# Changelog

All notable changes to `gflow-cli` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- **`gflow media trash` and `gflow media restore` move generated items to Flow's Trash and back over the wire ([#1363](https://github.com/ffroliva/gflow-cli/issues/1363)).** Operates directly via batchexecute RPC `pGCYOe` at 0 credits, resolving Flow project IDs from the local catalog and accepting Flow media UUIDs or catalog asset IDs. The CLI prompts for confirmation unless `--yes` is supplied, and MCP twins `gflow_media_trash` (requiring `confirm=true`) and `gflow_media_restore` maintain full surface parity.
- **`gflow video assemble` joins clips with a music bed and a voiceover, locally and free ([#1359](https://github.com/ffroliva/gflow-cli/issues/1359)).** Clips are local files or catalogued media ids; `--music` and `--voiceover` mix in with per-track volume, and `--duck` lowers the music under the voiceover. Output takes the first clip's size and frame rate; a clip with a different aspect ratio is refused rather than stretched. It runs on PyAV from the `chain` extra, needs no system ffmpeg, contacts no Flow surface and spends no credits. The MCP twin `gflow_video_assemble` stays available under `--no-spend`.
- **Local video transcription and burned-in captions ([#1358](https://github.com/ffroliva/gflow-cli/issues/1358)).** `gflow video transcribe` exports timed `.srt` subtitles through a configured OpenAI-compatible `/audio/transcriptions` endpoint using `GFLOW_CLI_LLM_BASE_URL`/`GFLOW_CLI_LLM_API_KEY` and `GFLOW_CLI_TRANSCRIBE_MODEL`; Google's endpoint does not offer transcription, and gflow refuses it before sending audio. `gflow video captions` burns subtitles into a local MP4 without credits. Both commands have MCP twins.
- **Hard per-command video credit caps ([#1355](https://github.com/ffroliva/gflow-cli/issues/1355)).** Pass `--max-credits N` to billed video commands or set `GFLOW_CLI_MAX_CREDITS=N`; use `--no-max-credits` to clear that default for one CLI call. MCP agents can pass `max_credits`, but cannot clear the environment default per call. gflow reads Flow's pre-submit quote, refuses an unreadable or over-limit quote with exit 45, and tracks spend across chain, extend, and movie runs.

### Fixed

- **macOS: gflow no longer asks for the Keychain password on every command.** Checking the session and launching the browser read the profile's cookies with browser_cookie3 first. On macOS that fetches "Chrome Safe Storage" from the Keychain, which raised a password prompt on each read (about five per command), and the read still failed to decrypt the jar, so gflow fell back to the headless Chrome read every time. On macOS gflow now goes straight to that read. A cookie store that is not an SQLite file is still reported as corrupt (#796) and never opened by Chrome. Windows and Linux are unchanged.
- **The landing page meets WCAG AA contrast in both themes.**
  - The light theme's amber, grey and red text measured 2.4:1 to 4.0:1, and the primary button's hover state 3.7:1. Every text colour now measures at least 4.5:1 on the backgrounds it is used on.
  - The light theme's background is a neutral light grey instead of cream, and on the darker amber the primary button's text is white.
  - In the dark theme, the faint text (the terminal titles and the footer note) now passes 4.5:1 too.
  - On phones the hero section has side margins again: its padding had removed the page gutters, so the headline touched the screen edge.
  - The small uppercase labels above section headings are removed; the hero's "beta" status moved into the opening paragraph.
- **The README's models table renders as one table again.** A note about the 2026-12-05 retirements sat between its rows, so Veo 3.1 Lite and every image model lost the table header.
- **The README comparison table adds kodelyx/flow-agent**, with two rows where it goes further than gflow-cli: an OpenAI-compatible API and credit pooling across Google accounts. `llms.txt` now claims only what still holds with it counted: gflow-cli is the only tool in that table that installs from PyPI and is listed in the official MCP Registry.
- **The README, `llms.txt` and the landing page say which gflow-cli this is.** Other projects use the name, including Node.js packages on npm and JSR; this one is the Python package on PyPI.

## [0.103.1] — 2026-11-20

### Fixed

- **A project left in Flow's agent mode, or with the agent panel open, runs on the classic composer again on flow.google.com ([#1384](https://github.com/ffroliva/gflow-cli/issues/1384), [#1374](https://github.com/ffroliva/gflow-cli/issues/1374)).**
  - **The new build.** Flow's 2026-11-20 build replaced the Agent chip with a switch and closes the agent panel through a different control. Every generation on such a page failed before submit as selector drift (exit 23), `image t2i` included.
  - **The older build.** With the panel open, the page was read as the agent-only composer, so image-to-video, reference-to-video and image-to-image exited 36.
  - **What gflow does now, on both builds and through the CLI and MCP alike:**
    - closes the panel with its own close button;
    - turns agent mode off;
    - continues on the classic composer.
  - **Flow keeps that change across reloads**, so agent mode stays off until it is switched on again. The run logs `migrated.agent_mode_exited` at warning level when it happens.
  - **Messages** that asked users to turn "the Agent chip" off now say to close the agent panel and switch Agent off. The error table in `KNOWN_ISSUES.md`, the exit-23 row in USAGE and the agent-only section of the MCP guide describe the switch and the panel ([#1389](https://github.com/ffroliva/gflow-cli/pull/1389)).
  - **gflow never guesses at the panel's close button.** If more than one control matches, or none does, nothing is clicked and the run stops before submit with exit 23, charged nothing ([#1389](https://github.com/ffroliva/gflow-cli/pull/1389)).
- **#1369 (the agent-only chat answering the previous request) is closed as stale.** On Flow's 2026-11-20 build the agent-only driver stops at its settings button before sending anything, so the carry-over cannot occur there. The check moves to [#1387](https://github.com/ffroliva/gflow-cli/issues/1387), which ports the driver to that build ([spike](docs/superpowers/spikes/2026-11-20-agent-only-driver-on-the-new-build.md)).

## [0.103.0] — 2026-11-19

### Added

- **gflow says which video models Flow is retiring ([#1375](https://github.com/ffroliva/gflow-cli/issues/1375)).** Flow retires Omni 1.1 Flash (`omni-flash`), Veo 3.1 Fast (`veo-fast`) and Veo 3.1 Quality (`veo-quality`) on 2026-12-05. `gflow models` shows the date in a `retires on` column, and `gflow models --json`, `gflow models show --json` and the MCP tool `gflow_list_models` carry `retires_on` (an ISO date, or `null`) on every video model. A generation that selects one of them logs a `model.retiring` warning on stderr (stdout stays clean for `--json` and `-o id`); over MCP, the `gflow_generate_video` reply and the queued task's `tasks/get` result carry `"warnings": [{"type": "model_retiring", "model": …, "retires_on": …}]`. Nothing is refused because of the date: once Flow's menu stops offering a model, the run stops before submit, charged nothing, as before; on flow.google.com's composer (exit 11) the message now also names the date and the models Flow does offer. The dates come from Flow's own catalog, recorded in a test fixture that fails when a refreshed capture moves them. **Before 2026-12-05, move scripts and manifests to `veo-lite` or `omni-1.2`.** A run that leaves `--model` out on t2v or r2v uses Flow's current default, which gflow cannot read yet, so it gets no warning even if that default is leaving.

### Changed

- **The `gflow movie template` scenes and the documentation examples use models Flow keeps ([#1375](https://github.com/ffroliva/gflow-cli/issues/1375)).** The template's scenes move from `omni-flash` and `veo-quality` to `omni-1.2` (the scene with a duration) and `veo-lite`. The examples in USAGE, MOVIE and the video-production skill move the same way, and the skill recommends `omni-1.2` where it recommended `omni-flash`. The short spellings `omni` and `flash` (accepted over MCP and in manifests) keep selecting Omni 1.1 until the date passes; repointing them is [#1379](https://github.com/ffroliva/gflow-cli/issues/1379).

- **The project status moves from alpha to beta.** The PyPI classifier is now `Development Status :: 4 - Beta`, matching the README badge, `docs/PROJECT_STATUS.md` and the docs site. The status reflects more than 130 releases, every one since v0.54.0 live-verified against Google Flow; `0.x` minor versions may still change the API.
- **The README leads with what gflow-cli is and does.** It opens with a one-paragraph definition and an at-a-glance table, then answers the common questions under their own headings: what it can do, how to connect Claude Code, Cursor or Codex, which models it supports, how it protects credits and the account, and how it compares with other Google Flow automation tools (dated, sourced from each project's README, with planned items linked to [#1367](https://github.com/ffroliva/gflow-cli/issues/1367)). The package description, `server.json`, the docs-site home page and the plugin manifests name the current models (Veo 3.1, Omni, Nano Banana). `llms.txt` opens with a short summary and a key-facts list before the detailed reference, and is published at the docs-site root. The landing page carries Open Graph tags and `SoftwareApplication` / `FAQPage` structured data.

## [0.102.1] — 2026-11-19

### Fixed

- **`gflow video t2v` on the agent-only composer finds a clip whose page names no media id ([#1354](https://github.com/ffroliva/gflow-cli/issues/1354)).** On some flow.google.com accounts, every URL that shows a finished clip, including the tile, its hover player and the chat option's poster, is an opaque `flow.google.com/asb/...` with no media id. gflow read the id only from a `flow-content.google/video/<uuid>` URL, so a clip Flow had billed and finished was never recognised: the run waited out its 600 s, exited 9 with `charged: "maybe"`, and saved nothing. When the new tile names no id, gflow now reads the project's listing in a second tab and takes the record whose poster carries the same `/asb/` token as the tile, provided that the record is finished, was not on the page before the submit, and was created after it (with 15 s allowed for clock skew). gflow reads the listing only after the clip has shown as pending. The early `VideoStarted` report fires once the id is known. A clip it cannot match that way still ends with exit 9 (exit 44 under `GFLOW_CLI_EXIT_CODES=2`), and the error's detail now names where the run stopped: the last poll's verdict, whether a pending clip was seen, and how often the listing was read. `gflow_generate_video` with `mode="t2v"` over MCP runs the same code and gets the same fix.

## [0.102.0] — 2026-11-18

### Added

- **A queued job that fails unexpectedly names the exception class ([#1343](https://github.com/ffroliva/gflow-cli/issues/1343)).** The worker's `errors/unknown` result carried only a SHA-256 of the message, so an intermittent failure could not be told apart from any other. It now also carries `class`, the qualified exception class (for example `playwright._impl._errors.TimeoutError`); the message itself is still never stored.
- **The weekly usage report counts the browser engine and the Flow site served ([#1326](https://github.com/ffroliva/gflow-cli/issues/1326)).** Two new fields, `engines` (`playwright`, `patchright`, `other`) and `hosts` (`labs`, `flow`, `unknown`), count the commands and queued jobs that selected a browser engine (a launch that then fails still counts; `gflow auth` is not counted), so a defect limited to one engine (#1319, #1324) or one Flow site can be sized. Both are closed enums; no hostname or setting value is sent, and a command that launches no browser counts in neither. The privacy notice moves to version 3 and names both fields. In the EU and EEA, consent given to an earlier notice no longer counts: uploads stop until `gflow telemetry on` is run again. Showing the version 3 notice restarts the upload clock: weeks finished before it was shown are not sent, and a machine used only through MCP uploads again after a person runs one command in a terminal.
- **A weekly `driver-watch` job announces browser-driver releases.** Dependabot ignores patchright updates and playwright minor and major updates by design, because a driver bump needs the engine-contract job and a live run (#1319, #1324), so seven patchright releases went unnoticed. The job compares both pins with PyPI and opens or updates one `driver-watch` issue per package whose latest release falls outside its pin, and closes it once the pin admits that release; a release whose issue is closed as not planned is not announced again. It never opens a pull request or changes a pin. `workflow_dispatch` with `dry_run` prints the plan only.

### Changed

- **CI: the Playwright browser is cached, and macOS lease runs move off pull requests ([#1335](https://github.com/ffroliva/gflow-cli/issues/1335)).** The uncached Chromium download took 18-362 s per shard and alone pushed runs past the 3-5 minute target; the 3.13 shards now restore it from a cache keyed on `uv.lock`. The macOS ProfileLease leg queued past its 15-minute timeout without a runner on four pull-request runs; pull requests now run the lease contract on Linux (the same POSIX `fcntl` branch) and Windows, and pushes to `develop`/`main` add macOS.

### Fixed

- **`gflow video extend` extends a clip that was already extended ([#1346](https://github.com/ffroliva/gflow-cli/issues/1346)).** On flow.google.com, each extend adds a workflow record to the clip under the same media id, and Flow's project read lists those records in no set order, while the clip's own entry names the newest one. gflow took the first record listed, so on a clip extended before, its route guard expected an older workflow than the one the page's extend request continues, and aborted the request ("continues workflow ..., not ...") before billing. gflow now expects the workflow the clip's entry names, provided it is one of that clip's records; a request for any other workflow, including an older version of the same clip, is still aborted before Flow sees it.
- **A queued job that fails unexpectedly after its submit is stored as `indeterminate`, not `failed` ([#1347](https://github.com/ffroliva/gflow-cli/issues/1347)).** The worker already stored a cancelled job by how far it got, but an unexpected exception after the submit always wrote `failed`, so a caller could retry a generation Flow may have billed. An unexpected (untyped) exception after the submit now stores the job as `indeterminate` with `charged: maybe` and `next_action: reconcile`; a gflow error keeps the job `failed` with the `charged` and `next_action` its raise site sets.
- **`gflow video upscale` reports a scale Flow does not offer as exit 22, not selector drift ([#1338](https://github.com/ffroliva/gflow-cli/issues/1338)).** Flow decides which scales a clip's download menu lists. Measured 2026-11-18 on flow.google.com: a Veo 3.1 Fast clip still lists 1080p, but Veo 3.1 Lite and Veo 3.1 Quality clips list only 270p and 720p, and an Omni 1.2 Flash clip lists 270p, 360p and 720p, so `--scale 1080p` found no item and exited 23 ("menu item for 1080p was not found"), which reads as a broken selector. When the menu's other items carry scale tokens but not the requested one, the image and video upscale paths now raise `UpscaleUnavailableError` (exit 22, do not retry) naming the scales Flow does list. The hint names which of the listed scales gflow can export. A menu with no readable scale at all, or one whose text carries the requested token, is still exit 23. `gflow_upscale_video` and `gflow_upscale_image` over MCP return the same error.
- **`gflow update` keeps installed extras on a pip install ([#1322](https://github.com/ffroliva/gflow-cli/issues/1322)).** It ran `pip install --upgrade gflow-cli`, which upgrades gflow-cli alone, so an extra's own pin never moved: a user who installed `gflow-cli[patchright]` and updated to v0.101.1 kept the broken patchright 1.61.2 (#1319). The pip command now requests every extra whose requirements are all installed (for example `gflow-cli[patchright]`; the contributor `dev` extra is never requested), and the repair commands gflow prints for uv, pipx and pip carry the same extras. `uv tool upgrade` and `pipx upgrade` were measured to keep the extras recorded at install time and are unchanged. The update runs the installed version's code, so a pip install of 0.101.2 or earlier needs one manual `pip install -U 'gflow-cli[patchright]'` to leave it.
- **`gflow video extend` reports a disabled Extend item as exit 35 instead of a 30 s timeout ([#1334](https://github.com/ffroliva/gflow-cli/issues/1334)).** On flow.google.com, Flow can render the clip editor's Extend menu item disabled: measured on an account holding 12 credits, next to a link to Google's AI plans, while a funded account's item was enabled. gflow clicked it anyway, and the click waited out Playwright's 30 s and surfaced as an unexpected browser timeout. gflow now reads the item's state first, allows it up to 3 s to become enabled, closes the menu, and raises `ExtendUnavailableError` (exit 35), or `InsufficientCreditsError` (exit 37) when Flow also shows its insufficient-credits warning, both with `charged: no`, since nothing was submitted. The page does not say whether the plan or the balance disables the item, so the hint names both.
- **A failure before a flow.google.com submit reports `charged: no` ([#1320](https://github.com/ffroliva/gflow-cli/issues/1320)).** `UiSelectorDriftError` (exit 23) defaults to `charged: maybe`, and its pre-submit raise sites inherited that default, so a settings-pane miss, which sends nothing to Flow, told an agent to reconcile a charge that cannot exist (seen in #1319). Every gflow error raised before the submit click on the classic and agent-only composers and in `video extend`, before the export click of `image upscale` and `video upscale`, and during a reference upload now reads `charged: no`; its `next_action` is unchanged. A submit the route guard aborts in the browser reads `charged: no` with `next_action: retry`. A failure at or after the click keeps `maybe`.
- **An `@mention` of a character the project does not have is exit 32, not exit 1 ([#1333](https://github.com/ffroliva/gflow-cli/issues/1333)).** On flow.google.com, a character mention whose first picker search offered nothing was retried by Backspacing the query, which leaves the picker's overlay open, so the retry's click on the prompt box timed out and the run ended in a raw `Locator.click: Timeout 5000ms exceeded` (exit 1, an incident bundle, and `errors/unknown` with status 500 over MCP). The retry now also presses Escape to close the picker, refuses the run if clearing the query removed a reference already attached, and a name no picker option carries ends in `ReferenceNotFoundError` (exit 32, `charged: no`, `next_action: fix_input`) naming the character, before anything is submitted. Its remediation points to `gflow character list --project <id>` (MCP: `gflow_character_list`) instead of the media-caption advice the class gives by default. The same picker search serves `--reference-entity-name` on `gflow video`, which gets the same fix.

### Tests

- **The `@Character` image e2e reads the CLI's events again ([#1332](https://github.com/ffroliva/gflow-cli/issues/1332)).** Since the CLI's default log level became WARNING (#1041), a `gflow` subprocess writes no INFO event to stderr, so `test_migrated_image_character_mention_bdd.py` reported "no character was attached" for a CLI run that did attach the character. The product was not affected: on an unchanged build, both CLI scenarios pass once `GFLOW_CLI_LOG_LEVEL=INFO` is set. The test now sets the level and the JSON format, and fails with a message naming those settings when the child wrote no events at all. `test_agent_only_composer_bdd.py` and the format-prompt test in `test_character_create_e2e.py` read INFO events the same way and now set the level too. A new offline check, `tests/test_e2e_log_level.py`, flags an e2e module that splits a child's stderr into lines and reads their `"event"` without assigning `GFLOW_CLI_LOG_LEVEL=INFO`.

## [0.101.2] — 2026-11-17

### Fixed

- **Under `GFLOW_CLI_BROWSER_ENGINE=patchright`, Chrome closes promptly again ([#1324](https://github.com/ffroliva/gflow-cli/issues/1324)).** patchright 1.64.4 (the v0.101.1 pin) ends its disabled-feature list with `.filter((feature) => feature && feature !== "MediaRouter")` instead of `.filter(Boolean)`. gflow's parse of that list stopped matching, so the merged `--disable-features` switch carrying `CloudSyncedFolderChecker` (#1140) was left out, and every patchright run waited out the 30 s close timeout before a force close (`browser_teardown.context_close_error`). The parse now reads that filter and drops the names it excludes, so `MediaRouter` stays enabled as patchright intends. The default `playwright` engine was not affected.
- **Sign-in, renewal, verification, cookie export and the experimental transports now read Playwright's own feature list (#1324).** These paths always launch through Playwright, but they read the configured engine's list. With patchright configured, the list they passed would have re-enabled `RenderDocument`, `BoundaryEventDispatchTracksNodeRemoval` and `MediaRouter` under Playwright, because Chrome honours only the last `--disable-features` switch. Each launch site now names the engine that launches it.
- **The `engine-contract` CI job now also pins the patchright bundle parse**, requires all three engine contracts to execute, and has a 15-minute timeout.
- **Every `patchright` install hint now names the extra** (`pip install 'gflow-cli[patchright]'`), so it installs the pinned version instead of whatever is latest.

## [0.101.1] — 2026-11-17

### Fixed

- **`GFLOW_CLI_BROWSER_ENGINE=patchright` no longer fails every flow.google.com generation with exit 23 "0 option groups rendered" ([#1319](https://github.com/ffroliva/gflow-cli/issues/1319)).** The `patchright` extra's pin moves from `1.61.2` to `1.64.4`. In 1.61.2, `locator.last` and `locator.nth(-1)` counted `0` whenever exactly one element matched, so the settings pane, the library picker and every other `.last` locator resolved to nothing while Flow's UI was unchanged. A real-engine regression test (`tests/api/test_engine_locator_contract.py`) now drives each installed engine against system Chrome, because the fake pages in the unit suite cannot observe a driver regression. The default `playwright` engine was not affected. Workaround on older releases: `GFLOW_CLI_BROWSER_ENGINE=playwright`.
  - **Upgrading must re-install the extra.** `gflow update` and a plain `pip install -U gflow-cli` do not upgrade an extra, so patchright can stay at 1.61.2. Upgrade with `pip install -U 'gflow-cli[patchright]'`, or `uv tool install 'gflow-cli[patchright]' --force` for a uv tool install, or `pip install patchright==1.64.4` if patchright was installed on its own. Then check that `pip show patchright` reports `1.64.4`.

## [0.101.0] — 2026-11-16

### Breaking Changes

- **Universal `-o/--output [json|table|id]` format selector across all commands ([#1158](https://github.com/ffroliva/gflow-cli/issues/1158)).**
  - `-o/--output` now exclusively selects the output format (`json`, `table`, or `id`, case-insensitive), aligning with standard CLI conventions (`kubectl`, `gh`, `az`, `gcloud`). `--json` is retained as an alias for `-o json`.
  - `--out-file PATH` is strictly enforced for explicit destination paths across all generation and export commands (`image t2i`, `image i2i`, `scene create`, `video t2v`, `video i2v`, `video r2v`, `video chain`, `video extend`, `data errors export`). Passing non-format values to `-o/--output` fails with exit code 2 and loud remediation (`use --out-file <path>`).
  - For `video upscale`, `--out DIR` is enforced; legacy `-o` is rejected with exit code 2 and remediation (`use --out <dir>`).
  - Kubectl-style `-o id` emits bare identifier strings separated by newlines to stdout (no table borders, headers, or decorative prefixes), with errors directed to stderr.
  - MCP parity: removed deprecated `output` parameter from `gflow_generate_image` and `gflow_generate_video` (`out_file` is the sole destination parameter).

## [0.100.1] — 2026-11-16

### Fixed

- **Locale-invariant count selector for settings pane on flow.google.com ([#1312](https://github.com/ffroliva/gflow-cli/issues/1312), [#1315](https://github.com/ffroliva/gflow-cli/pull/1315)).**
  On non-English accounts (such as German `hl=de`), Google Flow translates count toggle button labels to `1-mal`, `2-mal`, `3-mal`, `4-mal` (or in other locales `1 vez`, `1 fois`, bare `1`, `1x`). `_select` previously used `_exact("x1")`, which matched 0 radios and aborted with `UiSelectorDriftError` (exit 23). `_count` now anchors on the numeric count token while refusing adjacent duration (`4s`, `10s`), resolution (`4K`, `480p`), and aspect (`16:9`) sibling radios.


## [0.100.0] — 2026-11-15

### Added

- **`gflow image generate` and `gflow video generate`: one generate verb per media type, the mode
  read from the inputs.** `image generate` runs `image t2i`, or `image i2i` when a `--ref` is
  given; `video generate` runs `video t2v`, `video i2v` with `--initial-frame`/`--end-frame`, or
  `video r2v` with `--ref`. Each then is that verb: the same options, output and exit codes,
  and `--json` adds `"mode": "<resolved>"`. A frame and a `--ref` together, or an option
  the resolved verb does not take, is a usage error (exit 2) naming the mode verb, never a
  guess, and so is `--end-frame` without `--initial-frame`. The file flag is `--out-file
  PATH` only: the bridges take no `-o/--output PATH`. `video generate hero.png` (an image file
  as the prompt) is refused with the `--initial-frame` form instead of billing a t2v clip.
  The mode verbs stay and nothing is deprecated. The MCP tools are unchanged:
  `gflow_generate_image` runs i2i when `reference_images` is given, and
  `gflow_generate_video` takes `mode`. `generate` is the spelling the OpenAI and Google Gen
  AI SDKs use, and `gen` is kept as its alias (#1193).
- **`gflow --help --json` prints the command tree as JSON ([#1203](https://github.com/ffroliva/gflow-cli/issues/1203)).**
  `gflow <group> [<cmd>] --help --json` narrows it. Each command lists its path, summary,
  params and `spends_credits`, which is true for a command that submits a new Flow
  generation (video spends Veo credits, image the daily image quota). Paths and params are
  read from Click; `spends_credits` is set per command, and tests fail when a command has no
  decision, when the path-to-`spends_credits` snapshot changes, when a decision disagrees
  with the MCP spend gate, or when a command is missing from `docs/USAGE.md`. `gflow auth`,
  `auth use`/`logout`, `data errors export`/`prune`, `project show` and `project rename` are
  now documented there.

- **`gflow cancel <id>`: local abort, honest about server-side cancel.** A queued job, or
  one a worker claimed but has not submitted yet, is cancelled (state `cancelled`, exit 0,
  nothing charged): the worker re-reads its row just before submitting and stops. A job a
  gflow worker already submitted is marked `abandoned` (exit 22): Flow cannot be told to
  cancel it, so it may still run and be charged (a worker still running it keeps polling,
  so the result is recorded), and `--json` says
  `cancel.server: no`, `charged: maybe`, `next_action: reconcile`. A finished job is left
  as it is (exit 0); an unknown id is a `TaskNotFoundError` (exit 1). MCP `tasks/cancel`
  calls the same function. Migration `0010` adds the two queue states; error type
  `server-cancel-unavailable` shares exit 22 (#1198).

### Changed

- **MCP `tasks/cancel` stores what happened, not `failed`/`indeterminate`.** A task not
  yet submitted is now stored `cancelled` (it used to be `failed` with `reason: cancelled`);
  one already submitted is stored `abandoned`, whether this server or another process runs
  it (it used to be `indeterminate`, or left as it was). Both states are sticky: a worker
  that finishes later records its media id and catalog entry but does not flip the row, so
  `tasks/get` keeps answering `cancelled`, as SEP-2663 requires. A script that reads the
  queue table and matched `failed`/`indeterminate` for a cancel must also match these two
  (#1198).

### Fixed

- **`gflow update` in a Windows pip install no longer leaves gflow unusable ([#1298](https://github.com/ffroliva/gflow-cli/issues/1298)).**
  On Windows, `gflow update` in a pip install could leave gflow unusable when pip attempted
  to replace the running executable. `gflow update` now moves its launchers aside so the
  upgrade can complete; or, while another gflow process (an MCP server, `gflow serve`) holds
  a launcher, it stops before changing anything (exit 11). Installs in the user site
  (`pip install --user`) now upgrade with `--user`.
  *One-time manual upgrade for existing installs at 0.99.0 and below:* because their own updater
  still has the bug, close every gflow process, then run
  `<venv>\Scripts\python.exe -m pip install --upgrade gflow-cli` (venv) or
  `py -3.X -m pip install --user --upgrade gflow-cli` (`--user`; `3.X` is the Python gflow was
  installed under, and `py -0p` lists them).
- **`gflow character list` and `show` now work on accounts Flow serves from `flow.google.com`; the voice list has 30 voices (`Enceladus` added).**
  The MCP twins `gflow_character_list` and `gflow_character_show` return the same character
  details on `flow.google.com` ([#875](https://github.com/ffroliva/gflow-cli/issues/875)).
  Thanks to @ziyedbe ([#987](https://github.com/ffroliva/gflow-cli/pull/987)).
- **`video chain --out-file PATH` (and the deprecated `-o`) now writes the clips there.** It was
  accepted and ignored. Link i's clip goes to `<stem>_<i><suffix>` next to PATH
  (`out/clip.mp4` gives `out/clip_1.mp4`, `out/clip_2.mp4`), numbered over the whole manifest so
  `--resume-from` keeps each link's name; `--json`, the chain table and the videos catalog report
  those paths, and seed frames stay under `--out-dir`. An existing file or folder at a numbered
  path is never replaced, and a clip whose move fails is never lost: either way it stays where it
  downloaded, is recorded there, and a warning names the link, its media id and the path. A
  FILE under an existing file is a usage error before the cost prompt. The stderr notice is gone
  ([#1293](https://github.com/ffroliva/gflow-cli/issues/1293)).
- **`video chain --resume-from` continues the chain instead of restarting it.** The first resumed
  link was numbered 0: it overwrote link 0's chain row, went out as an unseeded text-to-video,
  and left the chain one row short, so a later resume billed a finished link again. Resumed links
  now keep their manifest index (chain table, `--json` `links[].index`, `--out-file` number), the
  first one is an image-to-video seeded from the last completed clip, and a resume whose clip is
  gone is refused with exit 20 naming the file, before anything is billed
  ([#1300](https://github.com/ffroliva/gflow-cli/issues/1300)).

- **`gflow update` says one thing about the result
  ([#1163](https://github.com/ffroliva/gflow-cli/issues/1163)).** It no longer shows the
  cached "update available" banner, which could name an older release than the one it then
  installed. The package manager's output is captured: a successful run prints two short
  lines, and the output is shown only when the update fails. `gflow update -v` streams it
  live, and `--json` stdout stays a single JSON document. When the manager exits non-zero
  after the new version is installed (on Windows, usually the running `gflow.exe`
  launcher), you get its output and a one-line note instead of an error followed by a
  success. Thanks to @nitishkp001.

- **`video extend` on flow.google.com no longer fails its catalog write, and reports the
  length it added.** Measured 2026-11-08 with the Omni extend key, Flow grows the source clip
  in place, under the source's media id. An extend is in place when Flow returns the
  source's own id. Nothing is written for it at submit, so a failed or timed-out run leaves
  the source row as it was; once Flow reports it done, the existing row gets `extended_by`,
  `extend_workflow_id` and `extended_at` instead of a failing duplicate insert (a source the
  catalog does not hold stays unrecorded). In that case `--json` reads
  `seconds_added`/`seconds_billed` from the key's `_<n>s` token (4/4 for
  `macaron_cookie_extend_4s`), or reports `null` when the key names no length; a separate
  segment keeps 7/8. The default output file gets a random tag when
  `<date>/<media-id>_extend.mp4` already exists, so a same-day re-run keeps the earlier
  file. The help no longer says the extension alone is downloaded or that each run leaves a
  new scene (#1184).
- **Usage telemetry recorded the wrong command after a root flag ([#1209](https://github.com/ffroliva/gflow-cli/issues/1209)).**
  `gflow -v auth list` counted as `gflow`, because a flag was treated as taking a value.

### Security

- **Error messages and saved failure records no longer leak flow.google.com secrets.** reCAPTCHA
  tokens, the page's XSRF value and private image links are now replaced with a placeholder,
  including when a long reply is cut short for the message. Media ids stay readable, so a
  recovery message can still name the clip. Very long replies no longer stall error reporting.
  Thanks to @ziyedbe (#987).

## [0.99.0] — 2026-11-14

### Added

- **Opt-in stable exit-code core (`GFLOW_CLI_EXIT_CODES=2`).** Opt in to a standardized core
  (0 ok, 1 error, 2 usage, 3 auth, 130 interrupted; 4 is reserved for "accepted, still running") with specific causes moved to
  `40`–`44` (`40`–`63` is reserved for specific causes). In `--json` envelopes, `exit_code` reflects the active mode and `exit_code_legacy`
  preserves the legacy code ([#1202](https://github.com/ffroliva/gflow-cli/issues/1202)).
- **`--out-file PATH` on generation/export commands and `out_file` on MCP tools ([#1158](https://github.com/ffroliva/gflow-cli/issues/1158)).**
  The explicit file destination is `--out-file PATH` on `data errors export`, `image t2i`,
  `image i2i`, `scene create`, `video t2v`, `video i2v`, `video r2v`, `video chain`, and
  `video extend`. In MCP, `gflow_generate_image` and `gflow_generate_video` gain `out_file`.
  `video chain` has never written to this path; it now says so on stderr instead of staying
  silent, and the clips still land under `--out-dir` ([#1293](https://github.com/ffroliva/gflow-cli/issues/1293)).

### Deprecated

- **`-o/--output PATH` on generation/export commands and `output` on MCP tools ([#1158](https://github.com/ffroliva/gflow-cli/issues/1158)).**
  Passing `-o` or `--output PATH` still works and prints one stderr deprecation warning.
  Passing `-o DIR` to `video upscale` still works with a warning; use `--out DIR`.
  In MCP `gflow_generate_image` and `gflow_generate_video`, `output` is deprecated in favor of `out_file`.
  Passing both old and new options is refused with exit 2 (or an MCP validation error).

### Changed

- **Internal: `UiAutomationTransport` and `MigratedComposer` are split into single-purpose mixins ([#1249](https://github.com/ffroliva/gflow-cli/issues/1249)).**
  The two classes are now chains of mixins, one job each; every name other modules read is still
  importable from the same place. No behaviour change.
- **Locked `opentelemetry-api` 1.45.2** (transitive only).

### Upcoming breaking change

- In a future release `-o/--output` selects the output format (`-o json|table|id`).
  Replace -o/--output PATH with --out-file PATH (and video upscale -o DIR with --out DIR).
- **Exit-code core will become the default in a later release ([#1202](https://github.com/ffroliva/gflow-cli/issues/1202)):**
  - `4` (`RateLimitError`) moves to `40`.
  - `5` (`ContentPolicyError`) moves to `41`.
  - `6` (`NetworkError`) moves to `42`.
  - `7` (`WireFormatError`) moves to `43`.
  - `8` (`AuthMissingError`) moves to `3` (unified auth exit code with `AuthExpiredError`).
  - `9` (`TransportTimeoutError`) moves to `44`.
  - `4` is reserved for "accepted, still running" (resumable jobs).
  - `5–9` are reserved.
  - `0`, `1`, `2`, `3`, `130`, and `10–39` are unchanged.
  Set GFLOW_CLI_EXIT_CODES=2 now to test your scripts against the new codes.

## [0.98.0] — 2026-11-12

### Added

- **Error envelopes say whether Flow may have billed, and what to do next.** Every
  `--json` error, MCP error result and failed worker-queue task now carries `charged`
  (`no` / `maybe` / `yes`) and `next_action` (`retry`, `retry_after`, `wait`, `reauth`,
  `fix_input`, `reconcile` or `none`), plus `operation_id` when an id exists. Each error
  class declares its defaults, and raise sites that know better override them: a failed
  download of a billed clip, an extend render or chain link failing after billed work, and
  a labs poll timeout after submit read `reconcile`. The result-shaped `--json` failures
  (`video t2v`/`i2v`/`r2v`, `video extend`, a partial `video chain`) and the envelopes the
  MCP server and worker build by hand carry them too. `retryable` is unchanged and always
  agrees with `next_action`; a rate limit also reports its `retry_after` seconds. Every `type` URI, its exit code and its defaults are listed in
  [docs/ERRORS.md](docs/ERRORS.md) (#1201).
- **`gflow capabilities [--json]` and the MCP resource `capabilities://self`** declare what
  gflow can drive, so an agent can plan instead of learning by failing (#1197). One value per
  key (`yes`/`no`/`partial`/`unknown`), with a note on every `partial`: `cancel.server` and
  `idempotent_submit` are `no`, and `submit.no_wait`/`status`/`wait` are `partial` (MCP
  `wait=false` and `tasks/get` only; the CLI verbs are #1194), and `download` is `partial`
  (recovery is video-only, #877). No call to Flow: the only input is `GFLOW_CLI_FLOW_HOST`,
  and `host` reports that setting (per-profile resolution is #1212). Both surfaces return
  the same document, except that a no-spend MCP server reports generation as `no`; a test
  fails when a CLI command is added without a capability entry. Keys: `docs/CAPABILITIES.md`.
- **`gflow models list` and `gflow models show <id>`.** `show` prints one model's catalog
  entry (aliases, reference cap; image models add Flow's menu name and the default flag, video
  models their selectable `durations` and max duration) by name or any spelling `--model`
  accepts; `--json` emits exactly the object `gflow_list_models` returns for that model, so a
  script no longer parses the whole list for one model's limits. An unknown id exits 2 and
  names the closest matches. Bare `gflow models` still works and is an alias of
  `gflow models list` (#1196).

### Fixed

- **Classic-editor selectors no longer depend on the UI language ([#1273](https://github.com/ffroliva/gflow-cli/issues/1273)).**
  On the classic (labs) editor the voice/character include action, the media-dialog upload
  button and the I2V frame slots now anchor on structure and icons only; the English and
  Portuguese/Russian caption fallbacks are gone. The duration tab is matched by its exact
  `8s` token first, then by its number alone, so a translated unit such as `8 giây` now
  works too; the number match refuses a resolution (`480p`, `4K`) or count (`4x`) sibling.
  When two visible iconless buttons could be the include action, gflow now fails loudly
  (exit 9, with a screenshot, "ambiguous: N matches") instead of clicking the first one.

- **An image submit is never resent with the same reCAPTCHA token ([#1275](https://github.com/ffroliva/gflow-cli/issues/1275)).**
  On a transport that sends gflow's own reCAPTCHA token (the HTTP transports, not Flow's page),
  a failed image submit was retried up to three times with the same single-use token. A 5xx
  can arrive after Flow took the job, so a resend was refused for the spent token or spent the
  daily image quota twice. The submit is now sent once on every transport. A server error,
  timeout (including the transport's own submit timeout), connection reset or closed browser
  exits 6 with `charged: maybe`, `next_action: reconcile` and a hint to check the project in
  Flow; a closed browser on these transports used to exit 15. A 429 is no longer retried
  either: it exits 4 with its `retry_after`, since the daily quota does not clear in seconds.
  An auth refresh after a 401 still resends once, because a 401 is refused before anything is
  made. The Flow-page path (#1010) is unchanged; polls and downloads still retry.

- **A timeout or connection reset on a billed extend or upscale asks you to check Flow ([#1274](https://github.com/ffroliva/gflow-cli/issues/1274)).**
  A Playwright timeout or connection reset while `gflow video extend` or `gflow image upscale`
  (or the `gflow_upscale_image` MCP tool; `video extend` has no MCP tool) sent its billed
  request exited 1 as an `UnexpectedError`, with no hint, though Flow may already hold the
  job. It now exits 6 like a server error on the same request: `charged: maybe`,
  `next_action: reconcile`, a hint to check the project in Flow, the cause's first line in
  the detail, and no resend. A browser closed while that request is in flight now gets the
  same answer instead of `BrowserSessionClosedError`, since the request may have reached
  Flow. A timeout before the request is sent (fetching the access token) surfaces as before.
  Non-billed calls still retry a timeout or reset as before.

- **A billed extend or upscale is never resent after a server error ([#1260](https://github.com/ffroliva/gflow-cli/issues/1260)).**
  `gflow video extend` and `gflow image upscale` (and the `gflow_upscale_image` MCP tool;
  `video extend` has no MCP tool) retried a 5xx or 429
  up to three times with the same request, single-use reCAPTCHA token included. A 5xx can
  arrive after Flow took the job, so a resend could bill twice or be refused for the spent
  token. These requests are now sent once. A server error exits 6 with
  `charged: maybe`, `next_action: reconcile` and a hint to check the project in Flow before
  running the command again. Non-billed calls (polls, reads) still retry as before.

- **A renamed image heals on flow.google.com too ([#546](https://github.com/ffroliva/gflow-cli/issues/546)).**
  `gflow image i2i --ref <media id> --project <id>` with a catalog name gone stale (the image
  was renamed in Flow) exited 32 where Flow serves flow.google.com, because the listing the
  heal reads (`flow.projectInitialData`) answers "deprecated and disabled" there. gflow now
  reads the current caption from the page's own `@` picker and retries within the reload
  budget; the MCP tool and `gflow run` heal the run too. The CLI still writes the fresh
  name to the catalog (`store` history mode only). Reach: the assets the empty picker lists.

### Changed

- **Internal: `VideoGenerationMixin` is split into single-purpose parts ([#1249](https://github.com/ffroliva/gflow-cli/issues/1249)).**
  The 3,278-line video mixin is now a chain of mixins in `api/transports/_video_*.py`, with the
  shared selectors in `_video_common`; every name others read from `ui_automation_video` is still
  there. No behaviour change: a golden master pins every moved method's source.

## [0.97.0] — 2026-11-10

### Added

- **`gflow credits` reads the balance without starting a browser when the saved session is
  accepted.** `credits user`, `credits list` and the MCP `gflow_get_credits` tool now ask
  flow.google.com for the balance directly, with the profile's saved cookies: two HTTP
  requests and no Chrome. When that fails (signed out, a network error, an unexpected reply)
  they read it in the browser as before; with Chrome open on the profile both reads fail and
  report the profile in use (exit 11, close Chrome and retry). When Flow throttles the account
  (HTTP 429 or 503) nothing falls back to the browser, which would send the same requests:
  `credits user` exits 4 or 6, and `credits list` records the error for that profile. `GFLOW_CLI_WIRE_READS=0` turns the
  direct read off; it is off by default on macOS and while any proxy is configured
  (`GFLOW_CLI_BROWSER_PROXY`, or an environment/system proxy). The direct read uses the saved
  Google session outside Chrome; what that risks and what is still unmeasured is in
  KNOWN_ISSUES (#1229).

- **`gflow doctor` and the MCP `gflow_auth_status` tool report whether that direct read works.**
  Doctor's new `auth.wire_read` check (default profile) and the tool's new `wire` field (on every session result) give
  `accepted` with Flow's build label, or the reason credit reads use the browser
  (`signed_out_shell`, `store_unreadable`, `disabled`, `proxy_configured`, `throttled`, …).
  Each sends one GET and one POST to flow.google.com unless the direct read is off. The check
  is informational: it never changes doctor's exit code. When Flow is throttling the account,
  `gflow_auth_status` skips its browser probe and returns `status: throttled` with
  `retry_after` (#1229).

### Fixed

- **No gflow process logs an httpx request URL any more.** Starting the MCP server set Python
  logging to INFO, at which httpx writes every request's full URL to stderr; MCP clients keep
  that output. The `httpx` and `httpcore` loggers are now held at WARNING in every gflow
  process (#1229).

- **`video extend` on flow.google.com reports the model it ran with instead of `unknown`.**
  The page now orders the extension with an Omni key (`macaron_cookie_extend_4s`, measured
  2026-11-08) that gflow's key search did not match. The key is now read from its slot in the
  request, so a word in the prompt can no longer pass for it. The page also no longer creates
  a scene before the extend. The extend e2e contract follows the new wire, and the guard that refuses an
  extend of the wrong clip is unchanged (#1180).
- **Closing Chrome no longer waits out the 30 s close timeout on Windows.** Chrome's
  shutdown waited on its OneDrive-folder check (`CloudSyncedFolderChecker`), which never
  answered on an affected machine, so every browser-backed command (for example `gflow credits
  user`) paid about 30 s after its work was done. Headless real Chrome waited too. gflow now
  turns that feature off in every Chrome it launches. Playwright passes its own `--disable-features` list and Chrome
  keeps only the last one, so gflow sends a single switch that carries Playwright's list plus
  its own. If a Playwright release moves that list where gflow cannot read it, the switch is
  left out and the close is slow again rather than wrong (#1140, #1233).

## [0.96.1] — 2026-11-08

### Fixed

- **Omni 1.2 Flash start+end (`video i2v --model omni-1.2-flash --end-frame`) runs instead of
  exiting 7.** Its submit carries a `*_i2v_fl_*` model key that gflow's start+end check did not
  know, so a valid run was refused after Flow had already billed it (#1178, by @Eighty20Digital).
- **A video submit gflow refuses is stopped before it leaves the browser, so it is not billed.**
  The check used to watch requests already on their way to Flow; it now runs as a route guard
  that aborts a wrong start+end, start-only or reference submit unsent, and the error says
  nothing was billed (#1178).
- **An Omni 1.2 end frame above 10 seconds is refused before any upload** (exit 2 on the CLI, a
  bad-parameter error over MCP). Flow drops the end frame there and bills a start-only clip,
  as measured by the reporter at 12s and 15s on a Google AI plan; start-only Omni 1.2 keeps
  3–15s (#1178).

## [0.96.0] — 2026-11-07

### Added

- **Omni 1.2 Flash** (`--model omni-1.2-flash`, alias `omni-1.2`; MCP `omni_1_2_flash`) with
  every whole-second `--duration` from 3 to 15 on flow.google.com, set through the model's
  duration slider and read back before Send. Above 10s needs a Google AI plan: on an account
  whose slider stops at 10s, a longer request is refused before submit (exit 11), with no
  credits spent. Chains and the agent-only composer still refuse it (#1168, by @vietanhjp93).

### Fixed

- **A request only the classic composer can take reloads the page before refusing.** When
  flow.google.com serves the agent-only composer (#799), image-to-image, a local `--ref`
  upload, character references and the video forms it cannot take now get up to three free
  reloads, then the same exit 36 as before. Seen once so far, on an account that got the
  classic composer on its next nine loads (#1142, by @L1meSn0w).
- **`video r2v --model omni-flash` accepts `--duration` 4, 6 or 10** on flow.google.com, not only 8.
  The 8s-only rule was measured on Veo, and it still applies to Veo and to an omitted
  `--model`; Omni keeps every reference at each length (#1167, by @vietanhjp93).

## [0.95.0] — 2026-11-07

### Added

- **Weekly usage reports, after a one-time notice** (#1164). gflow now sends one small report per
  completed week: command and MCP tool counts, exit codes, models, installer, OS and version
  totals. No install ID, prompts, file names, paths or account details are sent, and the server
  adds each report to weekly totals and discards it. `gflow telemetry show` prints the exact
  report, `gflow telemetry off` stops counting and uploads (`--delete` also removes the local
  counters), and `GFLOW_CLI_TELEMETRY=0` or `DO_NOT_TRACK=1` turn it off without a command.
  Uploads start only after the notice has been shown in an interactive terminal.
- **In the EU/EEA, uploads need consent**: they stay off until you run `gflow telemetry on`, and
  only weeks after that consent are ever sent. `gflow telemetry status` says which applies.
- **`docs/TELEMETRY.md`** describes the notice, the exact report, retention, the controller and the
  legal basis; the receiving server is public at `ffroliva/gflow-telemetry-endpoint` (#1164).

### Fixed

- The `gflow mcp setup` backup is now a byte-exact copy of the original config.

## [0.94.0] — 2026-11-07

### Added

- **Local usage telemetry commands `gflow telemetry status` and `gflow telemetry show`**
  displaying local counter storage and payload report (#1164).

- **`gflow data stats` (CLI) and its MCP twin `gflow_usage_stats`** summarize local usage statistics
  across commands and catalogued generations over the last N weeks (#1164).

- **Local usage counters and sanitized crash fingerprinting** in `<home>/telemetry.db`, recording
  weekly CLI/MCP command execution frequencies and top crash call-sites without capturing prompts,
  arguments, or account details (#1164).

## [0.93.0] — 2026-11-05

### Added

- **`nano21` is accepted as an image model alias** for Nano Banana 2.1, alongside `nano2.1`
  and `nano-2.1`, on the CLI, in manifests and in `gflow run` configs (#1145, thanks @L1meSn0w).

### Fixed

- **A one-clip text-to-video run survives a lost submit reply.** Chrome sometimes drops the
  reply to the submit while Flow makes and bills the clip, and gflow stopped with exit 9. It now
  finds the clip by its exact prompt and model and follows it to the end, without a second
  submit. With `--count` above 1, or when the project listing cannot name exactly one clip, it
  still stops with exit 9, because adopting another run's clip would be worse (#1141).

- **A finished text-to-video clip is downloaded again on flow.google.com.** Flow's status replies
  now carry the clip's thumbnail link where the clip's link used to be. gflow took it for the clip, so a
  billed run failed with exit 6 and `HTTP 302`, leaving nothing on disk. It now reads the clip
  through the clip's own page, the same way `gflow data download` does, and checks its size.
  A clip already stranded this way is recovered for free with
  `gflow data download <media_id>` (#1153).

- **An `@` mention that matches nothing no longer risks submitting the run.** gflow pressed
  Enter even when the picker offered nothing, and with no picker open Enter starts the
  generation. It now presses Enter only on an offered match and cancels a miss with Escape,
  so the run stops with a clean `ReferenceNotFoundError` instead of a raw timeout, attached
  references stay in place, and a retry can find the asset (#1143, thanks @L1meSn0w).

- **`gflow auth login` opens on screen on a profile that has already generated.** Chrome saves
  the off-screen generation window's position in the profile and, on the next launch, showed
  only a sliver of the window at the screen's edge, with no setting to change it. Login now
  sets its own position, `0,0`, on both the Playwright and the plain Chrome path.

- **`auth status` and `auth login` survive a My Account request that cannot complete.** On
  flow.google.com, gflow now reads Flow's signed-in workspace in that case and accepts the
  session only if the project-creation control renders. The probe can now take up to about
  2 minutes on a slow network (#1144, thanks @L1meSn0w).
- **`auth login` no longer crashes when no account address can be read.** A verified login
  without one finished with an `AssertionError`. It now succeeds and removes any old recorded
  account, so `--account` and the chooser fail closed.

### Security

- `oauthlib` is locked at 4.0.1 for CVE-2026-49272. It reaches installs through the `gcs` extra,
  which `uv.lock` does not bind for pip users.

## [0.92.1] — 2026-10-30

### Fixed

- **MCP agents now see how to pass `tools` and character ids.** The generate tools'
  schema stated neither the `tools` item shape (`{"name": <slug>, "options": {...}}`)
  nor that, on flow.google.com, each `reference_entities` id needs its name at the same
  position in `reference_entity_names` (and, for video, `mode: r2v`). The `tools` shape and
  the video rules sat only in docstrings the MCP client never shows; the image pairing
  rule sat in the long tool description, where agents missed it. The schema now also says that
  `gflow_character_list` fails there with a `wire-format` error (the CLI's exit 7, #875)
  and to ask the user for the name. In a
  tool-selection eval with Claude Code as the host, a character given by id was sent
  without its name in 4 of 5 runs, which fails before submit. With the rule in the
  schema, that dropped to 0 of 5.
- **The flow.google.com remediation hint no longer says video takes no character.** Since
  v0.91.0 (#723) reference-to-video attaches a character by name there; the hint on the
  `flow-host-migrated` refusal still said "video none", which an agent reads as a reason
  not to try.

### Added

- **`scripts/dev/mcpjam/`: a local tool-selection eval for the MCP server.** It snapshots
  the real `tools/list` with MCPJam's client, serves it from a stub that records calls
  without running them ($0, no browser), and drives `claude -p` as the host. Dev-only;
  not part of CI.

## [0.92.0] — 2026-10-29

### Fixed

- **A video saved with `-o` onto another filesystem no longer fails after it is billed**
  ([#1114](https://github.com/ffroliva/gflow-cli/issues/1114)). Moving the downloaded clip
  to `--output` used a rename, which raises `EXDEV` across mounts (a tmpfs `/tmp`, another
  drive), so the run ended in "Unexpected error" with the clip left in `./tmp/`. The CLI
  and the MCP queued path now move it with a copy when a rename cannot. The MCP video
  tool also refuses an `output` that names a directory before anything is billed, as the
  CLI's `-o` already did ([spike](docs/superpowers/spikes/2026-10-29-cross-device-relocate.md)).

### Security

- **MCP tools can no longer write outside the configured output directory**
  ([GHSA-hqfj-4jww-76f2](https://github.com/ffroliva/gflow-cli/security/advisories/GHSA-hqfj-4jww-76f2)).
  `output` on `gflow_generate_image` / `gflow_generate_video` and `out_dir` on
  `gflow_download_media` / `gflow_upscale_image` / `gflow_upscale_video` accepted any path,
  so an MCP client, or content steering one, could write or replace files anywhere the
  server's user can. They are now resolved against `GFLOW_CLI_OUTPUT_DIR` and refused with a
  400 envelope when they resolve outside it; an `output` that resolves to a directory is
  refused too. The `profile` argument of every MCP tool that opens a browser profile is likewise refused (400 `Invalid
  Profile`) unless it is a plain name: a path in it pointed Chrome's user-data-dir, and the
  files Chrome writes there, at any existing directory. **Breaking for MCP callers** that passed an absolute path outside the output
  directory: pass a path relative to it, or set `GFLOW_CLI_OUTPUT_DIR`. The CLI is
  unchanged. Reported by Filip Kulisiewicz; the `profile` path was found while reviewing the fix.

## [0.91.0] — 2026-10-28

### Fixed

- **A video whose submit reply Chrome lost now finishes with its clip on flow.google.com**
  ([#1112](https://github.com/ffroliva/gflow-cli/issues/1112)). About 1 in 7 r2v submits
  lost the reply body while Flow made and billed the clip, and gflow ended with exit 9. A
  run that uploaded a file (`--ref`, `--initial-frame`, `--end-frame`) now picks its clip
  out of Flow's status replies by that upload's id, or out of the project listing in a
  second tab, and downloads it, without submitting again. Text-to-video and character-only
  r2v runs upload nothing unique, so they still exit 9 (`retryable: false`).

- **Reference-to-video with a character now runs on flow.google.com**
  ([#723](https://github.com/ffroliva/gflow-cli/issues/723)). Local-file `video r2v` with
  `--reference-entity` paired with `--reference-entity-name` is served on the migrated host:
  the character is attached through the composer's `@` picker, its chip is verified before
  the billed click, and the submit body must carry its entity id beside every uploaded
  image, or the run is refused before Flow acts on it. An MCP r2v whose only reference is a
  character had no submit-body check at all before. The refusal rested on a null submit reply measured on
  2026-09-07; on 2026-10-26 an entity-bound r2v run completed end to end through the stock
  observer. An entity id without a name now exits 36 with that reason instead of failing
  later on a chip-count mismatch. Text-to-video with a character stays refused (exit 36,
  [#716](https://github.com/ffroliva/gflow-cli/issues/716)); image-to-video with a character is refused the same way.

- **MCP `wait=false` generations now run**
  ([#1097](https://github.com/ffroliva/gflow-cli/issues/1097)). Before, `gflow_generate_image`
  and `gflow_generate_video` with `wait=false` saved the job and returned a `task_id`, but no
  gflow command ever ran it: `tasks/get` said `working` forever. The job now runs in the
  background of the server that accepted it, one job at a time per profile within that
  server, sharing the
  profile with `wait=true` calls. Once it has finished, `tasks/get` carries the same reply
  `wait=true` would (files, project id, seed). `tasks/cancel` now stops the job instead of only
  relabelling its row, and a job cancelled after its submit fired is recorded as
  `indeterminate` (a credit may be spent), not `failed`; `tasks/get` then answers
  `cancelled`. When the client closes a stdio
  server or `gflow serve` stops, running jobs are cancelled and recorded the same way.
  Jobs queued by older releases are never picked up. See [MCP](docs/MCP.md).

### Changed

- **MCP `tasks/get` and `tasks/cancel` now speak SEP-2663**, the Tasks extension the server
  declares ([#1102](https://github.com/ffroliva/gflow-cli/issues/1102)). They used the shapes
  of the older 2025-11-25 tasks spec. `tasks/get` now sends `ttlMs` (null: rows do not
  expire) instead of `ttl: 3600`, and carries the finished tool result in a `result` field. A
  generation that failed now reads `completed` with `result.isError: true` instead of
  `failed`, because SEP-2663 keeps `failed` for protocol errors: **check `isError`**.
  `tasks/cancel` answers with an empty acknowledgement instead of a task; read the outcome
  from `tasks/get`. There is no `tasks/result`; the server answers it `-32601`.

- **Dependencies:** `pydantic-settings` 2.16.0 → 2.16.1, `platformdirs` 4.13.3 → 4.13.5,
  `fastapi` 0.143.2 → 0.161.1, and the dev tool `ruff` 0.17.1 → 0.17.2
  ([#1104](https://github.com/ffroliva/gflow-cli/pull/1104)).

### Security

- **The agent-only composer reads a credit confirmation before approving it**
  ([#988](https://github.com/ffroliva/gflow-cli/issues/988)). On an account Flow serves the
  agent-only composer, one confirmation can bill several generations, and gflow used to
  approve the first one without reading it, so an agent that queued too much was caught only
  after the credits were spent. gflow now reads the numbers in the confirmation's title and
  **rejects** one that quotes more than requested (exit 25, nothing approved). A video
  confirmation whose count cannot be read is not approved either. This matters most over MCP,
  where the prompt may come from an untrusted source. Measured on English and Russian titles
  from a contributor's account; not yet run on a maintainer account, because none is served
  this composer.

## [0.90.0] — 2026-10-25

### Added

- **`gflow run --resume` picks up where a run stopped**
  ([#934](https://github.com/ffroliva/gflow-cli/issues/934)). With the same config,
  project and output folder, a row whose images are already on disk and recorded in the
  local catalog as that project's is shown as `RESUMED` and not generated again, and a
  `batch:N` child references it in place. Before, a re-run regenerated every row, parents
  included, spending image quota twice. `--resume` needs `--project` or a config
  `"project"` (exit 11 otherwise). CLI only, like `gflow run` itself.

### Fixed

- **`image i2i --ref <file>` no longer uploads the same file again on every run**
  ([#772](https://github.com/ffroliva/gflow-cli/issues/772)). On flow.google.com, a loop
  over prompts with one `--ref` file left one copy of that image in the project's library
  per run. The first upload is now recorded in the local catalog, and a later run in the
  same project with the same file (same path, same bytes) mentions that image in place.
  If it was deleted from the project since, the file is uploaded again and the new copy
  recorded. The MCP image tool does the same. On labs, a file not yet recorded in the
  project still goes through the editor's own filename dedup (#314).

- **A corrupt cookie store is no longer reported as a network problem**
  ([#796](https://github.com/ffroliva/gflow-cli/issues/796)). When a profile's Chrome
  cookie database could not be read as a database, `gflow auth status` said "check
  network connectivity". It now names the cookie store and says to close any Chrome
  window using the profile and run `gflow auth login` again. The MCP `gflow_auth_status`
  tool returns a new `cookie_store_unreadable` outcome (HTTP 409, `retryable: false`)
  instead of the retryable `verification_error` (#796).

- **The MCP `wait` parameter is described where agents read it**. `gflow_generate_image`
  and `gflow_generate_video` now carry a `wait` description in `tools/list`: the default
  `true` runs the generation inside the call, which can outlast a client's tool timeout,
  and `false` only enqueues it and returns a `task_id` for `tasks/get`. It also says that
  no gflow command runs the queue worker yet, so a `wait=false` job is never generated
  (`tasks/get` keeps reporting it as `working`; #1097). The default is unchanged. See
  [MCP](docs/MCP.md) (#481).

- **`movie run` refuses costume `variants` on an entity character**
  ([#724](https://github.com/ffroliva/gflow-cli/issues/724)). A variant appends a text
  delta to the prompt, but an `identity = "entity"` character's body reference already
  fixes one outfit, so the two contradicted each other inside one generation with no
  telling which would win. Such a manifest used to run; it is now a configuration error
  (exit 11) when it is parsed, before any browser starts, and the message says what to do
  instead: one entity per costume, sharing the same `face_prompt`. Variants on
  `identity = "text"` characters are unchanged.

- **An output folder gflow cannot write is exit 11, not "Unexpected error"**
  ([#1091](https://github.com/ffroliva/gflow-cli/issues/1091)). After a successful
  generation, a failed local write (for example `--out` pointing at a protected folder)
  kept the media id (#1035) but then ended in the catch-all, with exit 1 and a "file a
  bug" message. It now ends as a configuration error (exit 11) that says the asset is
  still in the Flow project. This covers image downloads, upscale and extend exports and
  scene output, on both the CLI and MCP; a generated video clip keeps its exit 6
  ([#1003](https://github.com/ffroliva/gflow-cli/issues/1003)).

- **A credit shortfall on flow.google.com is recognised in every UI language, and only
  when Flow shows it** ([#745](https://github.com/ffroliva/gflow-cli/issues/745)). The
  warning anchor had an English `aria-label` half, which Flow translates; it is now the
  warning button's class alone (the measured element carries both). And the check now
  requires the warning to be visible, so a hidden one Flow keeps mounted cannot turn a
  real selector drift into "top up your credits" (exit 37).

- **Selector drift is watched again, on flow.google.com**
  ([#1083](https://github.com/ffroliva/gflow-cli/issues/1083)). The nightly GitHub
  `selector-probe` workflow loaded the labs.google editor, which redirects to
  flow.google.com for every account we hold, so it failed as "no recognizable editor" on
  every run from 2026-08-21 and checked nothing. The selector registry gains a
  `migrated_editor` surface built from the migrated composer's own constants, graded by a
  new `$0` `e2e_auth` test that the local canary runs nightly (`run_canary.py --project`);
  the dead workflow is retired. The canary's labs REST upload test now skips with the
  measured reason (labs.google serves no session token) instead of reading as RED.

- **The flow.google.com reference-to-video chip-count refusal states the numbers it
  compared** ([#745](https://github.com/ffroliva/gflow-cli/issues/745)). The guard counts
  image references and characters together, but the message printed only the image
  count, so a mismatch caused by a character read as "1 requested but 1 on the prompt".
  It now reads, for example, "1 image reference(s) + 1 character(s) = 2 chip(s) requested
  but 1 on the prompt".

### Changed

- **A signed media URL that answers an HTTP error is a failed download, exit 6, not
  exit 7** ([#941](https://github.com/ffroliva/gflow-cli/issues/941), part 2). After Flow
  reports a clip done, an error status on its download link (an expired link, for example)
  used to raise `WireFormatError` (exit 7) and leave the clip `pending` in the catalog. It
  now raises `MediaDownloadError` (exit 6, `retryable: false`) naming the clip, so the
  catalog marks it generated and `gflow data download <media_id>` recovers it for free.
  Scripts that branch on exit 7 for this case should branch on 6.

## [0.89.1] — 2026-10-24

### Added

- **An advisory CI check for what a change silently removes**
  ([#713](https://github.com/ffroliva/gflow-cli/issues/713)). `scripts/ci/check_deletions.py`,
  run by the Governance advisory workflow, warns when a Markdown doc under `docs/` or at the root loses far more lines than
  it gains (more than 50 net and 3x), and lists every tracked file still referencing a path the
  PR deletes (e.g. a Dependabot `directory:` entry). It never fails the build.

### Fixed

- **A redirect to flow.google.com/about now names the one measured cause**
  ([#1080](https://github.com/ffroliva/gflow-cli/pull/1080), superseding [#881](https://github.com/ffroliva/gflow-cli/pull/881); [#902](https://github.com/ffroliva/gflow-cli/issues/902)).
  Exit 31 used to say only "open the project in a browser". On the account that
  reproduces it, the cause was Google asking the account to "Confirm it's you" while its
  cookies were healthy; the hint now says to run `gflow auth login`, which waits on that
  check. The exit code and `retryable: false` are unchanged.

- **Upscaling an image right after generating it no longer fails as selector drift**
  ([#1067](https://github.com/ffroliva/gflow-cli/issues/1067)). Flow lists a just-made
  tile on the project grid only after a reload, so the upscale waited 30 s on a page that
  could never show it and ended in exit 23. It now reloads the grid every 10 s within the
  same budget: three grid loads for an image upscale, two for a video upscale (the video
  reload is covered offline; the live run was the image upscale).

- **An image whose reply Chrome loses is still returned** on flow.google.com
  ([#1075](https://github.com/ffroliva/gflow-cli/issues/1075)). Flow made the image every
  time; only the submit reply's body was unreadable, and the run ended in exit 9. gflow
  now reads the new tile off the project grid and downloads it. When the grid does not
  show exactly the requested number of new images, the run still stops with exit 9, now
  naming the project page to check.

- **A hidden model picker on flow.google.com is refused instead of trusted**
  ([#788](https://github.com/ffroliva/gflow-cli/issues/788)). When the picker was in the
  page but hidden (an agent-mode screen), gflow read its text, took the requested model as
  already selected, and went on to generate with whatever Flow had bound, billing it.
  Image and video runs now stop with exit 23 before submitting, naming the hidden picker.

- **An image Flow refuses on upload is reported as declined, not as a broken reply**
  ([#755](https://github.com/ffroliva/gflow-cli/issues/755)). When Flow answers an upload
  with its INVALID_ARGUMENT refusal (measured for a 1x1 PNG), the error now says Flow
  declined the image and suggests a normal-sized one, instead of "answered 200 without a
  media id". The exit code (27) is unchanged.

- **A successful `character create` keeps the character's id and name in the local
  catalog** ([#737](https://github.com/ffroliva/gflow-cli/issues/737)). The completion
  record replaced the whole metadata column, so succeeded rows kept the voice and media
  ids but lost which character they belonged to (0 of 104 rows on one machine). The
  `entity_id` and `name` written when the create started are now carried over.

## [0.89.0] — 2026-10-23

### Added

- **MCP `gflow_list_models`** ([#883](https://github.com/ffroliva/gflow-cli/issues/883)).
  MCP clients can now read the model catalog that `gflow models --json` prints (names,
  Flow menu labels, accepted aliases, reference caps, durations, aspects, tiers) instead
  of hard-coding one. It needs no profile or browser and spends nothing.

- **`GFLOW_CLI_PROJECT` sets a default project**
  ([#1039](https://github.com/ffroliva/gflow-cli/issues/1039), reported by @error-Sench).
  Every generation run without `--project` used to create a new Flow project, so a loop
  of `image t2i` calls left one project per call. Set `GFLOW_CLI_PROJECT=<id>` (in the
  environment or `.env`) and `image t2i`/`i2i`, `video t2v`/`i2v`/`r2v`, `gflow run`
  and the MCP generate tools use that project instead, printing a line on stderr that
  says so. `--project` and a typed `--project-name` still win (`GFLOW_CLI_PROJECT_NAME`
  names the pinned project instead). It is never used by `extend`, `upscale`, `scene`,
  `character` or `instructions`, where `--project` means a specific existing project;
  `image batch` and `image upload` have no `--project` and are unchanged. A pin the local catalog records only under another profile is
  refused before a browser starts (exit 2), because a project belongs to one account.

- **`gflow models` shows the name Flow's menu uses**
  ([#1038](https://github.com/ffroliva/gflow-cli/issues/1038), reported by @error-Sench).
  Each image model now has a `label` in the table and in `--json`: Nano Banana 2.1,
  Nano Banana Pro, Nano Banana 2 Lite. `NARWHAL`'s label also names labs' Nano Banana 2,
  and Imagen 4 is marked as no longer in Flow's menu. `--model nano2.1` and `nano-2.1`
  (and the same values in a batch file, a `gflow run` config and over MCP) now select
  the `nano2` tier, the one Flow calls 2.1. `character create --model` keeps its own two
  choices. A model-selector hint on flow.google.com named `nano-banana-2`, which `--model`
  rejects; it now says `nano2`.

### Fixed

- **A rejected upload (exit 27) now writes an incident bundle**
  ([#770](https://github.com/ffroliva/gflow-cli/issues/770)). The error can only say that
  some dialog opened after the file was chosen; the bundle's screenshot shows which one.

- **An upscale or extend on the same client after a flow.google.com run no
  longer fails with a reCAPTCHA error** ([#914](https://github.com/ffroliva/gflow-cli/issues/914)).
  After an image, video or upload run gflow parks its page on `about:blank`, and the
  next call read that page as the labs host and tried to mint reCAPTCHA there. The
  route now remembers that the page was parked from flow.google.com. This was reachable when one
  `FlowApiClient` was reused in a script; a single CLI run or MCP task was not affected.

- **A failed download of a finished, billed clip is no longer marked `retryable`**
  ([#941](https://github.com/ffroliva/gflow-cli/issues/941), part 1). `MediaDownloadError`
  inherited `retryable: true` from `NetworkError`. A scheduler that re-runs anything
  retryable would generate, and pay for, the clip a second time. On the generation
  downloads (flow.google.com and labs), the clip writer and the image download (whose
  re-run spends daily quota again), it is now `retryable: false`
  in `--json`, MCP envelopes and the worker record. The fix is `gflow data download` /
  `gflow_download_media`, which spends nothing and stays `retryable: true`. Exit code 6
  is unchanged.

- **flow.google.com failure diagnostics no longer leak account identifiers**
  ([#890](https://github.com/ffroliva/gflow-cli/issues/890)). When the image submit
  button was covered, the drift error named the covering element with its raw `id` and
  class list, which on a signed-in page can hold the account email. It now names only
  the tag and framework class tokens (`div.glue-cookie-notification-bar`), as the click
  post-mortem already did. The composer also stopped writing its own screenshot and
  DOM snapshot into `<out>/ui-failures/`. Those files sat outside the incident bundle's
  review boundary and retention, and the snapshot carried the page title. The incident
  bundle still captures both.
  The same holds on the remaining paths
  ([#1062](https://github.com/ffroliva/gflow-cli/issues/1062)): the labs count-panel DOM
  dump (page title, element ids, class lists, labels and text) is removed, the debug
  screenshots written next to your output now follow `GFLOW_CLI_INCIDENT_CAPTURE`, and
  agent-mode recovery errors show the page URL without its query.

- **A profile open in your own Chrome window is now exit 11 with a clear message, not
  an unexpected error** ([#984](https://github.com/ffroliva/gflow-cli/issues/984)). When
  a Chrome you opened yourself holds the profile, Chrome refuses gflow's launch with
  "the profile is already in use by another instance". That text matched none of the
  checks for a stale gflow browser, so `credits user` (and any generation command)
  ended in `UnexpectedError`, exit 1. It is now `ProfileLockedError` (exit 11, MCP
  `profile-locked`), telling you to close that window or use another `--profile`.
  `auth login` (both `--browser internal`, which exited 1, and `--browser chrome`,
  which fell back to a second launch and exited 8) and the Playwright cookie read do
  the same ([#1059](https://github.com/ffroliva/gflow-cli/issues/1059)).

- **`gflow image batch` reports manifest errors as exit 11, like `gflow run`**
  ([#935](https://github.com/ffroliva/gflow-cli/issues/935)). The same malformed row
  exited 11 under `gflow run --config` and 2 under `gflow image batch`. A manifest's
  contents are configuration, so both now exit 11 with a `Manifest error:` line. That
  includes a row `ref`, which `image batch` does not support. Scripts that branched on
  exit 2 for a bad `image batch` manifest need to check 11.

- **Image and video generation into a `--project` id Flow will not open now fails in
  seconds with exit 11, not as selector drift** ([#974](https://github.com/ffroliva/gflow-cli/issues/974)). Flow
  answers such an id with its `flow.google.com/404?reason=project` page; gflow waited
  30 s for the composer and reported exit 23 ("Flow's UI changed"), telling a user with a
  typo the wrong cause. It now recognises that page by its URL and stops with a
  configuration error naming the id as not found or not accessible to the account, not
  retryable, on the CLI and over MCP (`image t2i`/`i2i`, `video t2v`/`i2v`/`r2v`,
  `gflow run`). `image upscale`, `video upscale` and `video extend` into such a project
  now end with the same exit 11 instead of exit 23 or a transport timeout (exit 9)
  ([#1053](https://github.com/ffroliva/gflow-cli/issues/1053)). They still wait out
  their own page budget (about 30 s) first.

- **A downloaded clip's media id is checked before it becomes a filename**
  ([#1004](https://github.com/ffroliva/gflow-cli/issues/1004)). Hardening: the local
  branch of the shared clip saver, used by the flow.google.com and agent-only video
  downloads, wrote `<media_id>.mp4` without the check the cloud branch applied, and so
  did `gflow data download`'s flow.google.com recovery. An id holding a path separator
  is now refused before anything is written.

- **A cloud storage URI with `video -o`, `video chain`, `movie run --stitch` or MCP
  `output` is refused before billing** ([#1008](https://github.com/ffroliva/gflow-cli/issues/1008)). With
  `GFLOW_CLI_STORAGE_URI` set to `s3://` or `gs://`, the clip comes back as a bucket
  object, which `-o/--output` and the MCP video `output` could not move to a local path
  and `video chain` and `movie run --stitch` could not hand to ffmpeg. Each failed with a raw exception after
  Flow had billed the clip. gflow now stops before submitting, with exit 11 (an MCP
  configuration error) naming the setting.

- **`video upscale` no longer says "Image upscale unavailable"**
  ([#966](https://github.com/ffroliva/gflow-cli/issues/966)). Exit 22's title, shared by
  the image and video upscale paths, is now "Upscale unavailable for this account" in the
  CLI message, `--json` and MCP error envelopes. The exit code and `type` are unchanged. A refused
  2K image upscale no longer advises `--scale 2k`.

## [0.88.0] — 2026-10-22

### Added

- **`GFLOW_CLI_BROWSER_PROXY` routes the browser through a proxy**
  ([#1036](https://github.com/ffroliva/gflow-cli/issues/1036), reported by @error-Sench).
  On a network where Google is reachable only through a local proxy (Clash on
  `127.0.0.1:7897`, say), gflow's HTTP calls followed `HTTPS_PROXY` but the browser it
  launches did not, so every page step timed out. The new setting takes
  `http://`, `https://` or `socks5://host:port` and applies to every browser launch:
  generation over the CLI and MCP, `auth login`, `auth renew` and the `auth status`
  check. Opt-in: unset changes nothing, and it is never derived from `HTTPS_PROXY`. A bad
  value fails at startup (exit 11), and so do proxy credentials (`user:pass@`): measured,
  Flow never loads through Playwright's proxy authentication, so a local client such as
  Clash should hold them. A dead proxy stops a generation run at its first page load with
  a hint naming the setting (exit 11). `gflow doctor` reports the proxy, and credentials
  inside any URL are now redacted from error details.
  `docs/ACCOUNT_SAFETY.md` now says: no IP rotation, no proxy unless you set one, and sign
  in through the proxy you generate through.

### Fixed

- **A project create on a slow link no longer fails while Flow makes the project, and
  never invites the retry that duplicates it**
  ([#1037](https://github.com/ffroliva/gflow-cli/issues/1037)). On flow.google.com a create
  whose reply took over 30 s (measured: 40 s through a slow proxy) ended as exit 9
  `TransportTimeoutError`, flagged retryable, while Flow went on to create the project, so
  a retry made a second one. The create and rename replies now wait up to 120 s. Selector
  waits stay at 30 s, so a moved frontend still fails fast. If the reply is still late or
  lost, gflow takes the id from Flow's navigation to the new project and checks it. If it
  cannot prove the outcome, it now ends with exit 7 (`RpcResponseUnavailableError`,
  `retryable: false` in `--json` and on the MCP queue) and tells you to look for the
  project and pass `--project <id>`, instead of a retryable timeout. A rename whose reply
  is lost is settled by reading the saved title back. Builds on #992's lost-body recovery.

- **Commands no longer print about ten info log lines before their result, and
  `GFLOW_CLI_LOG_LEVEL` works** ([#1041](https://github.com/ffroliva/gflow-cli/issues/1041)).
  Every command logged at `INFO` to stderr regardless of `GFLOW_CLI_LOG_LEVEL`, which was
  documented but read by nothing. The default is now `WARNING`, so a command prints its
  result plus warnings and errors. `GFLOW_CLI_LOG_LEVEL=INFO` restores the old output, and
  `-v` still shows everything. A long-running `gflow mcp run` / `gflow serve` now also logs
  only warnings by default (uvicorn's own startup and access lines under `serve` are
  separate); set `INFO` there to keep progress events. `gflow data sync` now echoes its
  per-project progress itself unless INFO text logs already narrate it. `--json` stdout is
  unchanged (it was already only the result).
- **A generated image whose download fails is no longer lost**
  ([#1035](https://github.com/ffroliva/gflow-cli/issues/1035), reported by @error-Sench).
  Flow generated the image and spent the quota, then a failed local write (for example an
  `--out` directory gflow cannot write to) left only a FAILED row with no project and no
  asset, and the media id went with the traceback. `image t2i`, `image i2i`, `image batch`,
  `gflow run` and the MCP `gflow_generate_image` tool now keep the media id in the catalog,
  with no local copy, under one FAILED operation in its project. `image t2i` and `image i2i`
  also print the media id(s) and the project URL on stderr; `image batch` and `gflow run`
  only log them (the row is marked failed in their summary). The MCP failed reply carries
  `flow_media_id` and `flow_project_id`. Exit codes are unchanged (a write refused by the OS
  is still exit 1). A download interrupted with Ctrl-C leaves the operation STARTED, which
  `gflow doctor` reports as stuck after 24 h. `gflow data download` stays video-only, so the
  image is recovered from the Flow project.

- **`gflow auth login --browser internal` no longer waits until its timeout**
  ([#1026](https://github.com/ffroliva/gflow-cli/issues/1026)). With labs.google's session
  URL answering 410 (#1023), a bundled-Chromium login (`--browser internal`, or
  `--browser auto` on a machine without Chrome) never saw a signed-in session and waited
  until its timeout. It now ends the wait once the flow.google.com session cookies appear,
  then verifies the saved profile with the same server-attested check `--browser chrome`
  and `auth status` use, so a sign-in that did not complete says why instead of timing
  out. Generation still needs a `--browser chrome` profile. Verified live on Windows
  (2026-10-22: a fresh bundled-Chromium sign-in finished on its own and `auth status`
  reported the session verified). Not measured on macOS, where the saved-cookie read is
  expected to fail; the login then ends with "re-run with `--browser chrome`".
- **flow.google.com: a write whose reply Chrome lost is read back, not called a failure**
  ([#1009](https://github.com/ffroliva/gflow-cli/issues/1009), PR
  [#992](https://github.com/ffroliva/gflow-cli/pull/992) by @L1meSn0w). Chrome sometimes
  cannot hand over a reply body (`Network.getResponseBody: No data found`, 2 of 45 real
  uploads in our spike) although Flow saved the write. A local upload was reported as a
  rejected file, and a project create or rename as a timeout. gflow now opens the project
  in a second tab and checks it: the new project's id from the page it navigated to, the
  saved title, or exactly one tile with the run's unique file name and a media id. Nothing
  is submitted twice. If that check cannot prove the outcome, the command exits 7 with
  `RpcResponseUnavailableError`, which is not retryable. Renaming a project to the title it
  already has no longer waits for a reply Flow never sends.

### Changed

- **A lost upload reply now exits 7 (`RpcResponseUnavailableError`) instead of 27**
  ([#1009](https://github.com/ffroliva/gflow-cli/issues/1009)). Exit 27 still means Flow
  answered and refused the file. Exit 7 here means the outcome is unknown: the upload may
  have saved, so check the project before re-running. Scripts that branch on 27 for a lost
  upload should branch on 7.

### Removed

- **`GFLOW_CLI_TIMEOUT_SECONDS`** ([#1037](https://github.com/ffroliva/gflow-cli/issues/1037)).
  It was documented as a per-request HTTP timeout and elsewhere as a chain link ceiling, but
  nothing read it. An `.env` file or environment that still sets it keeps loading; the
  value is ignored, as it always was.

## [0.87.1] — 2026-10-22

### Security

- **Locked `opentelemetry-api` 1.45.1 (CVE-2026-114603).** Transitive only, via `fastapi`
  and `mcp`; no gflow code imports it. The advisory turned the `pip-audit` gate red on every
  open PR.

### Fixed

- **`gflow credits` reads a balance again** ([#795](https://github.com/ffroliva/gflow-cli/issues/795)).
  Since 2026-10-22 it failed on every account, because its token came from labs.google's session
  URL, which now answers HTTP 410. `credits user`, `credits list` and the MCP tool
  `gflow_get_credits` now open flow.google.com in the profile's browser and read the balance from
  the app's own `nzlxg` reply. That is the number in Flow's account menu: it matched in 5/5 reads,
  one of them after a 10-credit spend. It costs one browser launch per profile, nothing is
  clicked or spent, and a profile in use by another gflow process reports `ProfileLockedError`.
  The JSON keys are unchanged, but `sku`, `service_tier`, `user_paygate_tier` and
  `subscription_credits` are now always `null`, because flow.google.com does not report them.
  A sign-in landing is exit 3 (`--refresh` renews it). An app that never fetches the balance is
  exit 31 (`FlowAppError`), never an auth error. Measured on two accounts, neither on a paid plan; a paid plan may shape
  the reply differently.

- **A video run into an existing `--project` no longer rewrites that project's title in
  the local catalog** ([#1022](https://github.com/ffroliva/gflow-cli/issues/1022)).
  `video t2v`/`i2v`/`r2v`/`extend` replaced the stored title with their `gflow-cli video`
  placeholder, so `gflow data list projects` showed that for a project titled `my-project`
  in Flow, and every run (images included) overwrote a project's `gflow-cli` source. Only
  `gflow project create` and `rename` change a stored title now, and an empty title is no
  longer kept as a real one. CLI and MCP share the fix. A title already overwritten is not
  recoverable locally: run `gflow project rename <id> <title>` to restore it. Reported, with
  the fix, by @error-Sench.
- **2K image upscale on flow.google.com no longer fails when Chrome loses Flow's reply**
  ([#1027](https://github.com/ffroliva/gflow-cli/issues/1027)). `gflow image upscale` and
  the MCP upscale tool failed with `WireFormatError: Failed to parse SPrCad response ...
  No data found for resource with given identifier` although Flow had upscaled the image.
  Chrome dropped DevTools' copy of that reply on 6 of 12 measured upscales. The image is
  now also taken from the file Flow's page builds for its own download, which held the same
  bytes on 12 of 12. A refusal Flow does send still fails the run.

## [0.87.0] — 2026-10-22

### Security

- **Locked `aiohttp` 3.14.5 (CVE-2026-111063, CVE-2026-111064, GHSA-2g87-pp6c-29x5).**
  Transitive only, via the `gcs` (`gcsfs`) and `s3` (`s3fs`/`aiobotocore`) extras; no gflow
  code imports it. `yarl` moved to 1.25.1 with it. The advisories landed after the last
  green CI and turned the `pip-audit` gate red on every open PR.
- **Pillow 13.0.0 (eight CVEs, CVE-2026-112395 … CVE-2026-112899) and `certifi`
  2026.10.19 (PYSEC-2026-4320).** Pillow is a direct dependency (it writes the seed frame of
  `gflow video chain` and reads image dimensions); its floor is now `>=13.0.0`. `certifi` is
  transitive. Both advisories landed on 2026-10-21 and turned `pip-audit` red on every open PR.

### Added

- **flow.google.com: `image i2i --ref <uuid>` references an earlier image of the same
  project in place** ([#995](https://github.com/ffroliva/gflow-cli/issues/995)). When the
  local catalog records the image in the `--project` being generated in (and kept its Flow
  caption), the ref is marked `in_project` and goes through the existing #913 picker path:
  no upload, so a t2i → review → i2i pipeline split across invocations no longer needs
  Flow's upload-terms confirmation. MCP image tasks behave the same (`ref_meta` now carries
  the catalog's `flow_project_id`). Refs from another project, or without a recorded
  caption, still exit 36. Behaviour change: a same-project image deleted in Flow since it
  was catalogued now costs up to ~90 s of grid reloads and exits 32, instead of exiting 36
  at once.

- `scripts/dev/cleanup.py` — sweeps what a release or takeover session leaves behind:
  merged worktrees and branches, done `pr-<N>` fetch branches, merged same-repo origin
  branches (`--remote`), stray `.env` copies, old `bt*` pytest basetemps, and dead agentctl
  agents (reported only). Dry run unless `--apply`; never touches the main checkout, a dirty
  worktree, an unmerged branch, `develop` or `main`. The release skill's final report runs it.

- **MCP generation results report the catalogued seed** ([#1013](https://github.com/ffroliva/gflow-cli/issues/1013)).
  A completed `gflow_generate_image` / `gflow_generate_video` result now carries `seed`:
  the value catalogued for its `flow_media_id` (`null` when none was recorded) — the MCP
  twin of `gflow image t2i --json`'s `images[].seed`. On the classic image paths that is
  the seed Flow chose; the agentic and agent-only arms observe no seed and record `0`;
  for video it is whatever the CLI recorded from `--seed` (the MCP video tool takes no
  seed, so over MCP it is `null`), never one read back from Flow. Reported by
  @Chapax.

### Removed

- **Breaking for MCP callers: `gflow_generate_image` no longer takes `seed`**
  ([#1013](https://github.com/ffroliva/gflow-cli/issues/1013)). The image request never
  carried it — Flow picks its own seed — yet the tool advertised it "for reproducibility"
  and echoed it back in `params.seed`, so a caller could not tell it was dropped. The CLI's
  `--seed` went from `image t2i` in v0.8.0 for the same reason. The parameter is gone from
  the tool schema; a call that still passes `seed` is not rejected (the MCP server ignores
  unknown arguments) and it is no longer echoed back — read the result's `seed` for the
  value Flow chose (classic image paths). Reported by @Chapax.

### Fixed

- **`gflow auth login --browser chrome` and `auth status` work again now that labs.google's
  session URL answers HTTP 410 Gone** ([#1023](https://github.com/ffroliva/gflow-cli/issues/1023)).
  Since 2026-10-22 every session check reported "Could not verify the Flow session",
  and a first login rolled back its `chrome` marker. On a 410 gflow now verifies the
  session against Google's account page with the profile's own cookies, the check it
  already used for accounts labs never signed in (#791), and a profile with no Google
  sign-in is reported as signed out rather than as a network problem. `auth renew` and
  MCP `gflow_auth_status` use the same check. `gflow credits` still cannot read a balance:
  it needs the labs token that URL no longer issues (#795). A login with bundled Chromium
  (`--browser internal`, or `--browser auto` on a machine without Chrome) still cannot
  finish and waits until its timeout ([#1026](https://github.com/ffroliva/gflow-cli/issues/1026)):
  use `--browser chrome`.
- **flow.google.com: a run that fails after the submit click no longer invites a second
  billed generation** ([#1010](https://github.com/ffroliva/gflow-cli/issues/1010)).
  When Chrome lost the image submit reply's body, gflow silently submitted the image
  again: one `--count 1` run left two images in the project and reported one. A lost
  video submit reply, or any timeout after the click, was reported as a retryable exit 9
  while Flow had already made and billed the clip. A failure after the click now makes no
  second submit and reports exit 9 with `retryable: false`, a detail that names an
  unreadable reply as unreadable, and a hint to check the project before re-running.
  The image call now runs once on the labs.google composer too, since there gflow drives
  the same browser page: a hiccup before the click is reported instead of retried.
- On Flow's agent-only composer, an image result's `model_name_type` echoed the requested
  `--model`, so a `--model nano-pro` run that Flow rendered with Nano Banana 2.1 still
  reported `GEM_PIX_2`. Nothing on that composer observes which model rendered, so it is
  now `null`, as on the classic flow.google.com arm since #789. This fixes the attribution
  half of [#1012](https://github.com/ffroliva/gflow-cli/issues/1012) only: the agent can
  still render a model other than the requested one; that is not proven fixed (no
  agent-only profile to test on). Reported by
  @dev1abz.

- On flow.google.com, `gflow video upscale` (and its MCP twin) no longer reports a working
  export as failed with `Failed to read a video export response: ... Network.getResponseBody
  ... No data found`. The export watcher read every `batchexecute` reply during the export
  and treated any body Chrome had already evicted, usually an unrelated `as29s` poll, as a
  failed export, while the 1080p file was being delivered. An unreadable reply is now
  skipped; a real refusal of the export RPC still fails fast, and an export that never
  arrives still times out. Fixes [#1014](https://github.com/ffroliva/gflow-cli/issues/1014).
  Diagnosed and measured by @buiminhhieu-svg. Live-verified on flow.google.com: 3 of 3
  exports passed, against 2 of 2 failing on the previous `develop`.
- On flow.google.com, a configured cloud `GFLOW_CLI_STORAGE_URI` (`s3://`, `gs://`) was
  ignored for generated video: both composer arms wrote the clip to local disk while labs
  uploaded it. Fixes [#1003](https://github.com/ffroliva/gflow-cli/issues/1003). Both hosts now
  store a clip through the transport's one writer, so it lands at
  `videos/<YYYY-MM-DD>/<media_id>.mp4` in the bucket on either host, and the result's
  `local_path` is that cloud URI. The `gflow video` commands and MCP video tasks (through
  the worker) share this transport path. Images, `video extend` and upscale already
  honoured the setting on both hosts. A failed store (bad credentials, missing bucket)
  now exits 6 with the media id and the free `gflow data download <media_id>` recovery,
  and the catalog marks the billed clip generated, instead of surfacing a raw storage
  exception. Proven offline and against a RustFS bucket. The paid live run has not been
  done yet.

- On flow.google.com, `gflow video t2v`/`i2v`/`r2v` without `--out-dir` saved the clip to
  the root of the working directory instead of the documented `tmp/`, and `gflow video chain`
  saved its links to the working directory instead of `--out-dir` (or the configured output
  directory). Both hosts now share one rule — per-call directory, then the client's output
  directory, then `tmp/` — and the classic and
  agent-only composers no longer fall back to the working directory. Reported by @ziyedbe.
  Fixes #986.
- **On flow.google.com, the 4th `@` reference no longer lands between the 2nd and 3rd.**
  Before each mention gflow clicked the centre of the prompt box; with three chips on the
  line that centre is chip 2, so reference 4 was inserted behind it and the prompt read
  1, 2, 4, 3 (measured 3/3 at 1280×720). gflow now moves the caret to the end of the prompt
  before every `@` (image references in place, uploaded `--ref` files, and `@Character`
  mentions alike), and a mention that does not land after the chips already there now
  fails with exit 32 before anything is submitted, instead of passing silently. Thanks to
  @Ltwoz for the diagnosis and the fix. Their other symptom — the 4th picker not opening at
  all, on macOS — did not reproduce here and is not claimed fixed.
  ([#997](https://github.com/ffroliva/gflow-cli/issues/997))
- The S3 storage container tests and the `docker-compose.yml` local stack now run
  **RustFS 1.0.3** (pinned by tag and digest) instead of MinIO. MinIO removed its community
  images from Docker Hub in Sep 2026, so the old pin no longer pulled and the S3 tests could
  not start. Nothing ran them, so nobody noticed. A new `Storage container tests` CI job runs
  `pytest -m containers tests/integration/` (S3 via RustFS, GCS via fake-gcs-server) and
  fails if fewer than all 12 storage tests execute. The local-stack credentials are now
  `rustfsadmin`/`rustfsadmin`. Any S3-compatible store, MinIO included, still works as a
  `GFLOW_CLI_STORAGE_URI` target. See
  `docs/superpowers/spikes/2026-10-19-minio-replacement.md`.

## [0.86.0] — 2026-10-18

### Added

- **`gflow video extend` runs on flow.google.com, one segment at a time.** gflow opens the
  clip's editor and drives Flow's own Extend control, so the page builds and mints the
  `fZytfe` submit itself, the way every other flow.google.com port works. Before any click,
  Flow's own project read must list the clip as a video in `--project` (exit 11 otherwise).
  Every scene/extend request passes a route guard that aborts it, before Flow sees it, if
  it names another clip. The new segment is downloaded to `--output` (or the output
  directory). On that host `--segments > 1`, `--scene`/`--resume-from`, `--seed` and an
  `--aspect` other than the source's exit 36 before anything is billed; `--aspect` now
  defaults to the source's aspect there (9:16 on labs.google, as before). Each run leaves a
  new scene in the project, and the plan shows no price, because flow.google.com does not
  report one before submitting. Thanks to @stgmt, whose wire research in #882 (the
  workflow-id slot, the frame window, the `as29s` record) mapped this surface.
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639), [#882](https://github.com/ffroliva/gflow-cli/pull/882))
- **Text-to-image and text-to-video on Flow's agent-only composer
  ([#799](https://github.com/ffroliva/gflow-cli/issues/799)).** Accounts `flow.google.com` serves
  with no classic composer exited 25; `gflow image t2i` and `gflow video t2v` (and their MCP
  twins) now run there. gflow sets aspect, count and model in Agent settings, saves, asks the
  agent in plain language, and restores those defaults afterwards — also when the run fails
  with an error. A run killed between Save and restore leaves the run's defaults in place; the
  `migrated.agent_only.defaults_restore_failed` log names the originals (KNOWN_ISSUES).
  Completion is read from the page: images from new grid tiles, named by their
  `img[data-media-id]` and downloaded at original size from the tile's opaque `/asb/` URL
  (`=s0`; the tile itself shows a 512-px preview), videos once no pending tile is left, with the clip id taken from the agent's reply when the grid tile has
  none. Live-verified on an AI Pro account: 3:4 × 2 images, and a 4 s 9:16 clip downloaded.
  Other forms on that composer exit 36 before anything is clicked.
- **`GFLOW_CLI_AGENT_CONFIRM=account|always|never`** — the agent-only composer's "Confirm before
  generating" choice, applied before a run and kept. `account` (default) leaves the account's
  setting alone. With a confirmation step gflow approves exactly one that its own submit
  produced, and stops without approving a second. Only that second confirmation is stopped
  before billing: one confirmation can cover several clips, and an over-count under it is caught
  after the fact. A video run also refuses to start while another clip is still generating in the project, and stops if more clips are queued than were requested.
- **`gflow auth renew` refreshes saved sessions without signing in again.** It opens each
  profile (`--profile`, or `--all`) in a headless browser and loads Flow, so Google and Flow
  rotate the saved cookies. It then verifies the session like `gflow auth status`. No credits
  are spent. A revoked session still needs `gflow auth login`, and a profile in use by another
  gflow process is skipped. It reports a profile as renewed only when it saw it renewed: an
  account Flow holds at its public `/about` page is `public_landing`; a labs.google session that
  stayed expired, or never answered readably, is `labs_stale` / `labs_unverified`; a browser
  that cannot start (the profile is open in your own Chrome) is a `launch_error` row, and the
  rest of an `--all` run carries on. `--json` prints JSON on every path, including errors.
- **`gflow credits user|list --refresh` renews expired sessions again.** Since #802, an expired
  session fails the credits read without opening a browser. That is the right default, because
  re-asking aisandbox-pa with the same Bearer cannot change its answer. It also removed the only
  automatic renewal that `credits list` used to give stale profiles. `--refresh` brings it back as
  an opt-in. A profile whose fast path raises an expired-session error is renewed through
  `auth renew` and asked again, while the others are untouched. A failed renewal keeps the
  original diagnosis. The MCP twin is `gflow_get_credits(refresh=true)`. The credits 401 hint
  now points at `--refresh` / `gflow auth renew` instead of "check your balance in Flow"; an
  account whose labs session issues no token at all is not helped by renewal, and says so.

### Changed

- **The agent-only composer is recognised after 5 s**, not after the full 30 s readiness wait.
- **Image downloads accept `flow.google.com` URLs, and now check where redirects end.** The
  agent-only composer's `/asb/` image URLs redirect to `lh3.google.com`; a download whose
  redirects end on a host outside Google's allowlist (or on plain `http`) is refused before
  anything is written.
- **A run on the agent-only composer that times out after submit is `retryable: false`.** The
  request was already sent, so an automatic retry would submit (and for a video, bill) again.
- **Refusals before the page opens now require that neither composer supports the request.**
  `--aspect 3:4` was refused up front because the classic settings pane has no 3:4 option; the
  agent-only pane does.

### Fixed

- **`gflow video extend --json` prints one JSON document.** The human plan preamble no
  longer precedes it on stdout, and the payload now carries the same `video_result` fields
  as `t2v`/`i2v` (`status`, `succeeded`, `media_id`, `local_path`, `request.mode`). On
  flow.google.com `--output` saves the new extension clip; on labs.google it still renders
  the whole scene.
  (#882, @stgmt)

## [0.85.0] — 2026-10-14

### Added

- **`@Character` mentions work for images on flow.google.com (#723).** On an account Flow
  serves from `flow.google.com`, `gflow image t2i "@Sussy …" --project <id>` (and `i2i`)
  used to exit 29 (the character catalog's labs route answers 401) or exit 36 (character
  references not ported). When the catalog is unreadable, an image mention that matches
  no media becomes a character named by the **first word** after `@` (multi-word names
  still need the catalog). The composer attaches it through its `@` picker. Character
  and media options look identical in the DOM, and a generated image captioned with the
  character's name can outrank it, so gflow commits the one option whose title equals
  the name. It refuses before submit (exit 32) when none or several do, or when the match
  is media. Nothing is committed on trial: a chip deleted from the prompt still went
  into the generation. The `ogiZ0b` submit must carry exactly the requested references
  plus the character, or it is aborted. The MCP image tool takes the same path through the
  worker. A `--reference-entity` id without a `--reference-entity-name` still exits 36
  there (the picker finds characters by name), and on a page served labs a character
  known only by name exits 29, since that picker attaches by id. **Video is
  unchanged**: on `video t2v`/`r2v` there, `--reference-entity` still exits 36 and a
  `@Name` exits 29 (the catalog is unreadable on that host).

### Fixed

- **`gflow image t2i --project-name` titles a multi-prompt run's project (#975).** With
  several prompts (positional, `--prompts-file` or `--stdin`) the option was accepted and
  then dropped: the shared project was always titled `gflow-cli t2i`. It now gets the name
  you pass, as a single-prompt run does; with `--project` no project is created, so the
  name is not used. The MCP image tool takes one prompt, so there is nothing to mirror.

## [0.84.0] — 2026-10-12

### Added

- **`gflow run --project ID` generates a batch into an existing Flow project (#970).** Every
  run used to create a new project titled `gflow-cli run`, so a user who keeps their
  images in one project had to fall back to one `gflow image t2i --project` call per
  prompt. `--project` (or a top-level `"project"` key in the config; the CLI wins) now
  runs every row in that project and creates none, and a title already in the local
  catalog is kept, as with `t2i --project`. `gflow run` has no MCP twin yet, so
  there is no MCP option to mirror.
- **`gflow image t2i` takes `--project` with several prompts (#971).** A multi-prompt run
  (several positional prompts, `--prompts-file` or `--stdin`) used to reject
  `--project` as single-prompt only; it now runs every prompt in that project and
  creates none, on the same path as `gflow run --project`. `--reference-entity` stays
  single-prompt only. The MCP image tool takes one prompt, so there is nothing to
  mirror.

## [0.83.2] — 2026-10-11

### Fixed

- **`--duration` failed before submit on a Flow account whose UI is not in English
  (#963).** On `flow.google.com` the duration radio was matched on its exact English
  label (`8s`), so a Vietnamese pane reading `8 giây` matched nothing and every run with
  `--duration` stopped with exit 11, before any credit was spent. The radio is now matched
  on its number, refusing a `4K`/`480p` sibling that shares the leading digit. CLI and MCP
  share this transport, so both are fixed.

- **A notice-only cookie bar blocked every run on `flow.google.com`, at exit 23.** Some
  languages are served a consent bar with only an *OK, got it* button and no reject
  option; the driver looked only for reject, so the bar stayed over the settings control.
  It now clicks reject where the bar offers one and acknowledges the notice only when it
  does not. Found while live-checking #963 under a Vietnamese UI.

- **`gflow image upscale` on `flow.google.com` failed with *Element is not attached to
  the DOM* (#957).** The image tile and the download button were held as element handles
  resolved once, and Flow re-renders the grid after it first appears, so the click landed
  on a detached node. They are now Playwright locators, re-resolved on every action. Video
  upscale opens its download menu through the same helper, so it shares the fix; the MCP
  tools call the same transport. Image upscale was verified live on the CLI and over MCP.

- **`gflow auth status` reported a migrated account as not signed in to Flow on hosts
  without Google Chrome (PR #962, by @mohaidoss).** For a `flow.google.com` account, the migrated-host probe opened
  the profile with a hard-coded `channel="chrome"`. Playwright resolves that only to
  `/opt/google/chrome/chrome` on Linux. On a host with just the bundled Chromium the launch
  raised, the probe logged `auth_migrated_fallback_probe_error`, and status printed
  *"Signed in to Google, but not to the Flow app"*, even though generation, which picks its
  channel with `channel_for_profile`, ran fine on the same profile. The probe now opens the
  profile with that same resolver and runs the #477 engine-downgrade guard first.

## [0.83.1] — 2026-10-08

### Fixed

- **The default image model failed on `flow.google.com` once Flow moved to Nano Banana 2.1
  (#958).** Flow replaced "Nano Banana 2" with "Nano Banana 2.1" in the migrated model menu,
  and the submit now carries `BELUGA` where it carried `NARWHAL`, so the submit guard refused
  every `nano2` run (the default) with exit 7: *the image submit body does not carry requested
  model NARWHAL*. `nano2` now accepts that token; upgrade with `gflow update`. On an older
  version, `--model nano-pro` or `--model nano2-lite` still works. Measured on two
  accounts on that host: 2.1 replaced 2 rather than appearing beside it, and Flow's
  catalogue there no longer lists `NARWHAL`. Found and first fixed by @omid-io.

## [0.83.0] — 2026-10-07

### Added

- **Image and video upscaling on the migrated `flow.google.com` frontend (Refs #914).**
  `gflow image upscale` now drives the migrated editor's download menu via the `SPrCad`
  batchexecute wire, decoding the upscaled JPEG directly without hitting the legacy
  aisandbox REST route (2K captured live; 4K is driven the same way but was only seen
  disabled, on a non-Ultra account). The menu item is picked by its resolution token
  (`2K`, `1080p`), which was measured identical across locales, never by its label.
- **`gflow video upscale` command.** Upscales or exports platform-generated videos to 1080p
  Full HD, downloads the original 720p, or exports a 270p animated GIF, on
  `flow.google.com` only (`GFLOW_CLI_FLOW_HOST=labs.google` refuses it, exit 36). The
  1080p export was measured free (1 observation, 2026-10-07), and the saved MP4 is checked
  to really be 1080p so a preview or the 720p original is never written as the export.
- **MCP tools `gflow_upscale_image` and `gflow_upscale_video`.** Exposes image upscaling
  and video upscaling/export over the MCP interface with full catalog resolution.

### Changed

- **Proactive 4K tier detection.** On accounts below the Ultra tier, 4K image upscaling
  detects the disabled UI state and fails fast with exit code 22 (`UpscaleUnavailableError`),
  advising `--scale 2k`, without waiting for an API 403. A missing menu item raises
  `UiSelectorDriftError` (exit 23) instead.

### Fixed

- **`gflow video upscale --scale 270p` no longer gives up while Flow is still rendering the
  GIF.** Flow renders the animated GIF in the page, and the delay varies: measured on
  2026-10-07, once 40 s, once a 104 s run, and once past the 120 s that MP4 exports get. A
  270p export now waits up to 5 minutes. A timeout now says to re-run (an export spends no
  credits) instead of the generic "a single API call exceeded the 30 s deadline".
- **flow.google.com video runs no longer fail after Flow has billed them (#948).** Since
  about 2026-10-05, Flow sends `null` in the generation record's fourth slot, where it
  used to send `"CAE"`. gflow located the record by that marker. As a result,
  migrated-host video submits (reported on t2v, i2v and r2v, and reproduced on t2v) were
  accepted and billed, but then exited 7 with `no generation record` and never
  downloaded. The same marker also stopped `gflow data download` from recovering those
  clips. Records are now matched by their three ids and their details block, whatever
  slot 3 holds. Measured on our own account, the submit (`YhhmEf`) and status (`jwpduf`)
  replies are otherwise unchanged. If the record is still missing, the error now says
  the run may already be billed, instead of suggesting a retry. Re-run after the fix on
  t2v (`YhhmEf`), i2v (`eb1hJf`) and r2v: each ended in a downloaded mp4.
- **gflow picks its own clip's record out of a reply that lists several.** A
  flow.google.com reply can carry several generation records; the project-load reply
  carries one per clip. gflow decoded only the first, then discarded the whole frame if
  that record was another clip's. It now selects the record by its own workflow id
  during a run, or its media id in `gflow data download`. `data download` now reads only
  the clip route's `as29s` reply. The project listing carries the same clip's record with an
  unsigned link that answers HTTP 302 (measured). Whether the multi-record case caused the
  one unexplained post-submit timeout seen while fixing #948 was not measured.

## [0.82.1] — 2026-10-02


### Fixed

- **A video's Flow workflow id is recorded in the catalog (#898).** It was written as
  `NULL` for every clip. As a result, the MCP task result's `flow_workflow_id` was always
  `null` for a video, and a clip could not be looked up by its workflow id. On
  flow.google.com the id now comes from the generation record (slot 0, the id Flow polls
  the clip by); on labs, from the generate reply's `media[0].workflowId`, which is not the
  operation name already stored as `flow_operation_id`.
- **Recording a started video twice no longer crashes (#898).** A second start for a
  media id already in the catalog minted a fresh row id and hit
  `UNIQUE(profile_name, flow_media_id)` (`DataIntegrityError`). A start for a media id the
  catalog already holds is now a no-op, so it cannot reset a completed clip to `pending`.
- **A busy catalog no longer turns a successful generation into a failed one (#900).**
  When another gflow process held the local database's write lock past the 5 s
  `busy_timeout`, recording a finished clip raised a raw `sqlite3.OperationalError`. That
  missed every handler that downgrades a recording failure to a warning, so `gflow video`
  exited 1 ("unexpected error") for a clip that existed and was paid for, and tried to
  record it as failed. Catalog transactions now raise `DataStoreError`, so `gflow image`
  and `gflow video` succeed and log a `data.persistence_failed_after_success` warning
  naming the media id. Outside a successful generation the same failure exits 16
  instead of 1.
- **A reCAPTCHA mint failure is a typed error with Problem Details (#915).** It was a bare
  `RuntimeError`: `gflow image upscale` and `gflow video extend` (and image generation on
  the experimental HTTP transports) exited 1 with an "unexpected" message and no
  remediation, an MCP/worker caller got a hashed "Unknown Error", and on an experimental
  transport one failure ended a multi-prompt run past `--continue-on-error`. It now has its
  own `type` (`…/errors/recaptcha-mint`) and a `retryable` flag set from a live measurement:
  a mint that lost a race with a navigation, or ran on a Flow page before Flow injected its
  reCAPTCHA script, is retryable (the settled page mints); a mint on a page that is not a
  web page (`about:blank`) is not (it fails the same way every time); an empty token, never
  observed, keeps the class default (not retryable). It still exits 1 —
  branch on the `type`. The site-key message no longer blames "the Flow editor page" or "the
  script tag layout", which was false on the `about:blank` page where it was seen (#891).

## [0.82.0] — 2026-10-01

### Added

- **A `gflow run --config` row can reference a local image file (#913).** Set `"ref"` to a
  path, resolved against the config file's folder. The file is checked before the browser
  starts (it must exist and be a real image). It is uploaded once per run, on first use;
  every row naming the same file references that upload in place, so the project holds
  one copy. See [docs/USAGE.md](docs/USAGE.md#referencing-a-local-file).
- **A `gflow run --config` row can generate from an earlier row's image (#913).** Set
  `"ref": "batch:N"`. The earlier image is already in the run's Flow project, so it is
  referenced in place by the handle Flow returned. Nothing is re-uploaded, and the
  project holds no duplicate. Rows run in file order, deferred only until
  their parent has run. A failed parent skips its dependents with the reason instead of
  submitting them without the reference. A referenced row must make one image. On
  flow.google.com the image is found in the composer's `@` picker and chosen by its
  thumbnail identity, not its caption (captions repeat). The submit is aborted before
  Flow acts if it does not carry the reference. `gflow image batch` refuses references and
  points at `gflow run`. See [docs/USAGE.md](docs/USAGE.md#referencing-an-earlier-row).
- **`gflow run --config` and multi-prompt `gflow image t2i` now record their successful
  generations in the local catalog.** They recorded failures only. A referencing row is
  recorded as image-to-image with its parent as the input.


### Fixed

- **Manifest references are refused instead of silently ignored (#913).** A
  `gflow run --config` or `gflow image batch` row with `ref` or `reference_entity` was
  accepted, then ran as plain text-to-image with exit 0. v0.52.0 announced the fields
  (#317), but nothing ever applied them. Both commands now refuse such a row before any
  browser work, naming the row and field: exit 11 for `run`, a usage error (exit 2) for
  `image batch`. The exceptions are `"ref": "batch:N"` and a local image file in
  `gflow run --config`, which now work (see Added).

- **The docs no longer suggest clearing a sign-in screen in the generation window
  (#925).** 0.81.0's docs said to make the off-screen generation browser visible and
  clear an account chooser or consent screen in it. A generation run gives up about 30 s
  after it clicks the chooser row, so that was a race. It also contradicted the error
  itself, which says to run `gflow auth login --profile <name>`. The login window is
  always visible and waits for you, so that is the remedy the docs now give.
  `GFLOW_CLI_BROWSER_WINDOW_POSITION` remains for watching or debugging a run.

## [0.81.0] — 2026-09-30

### Added

- **The generation browser opens off-screen (#923).** Headed Chrome is required, so until
  now every `image`/`video` run put a Chrome window over your desktop. It now opens at
  `-30000,-30000`. It is still fully headed, so Flow and reCAPTCHA see the same browser.
  Image and video generation were measured unchanged, and the page is not throttled.
  `GFLOW_CLI_BROWSER_WINDOW_POSITION` takes any `X,Y` to place it where you want (to watch
  a run or clear a consent screen by hand); empty restores Chrome's own placement. It
  does not stop Chrome taking keyboard focus at launch. Login windows are unaffected. See
  [docs/CONFIGURATION.md](docs/CONFIGURATION.md#gflow_cli_browser_window_position).
  Thanks to @johngbl for the idea and the first implementation.

### Security

- **Locked `urllib3` 2.8.0 (CVE-2026-97687, CVE-2026-97688, CVE-2026-97689).**
  Transitive only — via `requests` and, with the `s3` extra, `botocore`. No gflow
  code imports it directly.


### Fixed

- **Windows profile write-denial is distinguished from browser contention.** When
  the generation client's browser launch fails with a Chrome `ProcessSingleton`
  error carrying Windows access-denied code 5, it now raises `ProfileAccessError`
  (configuration exit code 11) instead of a misleading "another Chrome holds it"
  `ProfileLockedError` or an unclassified error. The match is on the error code,
  so it works in every Windows display language. The remediation points to
  profile-directory write access, not to closing a competing Chrome. Not covered
  yet: `gflow auth login` / auth verification, and the standalone and experimental
  transport launches — those still surface Chrome's raw error.
  Thanks @L1meSn0w for the diagnosis and the Windows reproduction (#919).

## [0.80.0] — 2026-09-29

### Security

- **Locked `oauthlib` 4.0.0 (CVE-2026-49265) and `pyjwt` 2.15.1 (CVE-2026-102274).**
  Both are transitive: `oauthlib` via the `gcs` extra (`gcsfs` → `google-auth-oauthlib`
  → `requests-oauthlib`), `pyjwt` via `mcp[crypto]`. No gflow code imports either directly.

### Added

- **Explicit video resolution control (`--resolution [360p|720p]`, #787).** Added `--resolution`
  to `gflow video t2v`, `i2v`, and `r2v`, as well as MCP tool `gflow_generate_video`.
  Enables explicit selection of `360p` or `720p` on models providing resolution controls
  (such as `omni-flash`), preventing unintended defaults.
- **Support for Nano Banana 2 Lite (`--model nano2-lite`, #787).** Added `nano2-lite` alias mapped
  to Google's internal `HARBOR_SEAL` wire model for `gflow image t2i`, `i2i`, and `batch`. Its I2I reference
  cap starts at 3 because it has not been measured yet, and its daily quota is
  unmeasured too ([spike](docs/superpowers/spikes/2026-09-11-nano2-lite-capability.md)).


### Fixed

- **An unported image form is refused by name, on a fresh or a reused client (#891).**
  The browser transport no longer pre-mints a reCAPTCHA token for images: Flow's page
  mints its own, and the client's token was never read. After a successful image the
  pre-mint ran on the parked `about:blank` page and turned exit 36 into a misleading
  `RecaptchaError`. The refusal now comes from the composer and names the form, e.g.
  "the IMAGEN_3_5 model is not ported yet". Reachable from `gflow run --config` with a
  per-prompt `imagen4` after a successful prompt: that run used to crash with exit 1 and
  lose its results table; now the prompt fails by name and the run completes. This
  corrects the 0.78.0 note that project-less image runs "keep the served host": the
  client creates the project first, so they are served by the migrated composer. The HTTP
  image transports still mint.
- **A clip whose download connection dropped is no longer recorded as never generated
  (#896, #898).** When Flow reports a video done but the signed-media connection drops
  on every retry, the catalog now marks the asset `MEDIA_GENERATION_STATUS_SUCCESSFUL`
  rather than leaving it `pending` forever. The operation's `error_type` is
  `media-download` (still exit 6), so `gflow data list errors` tells a lost transfer from
  a failed generation. `gflow data list videos` gains a `STATUS` column and a `status`
  field in `--json`. An HTTP error answer on the signed URL still leaves the asset
  `pending`. **Changed:** that failure's Problem Details `type` is now
  `…/errors/media-download` (a subclass of the `network` error, same exit code).
- **A generation flow.google.com refuses is now reported as that refusal, by name (#906, #873).**
  Flow answers a refused submit with HTTP 200 and a `batchexecute` error envelope carrying
  Google's reason (`PUBLIC_ERROR_UNUSUAL_ACTIVITY`), but gflow's parser discarded any frame
  without a payload. So a refusal ended as a retryable 60 s video timeout (exit 9) or an image
  "no ogiZ0b frame" wire fault (exit 7), whose remediation tells you to file a frontend bug.
  It is now `WafRejectionError` (exit 10) — the class the labs path has always used for the same
  reason — with a remediation that says the prompt is not the cause and nothing was charged. The
  content-safety reasons map to `ContentPolicyError` (exit 5) as on the REST path. Read from the
  wire, not from the grid's failure card, which looks identical for a refusal and an aborted
  submit ([spike](docs/superpowers/spikes/2026-09-27-migrated-refusal-is-on-the-wire.md)).
  The refusal was observed live on the image submit; the video submit reads the same framing
  and is covered offline, but a live video refusal has not been captured yet.
  Diagnosed by [@stgmt](https://github.com/stgmt) in #873 and #906; this change supersedes
  #873 and the refusal-card half of #907.

- **`gflow auth login` no longer reports success while Google is waiting for the account to
  "Confirm it's you" (#902).** In that state the cookies stay valid, so the session probe
  answered in 0.4 s and the login closed Chrome before Flow's client-side hop to
  `flow.google.com/about` could land. It then printed `[OK] Flow session verified` on an
  account where every command still exited 31. The login now watches a `flow.google.com`
  landing for up to 3 s before it closes. If Flow routes the page to `/about`, Chrome stays open
  and the user is told to press the page's main button and finish Google's check. Closing the
  window or running out of time in that state exits 12 with the new
  `IdentityRecheckPendingError`. The #849 on-disk check is skipped in that case, because it reads
  the same healthy cookies. A labs-served login closes as fast as before. The failing state is
  tested offline only: the one account measured in it (2026-09-23) had already been cleared by
  hand, and none of the profiles here is in that state now.

## [0.79.1] — 2026-09-22


### Fixed

- **A finished, billed clip is no longer thrown away when its download hits a connection
  reset (#895).** The signed-media GET was issued once, with no retry: a single
  `ECONNRESET` mid-transfer failed the whole command *after* Veo had produced the clip and
  charged for it — reported at 2 failures in 6 consecutive runs. The transfer now survives
  a dropped connection using Playwright's own `max_retries`, which retries on the driver's
  `ECONNRESET` and never on an HTTP status, and whose backoff is charged to the same
  timeout rather than multiplying it: three attempts stay inside one ~180 s budget instead
  of stretching to nine minutes on a lock shared with every other generation. Measured
  with an A/B control, not read from the docs —
  [spike](docs/superpowers/spikes/2026-09-22-playwright-max-retries-econnreset.md).
  Fixed at **all three** download sites, not just the one the traceback named: the
  migrated composer, `gflow data download`'s own recovery GET (so the escape hatch cannot
  be stranded by the fault it exists to rescue), and the labs `media.getMediaUrlRedirect`
  path.
- **A lost transfer now says the clip survived, instead of `Unexpected error` (#895).**
  `playwright.async_api.Error` is not a gflow error class, so it escaped the typed-error
  contract entirely and rendered as *"Unexpected error … exit code 1, retryable: False"* —
  of which the last two are wrong and the first is useless. It is now `NetworkError`
  (exit 6, correctly retryable) carrying the media id and `gflow data download <id>`, so a
  user is not left re-generating a clip they already own. The exception message is
  deliberately **not** forwarded into `detail`: Playwright concatenates its server-side
  call log into it, and `detail` reaches stderr and `--json` stdout without passing
  through redaction, so a signed URL would leak. Both MCP twins gain this for free — until
  now `gflow_download_media` returned *"Unexpected Error; details were logged
  server-side"* with no remediation field at all, and the queued `gflow_generate_video`
  path returned `detail: "sha256:<hash>"` with neither `remediation_hint` nor `retryable`.
- **A failed generation now keeps its media id on the queue row, so an MCP agent can
  actually recover the clip (#895).** The remediation added above names the media id and
  tells the user to recover it — but over MCP that advice was unusable. The worker's
  success branch recorded `flow_media_id` on the queue row; the failure branch did not,
  so the row stayed `NULL` and `gflow_generate_video`'s failed envelope carried no id at
  all. The agent's only copy was a UUID buried in an English sentence, suggesting a
  *shell command* an MCP client cannot run, when its actual tool takes `media_id=`.
  `update_task_status` already COALESCEs, so a task that failed before Flow named
  anything still records nothing.

- **An expired signed link stops blaming your prompt (#895).** A late GET answers 4xx, and
  every one of those branches fell through to `WireFormatError`'s class default — *"retry
  with a simpler prompt text"* — on paths that carry no prompt and no payload. The same
  wrong-advice class removed in #875. Each now names the short link lifetime and the
  credit-free re-mint.
- **The labs video download verifies where its redirect landed (#895).** That route is a
  302 by design, so it follows up to 5 hops, and nothing checked the final host — the
  posture the migrated arm gets from refusing redirects outright. The bytes are now
  refused unless the landing host is an allowed Google host.
- **A retired labs route no longer tells you to simplify a prompt you never wrote.**
  Every labs tRPC route except project-create now answers HTTP 404 with Flow's own
  explanation — *"Flow RPCs have been deprecated and disabled. Flow has migrated to
  https://flow.google.com."* — and gflow surfaced it as a bare `WireFormatError` (exit 7)
  carrying the class-default advice: check the payload, retry with a simpler prompt, file
  a bug. All three were wrong. The payload is fine, `gflow character list` is a read with
  no prompt at all, and Flow documents the condition in the very body being classified.
  The refusal is now recognised **by that message** — never by which host an account is
  served, and never by a route allowlist, so a route we have not observed yet is covered
  the day Flow retires it — and carries a remediation that names the retired route and
  points at [#639](https://github.com/ffroliva/gflow-cli/issues/639). It deliberately
  suggests **no** setting: `GFLOW_CLI_FLOW_HOST=flow.google.com` was measured not to help
  (2026-09-20, `character list`), because the read has no migrated arm to route to, and
  naming it would repeat the mistake being fixed. The error class and exit code are
  unchanged ([#875](https://github.com/ffroliva/gflow-cli/issues/875)).

- **`KNOWN_ISSUES.md` no longer claims `gflow character list` works on the migrated host.**
  Measured twice on 2026-09-20 — with and without `GFLOW_CLI_FLOW_HOST=flow.google.com` —
  it exits 7 on the retired labs `projectInitialData` route both times. `list_characters`
  reads that route unconditionally and has no migrated path
  ([#875](https://github.com/ffroliva/gflow-cli/issues/875)).

### Changed

- **The nightly canary stops crying wolf about an account that cannot reach Flow.**
  An e2e failure caused by Flow serving its public `/about` landing is now reported as a
  SKIP carrying the measurement, because it is a missing precondition rather than a
  product failure — measured 2026-09-20, `gflow project create` succeeded on two profiles
  and failed only on the canary's in the same minute. Seven of the thirteen standing
  failures in [#559](https://github.com/ffroliva/gflow-cli/issues/559) were this one
  condition, unchanged across three nightly runs, and the noise hid a real finding:
  `test_project_create_e2e.py` shipped in v0.78.0 and had never passed once.
  Test-only ([#888](https://github.com/ffroliva/gflow-cli/issues/888)).

  It narrows deliberately. The guard matches a marker **gflow itself** emits from
  `raise_if_known_landing`, never anything Flow says; a tripwire outside `tests/e2e/`
  asserts that marker against the real raise site so a reword cannot silently disable it;
  and it covers the `public` landing kind **only**. Two transports tests that fail on the
  `signin` kind are left red on purpose — catching `AuthExpiredError` would silence the
  signal an e2e exists to raise.

### Added

- **E2E coverage for the retired-route diagnosis** (`tests/e2e/test_retired_labs_route_diagnosis_e2e.py`,
  `e2e_auth`, 0 credits, one read-only GET). The unit tests for
  [#875](https://github.com/ffroliva/gflow-cli/issues/875) feed the classifier a *captured*
  body, so they stay green if Flow changes the wording, un-retires the route or switches to
  401 — while the user-facing diagnosis silently goes wrong again. This one asks Flow. It
  needs no project fixture (the route is retired before any project lookup) and **skips
  rather than passes** on an account still served the labs tRPC API, so a cohort change
  cannot retire it unnoticed. Verified by falsification: with detection disabled it fails
  with the pre-fix message verbatim.

## [0.79.0] — 2026-09-18

### Added

- **`gflow data download <media_id>` — recover a billed asset whose download failed.**
  A generation that finishes but whose signed media URL is never observed exits 7 with
  the credit already spent: the clip sits in the Flow project, the catalog row says
  `local_path: null`, and no command could fetch it. The only recovery the CLI offered
  was to generate it again and pay twice — and because the failure is a timing window,
  the retry could strand another copy. The new command opens the clip's own route, takes
  the signed URL Flow reports for it, verifies the bytes against the size Flow records,
  writes the file and updates `local_files`. Costs no credits. Mirrored as the
  `gflow_download_media` MCP tool.
  **Video only**, and it says so: the signed URL comes from the `as29s` record Flow emits
  when a clip's own route loads, which an image's route does not carry. An image media id
  is refused immediately with exit 11 rather than opening a browser
  ([#877](https://github.com/ffroliva/gflow-cli/issues/877)).


### Fixed

- **Auth errors on aisandbox routes no longer blame a cookie they never read
  (#803).** `AisandboxAuthError`'s default remediation said *"SAPISID cookie
  missing, expired, or unreadable — re-run `gflow auth login`"*. v0.74.0 corrected
  the two `gflow credits` sites, but the other three raise sites inherited that
  default, so every route through `_run_with_aisandbox_retry` — `createScene`,
  `commitWorkflow`, `createEntity`, `projectInitialData`, `upsampleImage` and the
  rest — still said it. None of them reads SAPISID: the credential is a Bearer
  token minted by labs' session endpoint, and SAPISID's only role is getting that
  endpoint to answer at all. The advice was therefore wrong in every word, and
  costly: on a profile with no browser-strategy marker a failed re-login rolls the
  marker back and starts the #791 loop. Each site now states what was actually
  rejected — a non-JSON reply is named as an interstitial, a token-less session is
  named as the flow.google.com shape, and a 401 after refresh names the route that
  refused it.
- **The migrated host no longer reports a model it never observed (#789).**
  `model_name_type` echoed the requested `--model` back on `flow.google.com`, where
  the `ogiZ0b` reply carries no model field at all. `recorder.py` persists that
  value as `AssetRecord.model`, so the echo was read back by `gflow data` as though
  Flow had confirmed it — and with a hidden model picker (#788) the model actually
  selected can differ from the one requested, making the echo wrong on the single
  field a user would check to find out. It is now `null` on that host, and typed
  `str | None`. On `labs.google` it is unchanged: Flow's own value, from Flow's own
  reply.
  ([#865](https://github.com/ffroliva/gflow-cli/issues/865),
  [#871](https://github.com/ffroliva/gflow-cli/issues/871))

- **`gflow data download` refuses an image immediately instead of blaming the project,
  the trash and your prompt (#877).** Recovery is video-only: the signed URL comes from
  the `as29s` record Flow emits when a clip's own route loads, and an image's route does
  not carry one. The command accepted an image media id anyway, launched Chrome, waited
  45 s, and then produced three guesses — wrong project, clip in trash, *"retry with a
  simpler prompt text"* — for a condition the catalog row states outright, on a command
  that has no prompt. It now checks `kind` before anything else and exits 11 saying
  recovery is video-only. The CLI help, the `gflow_download_media` MCP description and
  `docs/USAGE.md` all said "asset"; they now say video. The timeout message that remains
  for a genuine video miss drops the inherited generation-payload remediation and
  describes what to actually check.

## [0.78.0] — 2026-09-17

### Added

- **`--aspect 3:4` images now run on `flow.google.com`.** Flow's image settings there
  render a fifth aspect radio (`3:4`) that the 2026-09-08 enumeration did not see, so gflow
  refused it with exit 36. All five image aspects are now driven on both hosts.
  ([#864](https://github.com/ffroliva/gflow-cli/issues/864))

- **`gflow docs` — the documentation, reachable from the terminal.** 126 pages in `docs/`
  and nothing in the CLI pointed at any of them, so at the moment of use the knowledge was
  unreachable and the reader guessed. `gflow docs` lists the topics, `gflow docs <topic>`
  prints one as raw Markdown (it pipes), and `gflow docs --search <term>` returns the
  matching lines with `docs/FILE.md:LINE` beside each one. Read-only and offline — no
  network, no account, no credits.

  **The pages now ship inside the wheel** (`gflow_cli/_docs`; 1.3 MB of Markdown, **+0.58 MB
  compressed** — the wheel goes 0.74 MB → 1.32 MB), because the user this was filed for
  installed from PyPI and has no checkout; a command that could only print GitHub links
  would not solve it. A build hook globs `docs/*.md`, so the topic list cannot drift and
  `assets/`/`superpowers/` stay out — measured, after `force-include` + `exclude` silently
  shipped 148 files it was told to exclude. The hook **refuses to build** when it finds no
  pages: `Path.glob` on a missing directory returns empty, and `release.yml` is `uv build`
  then publish, with nothing in between that would notice a wheel whose `gflow docs` is
  empty for every user.

  Search returns a **line, windowed**, not a file name: the rule that prompted this issue
  lives inside a 4 000-character bullet in `MCP.md`, and answering "it is in MCP.md" leaves
  the reader where they started. Curated `INDEX.md` § Topic shortcuts rank above raw body
  text, all query terms must appear on the line, and a vague query reports how many hits it
  held back instead of quietly truncating. A topic resolves from its slug, its file name,
  either case or an unambiguous prefix — and never by building a path from what was typed,
  so `gflow docs ../../etc/passwd` is an ordinary unknown-topic refusal.

  No MCP twin, deliberately (`gflow update` is the precedent); the reasoning is recorded in
  `cli_docs.py` rather than left implicit.
  ([#861](https://github.com/ffroliva/gflow-cli/issues/861))

- **`gflow video i2v --end-frame <local file>` now runs on `flow.google.com`.** Start+end
  frame interpolation was the last i2v form the migrated composer refused: it exited 36
  ("an end frame is not ported yet") on every account Flow has moved. Both frames are now
  uploaded through the editor's own Upload entry and bound to the Start and End chips, and
  the driver reads back two bound chips before it lets the app submit.

  A bound end frame switches Flow to a different submit contract — rpc `nprQif`, an
  interpolation model key, and both media ids in the body — which is why watching only the
  classic submit rpcs made every start+end run time out *after* Flow had already accepted
  the submit and billed it. The submit body is asserted before Flow acts on it, so a frame
  that silently failed to bind is a refusal rather than a wrong generation you paid for.

  The model key is **cohort-dependent** and matched by shape, not by literal:
  `veo_3_1_interpolation_lite` and `omni_flash_i2v_8s_first_last` have both been captured
  on live accounts (the second on 2026-09-17, see
  `docs/superpowers/spikes/2026-09-17-migrated-end-frame-submit-contract.md`). Frames given
  by media UUID or `@Name` are still not ported.
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639))
- Migrated image submits prove the composer before any network observer arms:
  cookie-bar dismissal, blocking-overlay refusal, and submit pointer hit-test,
  each raising typed `UiSelectorDriftError` with bounded redacted diagnostics
  instead of bare Playwright timeouts.


### Fixed

- **The Frames picker could not bind the frame it had just uploaded.** On
  `flow.google.com`, `video i2v` matched a picker option with an *anchored* regex
  (`^\s*<name>\s*$`), but a picker tile is a `mat-icon` ligature followed by the file
  name and a locator reads both nodes as one string — `imageshero-ab12cd34.png` for an
  asset named `hero-ab12cd34.png`. The anchors could never hold, so every i2v run on this
  cohort ended in exit 32, *"the frame picker lists no asset named …"*, while the picker
  had been listing it the whole time. The match is now containment on the display name,
  which is run-unique by construction ([#792](https://github.com/ffroliva/gflow-cli/issues/792))
  and therefore still cannot bind a stale copy of the same file. Covered by a new $0
  route-intercepted e2e (`tests/features/frame_picker_binding.feature`) that renders the
  icon node for real — a mocked picker passes against the bug.
  ([#860](https://github.com/ffroliva/gflow-cli/issues/860))

- **Flow's promo modal blocked the first click on a freshly loaded editor.** On
  `flow.google.com` a `role="dialog"` panel over a new editor made `image t2i` fail as
  exit 23 — *".settings-trigger-button did not accept a click within 5000 ms — it is
  covered by div.cdk-overlay-backdrop"* — telling the user to file a selector-drift bug
  when one click on the page fixes it permanently.

  `_dismiss_dialog` already existed and its selector already matched. It was called at
  the one moment it could not see anything: one frame after `domcontentloaded`, before
  Angular has rendered the modal. That is why a blocked run logged **neither**
  `migrated.dialog_dismissed` nor `migrated.dialog_not_dismissed` — the silence in the
  incident's event stream was the evidence, not the absence of it. The dismissal now
  also runs in `_open_pane`, where the image and video paths take their first click, the
  same place the `glue` consent bar is already cleared. It stays best-effort: a modal
  that refuses to go still falls through to the click post-mortem, which names the
  backdrop, rather than becoming a second competing error path.
  ([#859](https://github.com/ffroliva/gflow-cli/issues/859))

- **The migrated `--end-frame` lane rejected omni's interpolation key.** The start+end
  submit validator pinned the model key to `veo_3_1_interpolation_lite`, so
  `omni_flash_i2v_*_first_last` submits — what the second measured cohort actually sends —
  were refused as wire-format errors before Flow could act on them. The check is now
  key-shape based: a submit whose model key contains `interpolation` or `first_last`
  counts as start+end interpolation for any model, and the submit observer accepts the
  bare `batchexecute` reply (no `rpcids` param) that the interpolation rpc answers on.
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639))
- **Generating without a project works again on accounts Flow serves from
  `flow.google.com`, and it no longer tells you to log in.** Every run without `--project`
  (CLI) or `project` (MCP) starts by creating a project through labs.google's
  `project.createProject`. Google has retired that route: it answers *"Flow RPCs have been
  deprecated and disabled"* (404), or 401 for a session holding no labs token — measured
  12/12 on four profiles. gflow reported the 401 as *"Authentication expired — run `gflow
  auth login`"*, which no login could fix. When that route refuses, gflow now creates the
  project on flow.google.com's projects page and reads the new id and title from Flow's own
  reply; `gflow project create` and `gflow project rename` work there the same way.
  `GFLOW_CLI_FLOW_HOST=labs.google` keeps the labs route and its error. Video runs without a
  project now get it created up front, like images, so they route exactly as if you had
  passed `--project`; MCP `gflow_generate_video` also honours `project_name`, which it
  accepted and then ignored. Thanks to @iceblue03 (#863) and @ChandraLiuswanto (#561) for
  the reports. ([#864](https://github.com/ffroliva/gflow-cli/issues/864),
  [#561](https://github.com/ffroliva/gflow-cli/issues/561))
- **An MCP server no longer fails a call because another call holds the profile.** Two
  calls on one profile inside one server — a client retry, two agents sharing a server —
  now run one after the other instead of the second failing with `ProfileLockedError`, and
  a profile held by another process (a CLI run) is waited out for up to 180 s. A
  `GFLOW_CLI_LEASE_WAIT_SECONDS` you set yourself, in the environment or a `.env`, still
  wins. The CLI keeps failing fast. Thanks to @iceblue03 (#862).
  ([#864](https://github.com/ffroliva/gflow-cli/issues/864))
- Image requests that the migrated composer serves, with a named project,
  from a pre-navigation page prefer the migrated host on `auto`, so the
  page-owned recaptcha path wins the post-goto handoff race instead of a
  doomed pre-navigation mint (#692). Labs editors, unported forms, and
  project-less runs keep the served host (and their pre-minted token); the
  `labs.google` kill-switch behavior is unchanged.

## [0.77.1] — 2026-09-17


### Fixed

- **A clean Windows install could not run a single command.** `configure_logging`
  renders TEXT logs with `structlog.dev.ConsoleRenderer(colors=True)`, and structlog's
  Windows `_init_terminal` raises `SystemError` outright when `colorama` is missing —
  but `colorama` was never declared, and nothing in the runtime closure supplies it
  (structlog keeps it an optional extra; rich ships its own Windows console handling).
  Because the call sits in the Click *group* callback it runs before any subcommand
  body, so every interactive command on a fresh Windows install aborted with a
  traceback that named structlog and never gflow — the failure read as a broken
  install rather than an incomplete one, and it made the README's Windows quick-start
  fail as written. Piping stderr happened to escape it, since `AUTO` then resolves to
  the JSON renderer, which is why non-interactive use and CI never saw it.

  The only `colorama` edge in `uv.lock` came from **pytest**, a dev dependency — so
  every developer machine had it transitively and no gate could see the gap.
  `colorama` is now a declared `sys_platform == "win32"` runtime dependency, and
  `tests/test_observability.py` fails if it is dropped again. Reproduced and verified
  on a clean Python 3.13 venv: the same `gflow doctor` invocation that raised
  `SystemError` before now runs to completion, on both the CLI and the MCP stdio
  server. ([#846](https://github.com/ffroliva/gflow-cli/issues/846))
- **The address scan in the migrated-host session probe was quadratic.** It reads a
  1.28 MB `myaccount.google.com` response, and `[\w.+-]+@…` retries from every start
  position and rescans its run before failing to find an `@` — so an unbroken run of
  characters that class accepts cost O(n²). Measured: 5 000 chars 0.12 s, 10 000 0.48 s,
  20 000 2.00 s, **40 000 12.07 s**. The class covers the entire URL-safe base64 alphabet,
  which a Google page is full of, and the scan runs synchronously inside an `async def`,
  so a stall blocks the event loop and cancellation cannot land until it returns.

  Anchoring on the literal `@` (which lets CPython's `re` use its literal-prefix fast
  search) and reading the local part backwards over a bounded 64-character window — the
  RFC 5321 cap — makes the work proportional to the number of `@` in the document. Same
  output for every address shape, including the Workspace and custom domains that #791
  turned on: 40 000 chars now scan in under a millisecond, and 440 000 base64-shaped ones
  in 0.2 ms. ([#852](https://github.com/ffroliva/gflow-cli/issues/852))
- **The sign-in window never closed for an account Google serves from `flow.google.com`.**
  `gflow auth login --browser chrome` watches the `labs.google` session endpoint to know
  when to close Chrome — and for a migrated account labs hands off without ever minting a
  session, so the one oracle the detector had could not answer. The window stayed open for
  the full 600 s while the banner promised gflow would close it, and the timeout then
  propagated *past* verification, so a sign-in that had completed perfectly was discarded
  unread and the user got exit 12 for a login that worked. It is the first thing a new user
  on a migrated account meets. v0.77.0 fixed the *verification* for these accounts, which
  made the outcome correct only for users who closed the window themselves.

  Two changes, and neither of them moves the authentication decision into a cookie. gflow
  now also stops waiting when the jar carries both halves of a migrated session (the
  `.google.com` SSO cookie **and** the `flow.google.com` app-session cookie) — that ends a
  wait which had no other way to end; `verify_flow_profile` still asks a server about what
  landed on disk, and is still the only thing that can call a login successful. And a
  timeout no longer discards the profile unread: gflow reads it before failing, reports a
  sign-in the detector missed as the success it is, and otherwise keeps the timeout's own
  wording. A caller with no on-disk oracle to fall back on (`--browser internal`) keeps
  waiting exactly as before. ([#849](https://github.com/ffroliva/gflow-cli/issues/849))
- **`gflow update` could report a version for an install that no longer starts.** A package
  manager replaces files in place, so an interrupted upgrade leaves a venv whose *metadata*
  reads perfectly and whose *imports* are dead. `gflow update` only ever re-read the version,
  so it called that state *"still 0.69.0"* and sent the user to a plain `uv tool upgrade` —
  which cannot repair it, because it reads the same intact metadata, finds it current and
  changes nothing. Measured on Windows: an aborted native-dependency swap left every command
  dying on `AttributeError: module 'greenlet' has no attribute 'greenlet'`, and only
  `uv tool install "gflow-cli==<version>" --force --reinstall` completed.

  After the manager runs, `gflow update` now imports gflow-cli in a fresh isolated
  interpreter *before* it looks at any version, and a failed import is reported as an
  unusable install (exit 11) quoting that interpreter's own last line, with the forced
  reinstall as the remediation. The probe is isolated (`-I`) so a `gflow_cli` directory in
  the caller's working directory cannot answer on the venv's behalf, and a probe that could
  not run at all is never reported as breakage.
  ([#848](https://github.com/ffroliva/gflow-cli/issues/848))

## [0.77.0] — 2026-09-16


### Fixed

- **Accounts Flow moved to `flow.google.com` could not sign in at all.** Verification used
  exactly one oracle — `labs.google/fx/api/auth/session` — which answers `200 {}` forever for
  a migrated account, so a perfectly usable Flow workspace reported *"Signed in to Google, but
  not to the Flow app"* and gflow refused every command. A total lockout, not a degraded
  feature. When labs declines **and** the profile carries a `flow.google.com` app-session
  cookie, gflow now confirms the session against the host that actually serves the app.

  The cookie only **gates** that check; it never decides one. A cookie on disk outlives a
  password change or a "sign out of all devices", so the decision is where the request lands:
  a revoked session is redirected off `myaccount.google.com`, which is server-attested in a
  way page content is not. The account's address is a display label only, so a page reshape
  cannot cost a user their login.

  **Google Workspace accounts are covered.** An earlier revision gated authentication on an
  `@gmail.com`-only pattern, which silently declined every custom domain — `dev@axelate.io`,
  `user@mycompany.com`, even `user@googlemail.com` — leaving this bug open for them while
  appearing fixed. `docs/AUTHENTICATION.md` documents Workspace SSO as supported.
  Live-verified on a Workspace account: `AUTHENTICATED`, correct address, 2/2.

  **This also prevents a profile downgrade.** A failed verification rolled the Chrome marker
  back, flipping `channel_for_profile` from `chrome` to `None` and silently demoting
  generation to bundled Chromium on a profile created with `--browser chrome`. The rollback is
  gated on `not verified`, so a verification that now succeeds never triggers it. Measured
  before and after on the same profile, same cookies: exit 8 / marker gone -> exit 0 / marker
  intact. ([#791](https://github.com/ffroliva/gflow-cli/issues/791),
  [#796](https://github.com/ffroliva/gflow-cli/issues/796))
- **Three lists of "the release version sites" disagreed, and one lived inside the gate that
  catches the disagreement.** `check_repo_hygiene.py`'s docstring said three files, its own
  `_check_version_agreement` checked five (six occurrences), and `skills/release/SKILL.md`
  named a fourth set omitting `server.json` and `uv.lock` — so a release engineer met each
  omission as a gate failure at the point of highest pressure. There are in fact **seven
  sites across three separate gates**, and no list knew them all; coverage was complete, but
  discoverability was not. The skill now carries the one canonical table, its staging step
  stages all seven, and `tests/test_release_version_sites.py` **parses** that table rather
  than restating it — a constant would have been the fourth disagreeing copy.
  ([#839](https://github.com/ffroliva/gflow-cli/issues/839))

### Changed

- **`wait_until="networkidle"` on the `ui_automation` bootstrap is documented, not removed.**
  [#836](https://github.com/ffroliva/gflow-cli/issues/836) proposed dropping it, on the theory
  that a held-open connection made it burn the full 45 s ceiling. Measured on a live profile,
  5 navigations per arm: it fires every time and reached the ceiling **0/5**, so there is no
  hang — but it costs **3422 ms mean against 1022 ms** for the prescribed pattern, with 4x the
  spread. Removing it turned the #580/#584 navigation ratchet red: both call sites are in that
  test's exemption set by name, because `goto(domcontentloaded)` returns 591–797 ms *before*
  Flow's locale redirect lands and `networkidle` is what absorbs it. The issue read two call
  sites with different constraints as one contradiction. The measurement and the probe ship so
  the next reader finds them instead of re-deriving this.

- **The MCP Registry publish never ran — not once, on any release that shipped with it.**
  `mcp-registry.yml` triggered on `release: published`, but `release.yml` creates the Release
  with the default `GITHUB_TOKEN`, and GitHub starts no workflow runs from
  `GITHUB_TOKEN`-created events. Measured on v0.76.0: a real Release published
  (`draft=false`, `prerelease=false`), the workflow file on the default branch, and
  `gh run list --workflow=mcp-registry.yml` returning **zero runs, ever**. The trigger was
  structurally dead rather than mistimed, so it would not have begun working at the next
  release. `release.yml` now **calls** the workflow (`uses:` + `needs: build-and-publish`)
  instead of relying on an event, so there is nothing for the token rule to block. A
  user-owned PAT on the Release step was the alternative and was rejected on maintenance
  grounds: fine-grained tokens expire after at most 366 days, which puts a scheduled failure
  on a path that runs a handful of times a year. `needs:` also enforces the ordering
  `mcp-publisher` requires — it reads the `mcp-name:` token from the *published* PyPI README —
  which previously rested on two files agreeing about step order. Registry authentication is
  unchanged: GitHub Actions OIDC, with no token stored for or handed to the registry.
  ([#841](https://github.com/ffroliva/gflow-cli/issues/841))
- **A manual registry dispatch could publish a superseded version, green, with nothing
  noticing.** A dispatch publishes whatever `server.json` says *on the dispatched ref*.
  Dispatching `develop` after the v0.76.0 tag but before the back-merge landed republished
  `0.75.0` to the registry, and the run succeeded. Both triggers now take a required `version`
  input, asserted against every version field in `server.json`, and fail the run on a
  mismatch instead of publishing. ([#841](https://github.com/ffroliva/gflow-cli/issues/841))
- **A pre-release would have become the MCP Registry's *active* listing.** `release.yml` fires
  on every `v*.*.*` tag, including `v1.2.3rc1`, and that listing is what PulseMCP and GitHub's
  MCP gallery ingest. While the publish was dead this was latent; repairing it would have
  armed it. The call is now skipped for pre-releases, and the workflow refuses a pre-release
  version outright if one reaches it by hand. The prerelease classification has a single
  definition shared by the GitHub Release flag and the registry gate, rather than two copies
  of the same expression that would drift. Found by council review, not in production.
  ([#841](https://github.com/ffroliva/gflow-cli/issues/841))

## [0.76.0] — 2026-09-16


### Fixed

- **The containerised sign-in now works on Windows, and no longer points at a service that
  does not exist.** `docker/docker-compose.yml` hard-coded the X11 socket at
  `/tmp/.X11-unix` and told non-Linux users to "use the VNC service below instead" — there
  is no VNC service; the file defines `login`, `gflow` and `serve`. On Windows 11 + WSL2 the
  display is real but lives elsewhere: WSLg publishes a live `X0` socket at
  `/mnt/wslg/.X11-unix` with `DISPLAY=:0`, while `/tmp/.X11-unix` inside that distro is an
  empty directory, so the default mounted nothing and Chrome exited against a display that
  was not there. The mount is now `${X11_SOCKET:-/tmp/.X11-unix}`, unchanged for Linux, and
  `docker/README.md` documents the WSL invocation plus the two prerequisites that actually
  bite (run it from inside WSL, and enable Docker's WSL integration for that distro).
- **The container image no longer silently installs a stale gflow.** `docker/Dockerfile`
  hardcoded `pip install gflow-cli==0.75.0` with nothing tying it to `pyproject.toml`, so
  the next release would have left the image on the old version while
  `docker/README.md`'s verification table went on quoting the new one. The version is now
  an `ARG` gated by `tests/test_dockerfile_version_pin.py`. That gate also asserts the
  ARG's **position**: declared above the Chrome layer it would invalidate ~1.6 GB of apt
  cache on every version bump, so the ordering is a cache contract, not style. The base
  image is now tracked by Dependabot (`docker` ecosystem); Chrome stays unpinned, with the
  reason and the refresh command written down rather than left implicit.
- **An account with no Flow access was told gflow's selectors had drifted, and asked to
  file a frontend bug.** Google Flow needs an age-verified account in a supported region
  on a Google AI Plus, Pro or Ultra plan (or a qualifying Workspace plan). An account
  without one is served Flow's own "you don't have access" screen instead of the app, and
  gflow had no route for that state, so the editor sweep reported the only thing it could
  see: the settings trigger never appeared. Measured on a newly created free Google
  account, 2026-09-15, as an **A/B through the same command** — the probe neutered, then
  restored, on live Flow:

  | | exit | class | what the user is told |
  |---|---|---|---|
  | before | 23 | `UiSelectorDriftError` | *"Google may have updated their frontend … file a bug at github.com/ffroliva/gflow-cli/issues"* — on `https://flow.google.com/unavailable`, after a 30 s wait, **with an incident bundle containing a screenshot of the account's own page** for the user to attach |
  | after | 39 | `FlowAccessUnavailableError` | *"This Google account cannot reach Flow"*, naming the subscription and linking Google's eligibility page |

  The guard goes in `raise_if_known_landing()`, already the single chokepoint for "we
  landed somewhere unexpected" and shared by all three raise sites (the labs gallery
  sweep, the labs prompt-box sweep, and the migrated composer's `ensure_editor`), so every
  command that drives the Flow editor is covered by the one change. It now probes the DOM
  before it reads the URL. Verified live at $0 on that account: `ui_driver.known_landing
  kind=unavailable at=migrated.ensure_editor`, exit 39, nothing submitted.

  Detection is by Angular component, not by path or status code, because the spike
  ([`2026-09-15-unentitled-account-signal`](docs/superpowers/spikes/2026-09-15-unentitled-account-signal.md))
  pre-registered four candidate signals and refuted all four. There is no entitlement field
  on the session wire; `flow.google.com/` answers **HTTP 200** and performs the hop
  client-side, so there is no 3xx to key on; and the path is not stable — `/unavailable`
  and `/u/8/unavailable` were both observed, the second carrying Google's account-index
  segment, which gflow does not parse anywhere. What is stable is Flow's own
  `<flow-pinhole-unavailable-screen>`, rendered inside `aisandbox-root`, and unlike the
  screen's prose it is locale-invariant by construction (AGENTS.md Tier 1). The probe is
  total: a page that cannot be queried, or a locator that raises, reports "not seen" rather
  than displacing the caller's own diagnosis.

  **What this does not fix, and why — measured, not assumed.** The same account run
  *without* `--project` never reaches the editor at all: it takes the labs REST arm and
  dies at `labs.google/fx/api/trpc/project.createProject` with **HTTP 401**, which is still
  reported as `AuthExpiredError` (exit 3) telling the user to log in again. `gflow auth
  login` (exit 8) and `gflow auth status` (exit 1) are wrong in the same way. All three read
  an oracle that cannot answer the question: `labs.google/fx/api/auth/session` returns 200
  with an empty `user` for an abandoned sign-in *and* for an account with no entitlement,
  and a REST 401 looks identical to an expired session. The discriminator exists only in
  the DOM, and on the login path Chrome has already closed by the time the verdict runs, so
  there is no page left to ask. Routing those means a browser probe on the auth path — a
  separate change, on a surface `AGENTS.md` gates behind its own spike. (`gflow credits
  user` exit 3 on that account is [#795](https://github.com/ffroliva/gflow-cli/issues/795),
  a different real bug. `gflow project list` returning `{"projects": [], "total": 0}` was
  never wrong — it lists the local SQLite catalog and never contacts Flow.)

- **An MCP agent's `project_name` is finally used.** `gflow_generate_image` and
  `gflow_generate_video` accept a `project_name` and document it as the title for a freshly
  created Flow project, but the worker read a different key (`project_title`) that nothing in
  the repository has ever written. Every supplied name was silently dropped and each new
  project was created as the hardcoded fallback `gflow-cli images` instead. Dead since the
  parameter shipped on 2026-07-26 — the daemon's read predated it by four days, and the
  feature wired up a new key rather than the one already being read. The CLI was unaffected.

### Added

- **The Official MCP Registry listing now publishes itself.** A new `MCP Registry` workflow runs
  on `release: published` — after `release.yml` has uploaded the wheel, which matters because
  `mcp-publisher` proves namespace ownership by reading the `mcp-name:` token out of the
  *published* PyPI README. It authenticates with **GitHub Actions OIDC**, so no personal access
  token is created, stored or handed to the registry, and the `mcp-publisher` download is pinned
  by version *and* sha256 since that job holds `id-token: write`. `workflow_dispatch` is there
  for a re-run when a release's PyPI upload succeeded but the registry publish did not. Registry
  listings feed the downstream directories: PulseMCP ingests it and GitHub's MCP gallery is built
  on it.
- **A gate for the MCP→worker payload-key round trip (#628).** `tests/mcp/test_cli_parity.py`
  checks parity at the command and option level; neither can see the queue payload, where a
  key written under one name and read under another type-checks, lints, passes every test and
  does nothing at runtime. The new `tests/mcp/test_payload_key_round_trip.py` extracts the keys
  `mcp/tools.py` writes and the keys anything under `worker/` reads, and fails on any written
  key the worker never reads. It found the `project_name` defect above on its first run. The
  extractors carry their own tests against synthetic sources, so the gate is proven able to go
  red rather than merely observed green (precedent: a dead `output` param the queue never read,
  found by hand in a v0.48.0 pre-release audit, #495).

## [0.75.0] — 2026-09-15

### Added

- **Installable as a Claude Code plugin.** `/plugin marketplace add ffroliva/gflow-cli` then
  `/plugin install gflow@gflow-cli` installs the `gflow-cli` and `video-production` skills and
  registers the MCP server in one step. The plugin ships **disabled**: Claude Code starts a
  plugin's MCP servers automatically on enable with no prompt of its own, and this one drives your
  own Google account where video generation bills your credits, so enabling it is a deliberate act.
  For a hard guarantee, register the server yourself with `gflow mcp run --no-spend`.
- **`docs/DISTRIBUTION.md`** — an operational catalog of every channel people install or discover
  gflow-cli through: audience, how to submit, requirements, status and a last-verified date per
  row. Every row was checked live. It also records the channels that listed us without being asked
  (MCP Market, skills.sh with 21 installs, two auto-generated catalogs) and the ones we are not
  eligible for, with the reason.
- **Listed on [cursor.directory](https://cursor.directory/plugins/gflow-cli)**, and submitted to
  seven more channels: Glama, mcpservers.org, and PRs or issues on `punkpeye/awesome-mcp-servers`,
  `ComposioHQ/awesome-claude-skills`, `hesreallyhim/awesome-claude-code`,
  `travisvn/awesome-claude-skills` and `Arnon-hs/open-source`. `DISTRIBUTION.md` carries the
  status and reference for each, and — equally deliberately — why four channels are closed to a
  local-stdio server that spends the user's own credits, including a section on why there is no
  hosted "connector" and what one would actually cost.
- **`server.json`** — metadata for the official MCP Registry, with `tests/test_server_json.py`
  pinning version lockstep, the schema's 100-character description cap, the name pattern, the
  `mcp-name:` ownership token in the README, and that the command it advertises really exists.
- **A `gflow-cli` console script.** `uvx gflow-cli mcp run` previously failed with uv's own
  *"Use `uvx --from gflow-cli <EXECUTABLE-NAME>` instead"*, because the console scripts were named
  `gflow` and `flow`. The MCP Registry builds exactly that `uvx <identifier>` command from the
  PyPI identifier and has no field for a differing executable name, so a listing would have been
  broken on arrival.

### Changed

- **PyPI metadata.** The summary described only image-to-video and never mentioned MCP; it now
  says what the package is. Added `Documentation`, `Repository` and `Changelog` sidebar links,
  ten trove classifiers (all checked against the official list) and MCP-related keywords.
- **Dropped "unofficial" as a label** from the PyPI summary, `README.md`, `index.html`, the docs
  site, `llms.txt`, `ROADMAP.md`, `DISCLAIMER.md`, `AGENTS.md`, `CLAUDE.md`,
  `skills/gflow-cli/SKILL.md` and `src/gflow_cli/__init__.py`. The substance is unchanged and
  still prominent: the README warning block reads "alpha and reverse-engineered — not affiliated
  with Google", and `DISCLAIMER.md` still opens "not affiliated with, endorsed by, sponsored by,
  or otherwise connected to Google LLC" — only the word "unofficial" left its first sentence.
  It was leading with a negative in the one line PyPI shows in search results.


### Fixed

- **The Codex and ChatGPT-desktop plugin manifests shipped every skill in `skills/`**, including
  maintainer-only ones (`release`, `check`, `pr-council-review`, `sonar`, `doc-review`). All three
  channels now point at the same curated two-skill payload under `plugins/gflow/`, generated from
  `skills/` by `scripts/ci/generate_plugin_skills.py` with a `--check` drift gate in CI.

- **Remediation hints naming an extra rendered without the extra.** Rich reads `[chain]` in an
  interpolated value as a style tag and silently drops it, so `pip install 'gflow-cli[chain]'`
  printed as `pip install 'gflow-cli'` — advice that reinstalls what you already have. The same
  applied to `gflow-cli[patchright]`. Only brackets whose first character is `[a-z#/@]` are
  affected, which is exactly the shape of a package extra. Every site that renders error text
  through Rich now escapes it, and `tests/test_rich_markup_safety.py` fails the build if a new one
  appears. `--json` was never affected.

- **`gflow video chain` was unusable on a clean `gflow-cli[chain]` install (#813).** The extra
  installed `av` but not Pillow, while `media.py` imports `PIL` at module level — so
  `uvx --from 'gflow-cli[chain]==0.74.0' gflow video chain one.jsonl --dry-run` died on
  `No module named 'PIL'`, surfaced as a generic exit `1` *"Unexpected error… file a bug"*,
  immediately after the user installed the documented extra. `pillow>=12.3.0` now ships in the
  `chain` extra alongside `av`.
- **A missing `av` used to fail only AFTER a paid clip.** `import av` sat inside
  `media._decode_frame`, which runs between links — so the missing extra surfaced once link 0
  had already been generated and billed. It is now a module-level import beside `PIL`, and the
  import block at the top of `video chain` is guarded: either missing package is a typed
  `FrameExtractionError` (exit `20`) raised *before* the manifest is read, before `--dry-run`
  prints a plan, and before the cost prompt. Nothing is submitted and no browser is launched.
  `FrameExtractionError`'s remediation now names the extra **and both** packages (`av`,
  `pillow`); it previously said only "PyAV", which left a missing Pillow undiagnosable.
- **Error text containing `[...]` was silently truncated on the console.** `detail` and
  `remediation_hint` were interpolated into Rich markup unescaped, so Rich read `[chain]` as an
  unknown style tag and dropped it — turning every `install gflow-cli[chain]` hint into
  `install gflow-cli`, advice that reinstalls what the user already has. Both error render
  paths now escape. `--json` was never affected.
### Security

- **`gflow serve` now requires the configured daemon token on every HTTP request.**
  `GFLOW_CLI_DAEMON_TOKEN` / `GFLOW_DAEMON_TOKEN` previously gated startup only. It is now verified
  on every request, on both the Streamable HTTP and the deprecated SSE transport, with a
  constant-time comparison; a missing, malformed or wrong token gets `401` plus a
  `WWW-Authenticate: Bearer` header and never reaches a tool. Set a token and upgrade if you run
  `gflow serve` on anything other than the default loopback bind.

## [0.74.0] — 2026-09-14

### Added

- **Sponsorship: a Support section, a sponsor hall of fame, and a Funding link on PyPI.** The
  README gains one-click sponsor links; [docs/SPONSORS.md](docs/SPONSORS.md) lists the tiers and
  what each one gets. `.github/workflows/sponsors.yml` refreshes the hall of fame daily from GitHub
  Sponsors, plus a Gold row at the top of both pages, and only ever lists sponsors who chose to
  sponsor publicly. No CLI or MCP behaviour
  changes.

### Changed

- **On `flow.google.com`, an agent-only composer now exits `25` (`FlowAgentUiError`) where
  it previously exited `23` (`UiSelectorDriftError`)** — and reports `retryable: false`
  rather than inheriting that class's retryable default. Scripts branching on `23` for
  this failure must add `25`. Nothing else moved: a trigger missing from the DOM is still
  exit 23. See the `### Fixed` entry below for why
  ([#799](https://github.com/ffroliva/gflow-cli/issues/799)).


### Fixed

- **Migrated-host i2v: the Frames picker is confirmed when it does not commit on the
  pick (#792).** On some cohorts Flow's Frames picker no longer closes when an asset is
  clicked — it waits for its own "Add to prompt" confirm. gflow sat out
  `FRAME_COMMIT_HIDDEN_S` waiting for an auto-close that never came and raised
  `UiSelectorDriftError` with the asset already picked, so i2v dispatch failed before
  submit (no credits spent). The picker is now given a short grace period and, if it is
  still up, its confirm is clicked. Anchored on `button.detail-add-to-prompt-btn`, a
  class measured on this exact surface — never on the translated label. Where the pick
  already commits, nothing changes: a closing picker no longer carries the button.
- **A re-run of the same start frame no longer binds a stale look-alike (#792).** The
  Frames picker is searched by display name and an upload is listed under its file name,
  so attaching the same keyframe twice left two identical library entries; the search
  could bind the older one and the submit-body check then failed with `eb1hJf does not
  carry the uploaded start frame`. What is uploaded is now a run-unique copy
  (`<stem>-<8 hex>.<ext>`), so the search has exactly one match by construction and the
  library's sort order is no longer trusted. **This applies to every local file this
  driver uploads on the migrated host** — `video i2v --initial-frame`, `video r2v --ref`
  and `image i2i --ref` alike, since all three find their upload again by display name.
  Expect the tagged names when you browse the project's library on flow.google.com.

  Reported, root-caused and verified end-to-end on the affected cohort by **@ai4U23**.

- **`gflow credits` stopped sending migrated accounts to re-login, on the raise site they
  actually hit (#795).** v0.73.2 fixed the message for a labs session that mints no token.
  It did not help the cohort that gets a token and has aisandbox-pa reject it, and it could
  not: the service caught its own accurate verdict and re-derived it through a browser,
  which fails inside the shared, route-blind aisandbox retry helper and so reported
  *"aisandbox-pa returned 401 after token refresh — SAPISID cookie missing, expired, or
  unreadable. Re-run `gflow auth login`"*. Every word of that is wrong here: aisandbox-pa
  answered, SAPISID is what let labs mint the token, and on a migrated account re-login can
  roll the profile's strategy marker back and start #791.

  The browser is no longer consulted once aisandbox-pa has **answered**: it asks the same
  endpoint for the same Bearer and gets the same refusal. The other raise site — labs
  answering with no token — keeps its browser rescue, because that one is not proven
  unreachable: httpx sends labs.google cookies only, while the browser carries the full jar
  and bootstraps a real navigation, which can renew a session httpx cannot. If that rescue
  fails too, the fast path's diagnosis is what survives, not the route-blind default.

  `gflow credits list` also reports the remediation per profile now. It rendered only the
  class title, so the multi-profile surface — and `gflow_get_credits(all_profiles=true)`
  with it — was the one place that still could not say why, or that re-login would not help.

  Measured on a migrated profile: `gflow credits user` went from ~7 s to ~2 s with no
  browser launch, and across 9 saved profiles `credits list` dropped from 9 Chrome launches
  to 6 — the 3 on the aisandbox-401 cohort skip it, the rest keep their rescue. Applies to
  the MCP twin `gflow_get_credits` identically: both doors share the service and the
  envelope.

  `credits` itself is still unavailable on migrated accounts; the balance surface for that
  cohort has not been located. #795 stays open for it.

- **The migrated agent-only composer is named before submit instead of reported as
  selector drift (#799).** Google has put some accounts on a `flow.google.com` composer
  that has **no classic arm at all** — the prompt box is the agent panel, and aspect,
  model and count live in Agent settings as defaults rather than per-request controls.
  gflow waited 30 s for a control that is structurally absent and raised
  `UiSelectorDriftError` (exit 23), which reads as *our* frontend bug and invites a retry
  that cannot work.

  It now raises `FlowAgentUiError` — **exit 25, `retryable: false`** — naming the cohort
  and saying plainly that no flag or profile change helps. The discriminator is the chip:
  the DOM is identical to #749's recoverable agent mode (settings trigger present under a
  bare `hidden`), and what separates them is that a recoverable account still has a
  `button.agent-mode-chip` to turn off while this one has none. A trigger that has left
  the DOM entirely is unchanged — that is a renamed selector, our bug, and still drift.

  `retryable` moved from `FlowAppError` to the error base to make that possible — its own
  comment set the condition, *"move it up if, and only if, a second class needs it"*, and
  this is the second. No existing error's retryability changed.

  Reported with the DOM evidence that made it diagnosable by **@Cstanish127**. gflow-cli
  still has no driver for that composer; #799 stays open for it.
## [0.73.2] — 2026-09-12


### Fixed

- **A missing browser-strategy marker no longer reports as a network problem (#796).**
  The Playwright cookie reader refuses a profile whose `.gflow_browser_strategy` marker
  is absent, and that `SecurityError` was flattened into `VERIFICATION_ERROR` — whose
  guidance is "check network connectivity", for a file on the user's own disk. It is
  also precisely the state a failed first login leaves behind, since that rolls the
  marker back. A new `PROFILE_MARKER_MISSING` outcome carries its own message and the
  remediation that actually works (`gflow auth login --browser chrome`), on the CLI and
  on the MCP twin (HTTP 409, `retryable: false` — it is neither a network blip nor an
  expired session).
- **`gflow credits` no longer blames SAPISID for a host it never contacted (#795).** When
  labs.google answers 200 with no `access_token` — the normal shape for an account Google
  has migrated to `flow.google.com` — the failure was raised as "aisandbox-pa
  authentication failed" with the remediation "SAPISID cookie missing, expired, or
  unreadable". aisandbox-pa had not been contacted, and SAPISID was present and fine, so
  the advice sent users into a re-login loop that cannot terminate on that cohort. The
  remediation now names the real cause. `credits` itself remains labs-only on migrated
  accounts — tracked in #795.
- **Incident bundles from a `flow.google.com` failure are no longer blank (#792).** The
  migrated composer parked its pooled page on `about:blank` in a bare `finally`, so on
  the FAILURE path it navigated away *before* `FlowApiClient._capture_incident` read the
  page — whose own contract is to stage the bundle "while the page is still alive".
  Every migrated video and image failure therefore shipped `tag_counts.div = 0`, a white
  screenshot and `host_category = "other"` beside a network journal that proved the app
  was alive, which reads exactly like a lost browser tab and is unusable as evidence.
  The park is deferred past the capture and drained at the **top of the next run**, before
  the route decision reads `page.url` — which is where the invariant it protects (a stale
  project URL must not route the next request) is actually consumed, and the only place
  that also covers the `post_with_retry` path, where a retryable 5xx re-enters the
  transport without passing the client's failure boundary at all. Cancellation still
  attempts the park inline and latches, since no bundle is staged for it.
  Note a failure bundle's `sensitive/screenshot.png` is now a real capture of the
  logged-in page rather than a blank frame — the review-before-sharing posture in
  SECURITY.md applies to it as it already did to every other screenshot.

- **The `/about` landing's `retryable=False` is now a measurement, not a preserved
  default.** A live occurrence was caught on a second account and the #756 stability
  probe re-run unmodified: **5/5** attempts landed on `/about` over ~3 minutes, on the
  account's own project, with a healthy session — so a retry is doomed and costs ~35 s
  each. Four places that said the measurement *could not* be made are corrected — two
  code comments, the exit-31 row in [USAGE](docs/USAGE.md) and the `retryable` note in
  [MCP](docs/MCP.md); behaviour is unchanged. Still unmeasured: the cause, and whether
  it ever clears.
- **An auth-status test no longer depends on how wide the terminal is.** Several steps
  assert a substring of Rich's output, which hard-wraps — so a temp path landing near
  the wrap column split `experiments` into `profile_e` + `xperiments` and failed on
  formatting rather than behaviour. Pinned at the shared `CliRunner` fixture, which is
  the one chokepoint for every invoke in that file.

## [0.73.1] — 2026-09-11


### Fixed

- **Google's cookie-consent bar no longer blocks generation on `flow.google.com`.**
  The `glue` bar is fixed at `z-index: 1000` and Flow's composer is bottom-anchored in
  the same band, so the bar sat on the settings trigger *and* on the image submit:
  `elementFromPoint` over each returned the bar in 5/5 rendered samples, on the same
  profile and project where the click had landed 3/3 the day before. Every image and
  video run on a re-prompted profile failed, before any submit, so nothing was billed.
  The driver now clears the bar before its first click. It **rejects** rather than
  accepts — both remove the bar, and only one answers a consent question on your
  behalf. Reported by @stgmt in [#780](https://github.com/ffroliva/gflow-cli/issues/780);
  measured in [the 2026-09-11 spike](docs/superpowers/spikes/2026-09-11-migrated-cookie-bar-blocks-the-composer.md).
- **A click post-mortem now names the thing on top, not its inner node.** The occluder
  allowlist matched `cdk|mat|mdc|flow` class prefixes on the element `elementFromPoint`
  returned — but a consent bar puts an unnamed label span there and keeps its identity
  in an `id` the allowlist deliberately drops, so #776's attribution reported
  `it is covered by span`. It now adds Google's `glue` prefix and climbs to the nearest
  ancestor that names itself, reporting `div.glue-cookie-notification-bar`. Unchanged
  for the CDK overlays that already worked, and the `id` is still never echoed.

## [0.73.0] — 2026-09-10

### Security

- **Google auth URLs no longer reach user-facing error messages with their query
  intact.** `client._handle_account_chooser`'s three raise sites interpolated
  `page.url` verbatim, and Google's auth URLs carry `state`, `code_challenge`,
  `client_id` and challenge tokens (`TL=…`). That text is the artifact users are
  asked to paste into a GitHub issue.
  - **Measured, not theorised:** a real `gflow image t2i --profile <name>` on
    2026-09-10 exited 38 and printed
    `accounts.google.com/v3/signin/challenge/pwd?TL=ACv9tzFkh8ZJ…` along with the
    OAuth `state` and `client_id`. Re-running the identical command after the fix:
    same exit 38, same landing named, **zero** secret matches.
  - New `safe_page_url()` in `api/transports/_common.py` keeps scheme+host+path and
    drops query+fragment; all four raise sites (the three in `client.py` plus
    `raise_if_known_landing`) route through it rather than stripping inline.
  - The landing is still named — knowing *where* the session stopped is the whole
    value of the message; only the credentials are gone.


### Fixed
- **A click that never lands now says what was true instead of nothing at all**
  ([#776](https://github.com/ffroliva/gflow-cli/issues/776)). On `flow.google.com`,
  `video r2v` reached `migrated.editor_ready` and died 5.039 s later as a bare
  Playwright `TimeoutError` — exit 1, no locator, no cause, no MP4. By elimination that
  is `migrated_composer.py`'s `trigger.click(timeout=5000)`: the `wait_for(visible)` one
  line above it is guarded and would have raised exit 23, so the control was *visible*
  and the *click* expired. [#752](https://github.com/ffroliva/gflow-cli/issues/752)
  finding #7 predicted exactly this, at exactly this function, before #776 was filed —
  its `count()`→visibility half was fixed and the click half was not, leaving a comment
  that describes the failure the next line went on producing.
  - **It reads; it does not diagnose.** Two causes were live and *neither could be
    measured*: Flow's announcement overlay ([#593](https://github.com/ffroliva/gflow-cli/issues/593),
    measured on labs.google, never on this host) and a mid-run agent-mode flip. A guard
    built on either would answer confidently and be wrong half the time. So on a timeout
    the driver reads Playwright's four actionability conditions back — agent chip,
    `hidden`/`disabled`, body pointer-events, and a hit-test naming what is on top — and
    reports the ones that fired. When every reading is healthy it **says so**, which
    eliminates three conditions and leaves *stable*, rather than inventing a fourth.
  - **Costs nothing when healthy** — the read runs only in the `except` branch, the rule
    `raise_if_known_landing` already states: a guard ahead of the probe deletes the
    evidence that would correct it.
  - **MCP gains more than the CLI.** A non-`GFlowError` on the queued path shipped
    `"detail": "sha256:…"` — a hash, not even the class name. The typed error routes it
    to the Problem Details branch instead, so an agent now gets the locator and exit 23.
  - Applied to four sites with a named reason each, not all nineteen: the reported one,
    the composer click `_close_pane`'s own docstring records as failing this way, and
    both submit sites, where a bare timeout left "did it submit?" unanswerable — the
    video one spends Veo credits, the image one spends only daily quota.
  - **The occluder report is a closed allowlist** — tag name plus at most three
    framework-prefixed class tokens, never `aria-label`, `title`, `src` or `outerHTML`.
    Typing the error moves the text from SHA-256-hashed telemetry to a message printed
    raw, logged, and invited into a GitHub issue; a signed-in Flow page carries the
    account email and signed media URLs on exactly the elements that occlude things.
  - `retryable` is unchanged and **preserved, not measured** — the condition did not
    reproduce, and a flag that moves as a side effect of retyping is a claim nobody made.
- **A known Flow landing page is no longer reported as selector drift**
  ([#756](https://github.com/ffroliva/gflow-cli/issues/756), and the 2026-09-10 RED
  nightly canary). `flow_host_kind()` classifies the *origin*; `/about`,
  `/project/<id>` and `/fx/api/auth/signin?error=Callback` all share one, so when a
  readiness wait timed out it had nothing left to blame but its own anchor — sending
  the operator to "check for a newer release, then file a bug" over a session state
  no release changes. The fourth instance of one pattern (after #721 credits, #749
  agent mode, and `FlowAppError`'s own crash page), so it is fixed once, shared:
  - New `flow_landing_kind()` beside `flow_host_kind()` in `api/transports/_common.py`
    names a known non-app landing (`"signin"` / `"public"` / `None`), and
    `raise_if_known_landing()` converts the diagnosis at **three** raise sites — the
    migrated readiness wait, the labs gallery sweep, and the labs prompt-box sweep,
    where a bare `RuntimeError` was being SHA-256 hashed into "Unexpected error" with
    the URL destroyed. Consulted **only inside an already-failed branch** — never ahead of a probe, which would delete the evidence
    that corrects a wrong absence claim, and never as a new bounded wait after `goto`,
    which reads the URL before Flow's client-side redirect lands
    ([#639](https://github.com/ffroliva/gflow-cli/issues/639)).
  - `flow.google.com/about` instead of the project → `FlowAppError` (exit 31), naming
    the landing and the project it did not open. It deliberately does **not** say why:
    #756 measured the redirect and not its cause, and `gflow auth status` reports the
    session verified while it happens.
  - `labs.google/fx/api/auth/signin?error=Callback` instead of the gallery →
    `AuthExpiredError` (exit 3), remediation `gflow auth login`. This is the exact
    page behind the 2026-09-10 RED canary, which reported
    `Could not find 'New project' CTA`.
  - `auth/internal_chromium.py` drops its private `_NEXTAUTH_ROUTE_PREFIX` and reuses
    the shared classifier — the knowledge existed there since #767 and no transport
    could reach it.
  - `FlowAppError`'s docstring and `docs/USAGE.md`'s exit-code table now describe both
    shapes; previously both stated the crash page as the only one. `docs/USAGE.md`'s
    exit-3 row and `docs/MCP.md`'s retryable list are corrected to match, and
    `docs/DEBUGGING.md` records that the sign-in landing is now capture-exempt —
    deliberate (a bundle there would screenshot a Google auth surface into the artifact
    users attach to issues), but a class swap switches capture off silently.
  - The landing URL is stripped to scheme+host+path before it reaches the message or
    the log: the NextAuth family includes `/fx/api/auth/callback/google?state=…&code=…`,
    and this message is precisely what users paste into issues.
  - `"public"` is scoped to the migrated host, the only one where `/about` was measured.
  - **`accounts.google.com` is recognised too — found by live-verifying, not by
    reasoning.** The first version returned `None` there on the grounds that "the
    chooser has its own handler", which is true at bootstrap
    (`client._handle_account_chooser`) and false for a hop that happens *after* it. A
    live A/B on profile `denon82` (2026-09-10, $0) landed exactly there mid-run and
    still produced `RuntimeError: Could not find 'New project' CTA` — with the OAuth
    `state`, `code_challenge` and `client_id` interpolated into the message. It now
    raises `FlowAccountChooserError` (38) for a chooser and `AuthExpiredError` (3) for
    other Google sign-in surfaces, URL stripped. The bot-rejection hop
    (`/v3/signin/rejected`) keeps returning `None` — it has its own error.
- **`gflow auth list` no longer fails on a profile whose `.gflow_account` is damaged**
  (PR [#764](https://github.com/ffroliva/gflow-cli/pull/764)). The reader decoded as
  UTF-8 and caught only `OSError`, so a non-UTF-8 or truncated file raised out of
  `list_profiles()` and broke the listing for *every* profile, not just the damaged one.
  The value is also interpolated into a DOM attribute selector, where a stray quote
  produced an untyped failure. Unusable content now reads as "no account recorded",
  which every caller already handles.
- **Google's post-migration account chooser no longer stalls a run**
  ([#763](https://github.com/ffroliva/gflow-cli/issues/763), PR
  [#764](https://github.com/ffroliva/gflow-cli/pull/764) — thanks @stgmt). When Google
  hands the session to `flow.google.com` and redirects to a chooser, `FlowApiClient`
  now auto-selects the profile's recorded account from `.gflow_account` instead of
  stalling into an opaque `RecaptchaError`/exit 1.
  - The row match is exact and case-insensitive on both tiers, and **anchored so the
    chooser's `Remove <email>` / `Sign out of <email>` rows can never be clicked**.
  - A chooser is identified *positively* (chooser path, or account rows), so an
    ordinary expired session still classifies as `AuthExpiredError` (exit 3) rather
    than being swept into the new class.
  - Cases that cannot be selected raise a typed, non-retryable
    `FlowAccountChooserError` (**exit 38**) naming the URL the session actually
    landed on.
  - `.gflow_account` is treated as untrusted input — this fixes an untyped failure in
    the selector and a crash in `gflow auth list` on a damaged file.
  - Follow-up hardening is tracked in
    [#773](https://github.com/ffroliva/gflow-cli/issues/773).

### Added
- **`gflow auth login --account <email>`** asserts the login authenticated as the
  required account, failing closed on a mismatch rather than leaving a profile signed
  in as somebody else (PR [#764](https://github.com/ffroliva/gflow-cli/pull/764)).
- **`FlowAppError.retryable`** — a per-instance override of that class's
  `RETRYABLE_ERRORS` membership. `None` (the default) keeps the class answer, so no
  existing raise changes. Scoped to the one class that needs it: `is_retryable()` reads
  it by `getattr`, so a base-class field would have sat on every error in the project
  to serve a single raise site.
  - It exists because routing `/about` to exit 31 would otherwise have silently flipped
    that shape from non-retryable (its exit-23 past) to retryable, asserting on every
    occurrence that a retry is worth making. **That was measured, and could not be
    settled:** the redirect stopped reproducing on `ci-probe` between 2026-09-08 and
    2026-09-10 (5/5 attempts reached the editor —
    [spike](docs/superpowers/spikes/2026-09-10-about-redirect-stability.md)), which is
    equally consistent with "transient" and with "a session state changed". So the
    `/about` raise site passes `retryable=False` to **preserve** the previous answer,
    not to claim a retry fails. Flip it when someone catches the redirect live and
    measures whether a second attempt wins.
  - `is_retryable()` pins the override with `isinstance(..., bool)` rather than a
    truthiness test: a `MagicMock` answers every attribute with a truthy child mock, so
    a truthiness test would report **every** mocked error as retryable with nothing in
    the suite noticing. Covered by a test that asserts that precondition explicitly.
- **BDD scenarios can now be bound as e2e tests**, with no new machinery: pytest-bdd
  converts Gherkin tags into pytest markers, so a Feature tagged `@e2e @e2e_auth`
  is filtered by the existing `addopts` and selected by the existing `-m <tier>`.
  Feature files stay in `tests/features/`; their step module lives in `tests/e2e/`
  so it inherits that suite's profile-gating fixtures. See
  [docs/E2E_TESTING.md § BDD-bound e2e](docs/E2E_TESTING.md#bdd-bound-e2e).
- `tests/features/test_e2e_binding_guard.py` — offline guard (no browser, runs in
  hosted CI) for three ways that binding breaks silently: an `@e2e` scenario nobody
  wrote a test for, an `@e2e` Feature with no cost sub-marker (invisible to the
  nightly canary), and the inverse hazard — a Feature bound from `tests/e2e/` but
  left untagged, which escapes `addopts` and makes hosted CI try to drive Chrome.
  It carries its own fire-test, so a green run means "no orphans", not "never looked".

### Changed
- **Workflow: the Bug Lane is now the documented route from symptom to fix.**
  `skills/issue-resolve/SKILL.md` gains a canonical `spike → systematic-debugging →
  BDD → TDD → fix → e2e` chain, gated by *surface* (steps 0–2 are skippable for a
  one-line fix whose cause is proven — but a skip is a claim and must be stated;
  steps 3–5 never are). AGENTS.md, `skills/spike`, `skills/scenario`,
  `docs/E2E_TESTING.md` and `docs/INDEX.md` cite it; none restate it.
  - Removes a real contradiction: `issue-resolve` step 3 previously permitted "the
    closest browser-free proxy" while AGENTS.md's Iron Law said a change with no e2e
    coverage must get one and listed "covered by unit tests" among the excuses that
    are *not* blockers. Two disjoint files, no merge conflict, no gate that could
    see it.
  - "Browser-free" is no longer accepted as a verification blocker: only a **named**
    external blocker is (an account you do not control, a Mac, an exhausted quota).

## [0.72.0] — 2026-09-09

### Added

- **`gflow image t2i` and local-file `i2i` now run on migrated `flow.google.com`
  accounts** ([#639](https://github.com/ffroliva/gflow-cli/issues/639)). The Angular
  composer binds Image mode, Nano Banana 2 / Pro, the four aspect ratios measured on that
  host (16:9, 4:3, 1:1, 9:16) and counts 1–4,
  then observes the page-owned `ogiZ0b` `batchexecute` reply and returns the same
  `GeneratedImage` contract as the labs driver. Local references reuse the measured
  `maseQ` upload + mention path and are verified in the outgoing submit body before the
  result is trusted. The migrated page owns reCAPTCHA minting, avoiding the root-grid
  `RecaptchaError`; unsupported UUID/entity/instruction/Imagen-4 forms still fail before
  submit rather than silently dropping options.

- **`gflow image batch` is refused on the migrated host instead of failing as selector
  drift** ([#639](https://github.com/ffroliva/gflow-cli/issues/639)). The batch path
  drives labs selectors only; it now raises `FlowHostMigratedError` (exit 36) before any
  submit, rather than running those selectors against `flow.google.com` and reporting
  exit 23 — which told the user to file a frontend-drift bug about a frontend that was
  behaving correctly.

### Changed

- **`gflow auth login` closes the browser for you.** It drives your real Google Chrome
  through Playwright, watches for the completed Flow sign-in, and closes the window itself —
  the "now close Chrome" step is gone. Closing the window yourself still works and still
  verifies; it is not an error. On a machine where Playwright cannot resolve a Chrome
  channel, or where Google rejects the browser anyway, login falls back automatically to the
  previous flow (Chrome as a plain subprocess, you close the window). **There is no new flag
  and nothing to choose.**
  ([spike](docs/superpowers/spikes/2026-09-08-g12-blocks-webdriver-not-playwright.md))


### Fixed

- **The second image in one session no longer falls back to the labs reCAPTCHA mint**
  ([#673](https://github.com/ffroliva/gflow-cli/issues/673)). Every migrated image run
  parks its page on `about:blank`, which routes as `labs` — so the page-owned-mint
  capability, derived from `page.url`, answered `False` on the next call and sent it
  back to minting on the pooled bootstrap page. The transport now latches the observed
  host: `gflow image batch`, which runs every prompt through one `FlowApiClient`,
  generated its first prompt and failed the rest with the exact `RecaptchaError` this
  release exists to remove.
- **`--aspect 3:4` is refused on the migrated host rather than reported as selector
  drift.** The composer's aspect radiogroup was enumerated there with four radios —
  `crop_16_9`, `crop_landscape`, `crop_square`, `crop_9_16` — and no `crop_portrait`, so
  a 3:4 request missed its selector and raised exit 23. It is now an unported form
  (exit 36). The "all five aspect ratios" claim has been corrected to the four measured
  wherever it appeared.
- **The exit-36 remediation no longer contradicts the error it accompanies.**
  `FlowHostMigratedError._default_remediation` still described the migrated host as
  driving only t2v and local-frame i2v, so an image refusal printed a `detail` saying
  t2i/i2i are driven directly above a remediation saying they are not. Both it and the
  class docstring now name the full ported matrix.
- **`gflow auth login --browser internal` launched a browser configuration measured as
  rejected.** The bundled-Chromium path shipped with no anti-automation flags, which leaves
  `navigator.webdriver` set. On 2026-09-08 a browser in that state — real Chrome with the
  flags removed — was rejected at `/v3/signin/rejected` 17.5 s into the flow, while the same
  browser *with* the flags signed in normally. Bundled Chromium was measured only in the
  flagged configuration, so its unflagged rejection is inferred from the shared signal, not
  observed directly. It now passes
  `--disable-blink-features=AutomationControlled`, `ignore_default_args=["--enable-automation"]`
  and `chromium_sandbox=True` — the last of which also removes Chrome's cosmetic *"You are
  using an unsupported command-line flag"* banner — and signs in on the real OS window
  instead of an emulated 1920×1080 viewport that pushed Google's sign-in form off-screen on
  smaller or scaled displays.
- **Setting `CHROME_BINARY` no longer makes Playwright's `channel="chrome"` look resolvable
  when it is not.** The availability check treated the variable as proof, passed, and then
  failed at launch with *"Chromium distribution 'chrome' is not found"*. Playwright honours a
  custom binary only via `executable_path=`, never via `channel=`, so the variable is now
  ignored by that check (it still resolves a Chrome binary everywhere else).

### Security

- **`httpx2` / `httpcore2` bumped to 2.12.0, clearing five newly published CVEs**
  ([#766](https://github.com/ffroliva/gflow-cli/pull/766)). `httpcore2` CVE-2026-84381 and
  `httpx2` CVE-2026-84378 / -84379 / -84380 / -84382, all against 2.9.1; both arrive
  transitively through `mcp`. The advisories were published against an unchanged lockfile —
  `Dependency audit (pip-audit)` went red on `develop` without any dependency change — so
  this is not a regression introduced by a feature PR. `uvx pip-audit` on the exported
  requirements now reports no known vulnerabilities. The bump also adds `httpx2-jsfetch`
  1.0 to the lock, marked `sys_platform == 'emscripten'` (Pyodide/WASM only); it is never
  installed on any platform gflow supports.

## [0.71.1] — 2026-09-08


### Fixed

- **A blocked first upload no longer reads as a broken file or a broken network.** On the
  migrated `flow.google.com` host, `video i2v --initial-frame` and `video r2v --ref` failed
  on an account's **first** upload with `MediaUploadRejectedError` (exit 27) — *"no maseQ
  reply within 60s of choosing the file — the upload never reached Flow or was dropped"* —
  and advised re-encoding the image to strip metadata. Neither the file nor the network was
  involved: Flow shows a one-time **"Rights to use this image"** confirmation *after* the
  chooser hands the file over, and sends nothing until a human accepts it, so the driver
  spent its whole budget waiting for a request the page had already declined to make.
  Measured across 8 runs on 3 profiles — the two accounts that had uploaded before never saw
  the dialog and uploaded fine, the account that never had failed 3/3, and accepting it once
  made that account upload on the next run and every run after
  ([spike](docs/superpowers/spikes/2026-09-08-migrated-upload-fails-two-ways.md)).

  The driver now counts dialogs across the upload and, when one appeared *during* it, names
  the one-time confirmation and tells the user to accept it once in a browser. **It is
  counted rather than matched on purpose:** the dialog's two buttons are
  `button.flow-button-medium` with no ligature and no data attribute, separable only by DOM
  order, and its copy is translated — there is no anchor there that satisfies this project's
  locale rule, whereas "a dialog appeared between the file being chosen and the wait
  expiring" is upload-related by construction and cannot rot when Angular renames a class.

  **gflow does not accept the dialog for you**, and there is no flag to make it: the dialog
  affirms that *you* hold the rights to what you upload, it is one-off per account, and the
  path already requires an interactive `gflow auth login` — so a setting that could never
  safely default to on would be a flag nobody sets.

  The driver also now watches the upload **request**, not just the response, so the timeout
  splits into two distinct messages: `no upload request ever left the page` and `the request
  left the page and Flow did not answer in time`. That distinction is load-bearing — the
  second argues for a retry and the first argues against one — and it exposes a **second,
  unfixed** failure on this path, an intermittent no-reply on already-consented accounts
  (~1 run in 4) that keeps [#719](https://github.com/ffroliva/gflow-cli/issues/719) open and
  now has its own [KNOWN_ISSUES.md](KNOWN_ISSUES.md) entry.
  ([#719](https://github.com/ffroliva/gflow-cli/issues/719))

### Documentation

- **Three documents said things that were not true, and are corrected rather than quietly
  patched.** [KNOWN_ISSUES.md](KNOWN_ISSUES.md) said Flow's first-upload terms dialog affected
  "the legacy in-tree Compiled Growth worker, **NOT `gflow-cli` itself** … workaround: none
  needed" — true of the old REST path, false since the migrated driver began using the
  editor's own upload, so it was the entry a user hitting #719 would find and be *reassured*
  by. [LIVE_VERIFICATION_v0.71.0](docs/LIVE_VERIFICATION_v0.71.0.md) labelled the `ci-probe`
  profile **labs** when it is migrated, contradicting v0.70.0 one day earlier; in a repo where
  "Flow's UI shows X" is not a fact until the host is named, that silently re-scoped every
  conclusion keyed to it — and it helped a credit-based theory for #719 survive four runs.
  Six "unreleased line" phrases, which go stale the moment a release ships and had accumulated
  across four of them, are now dated from the CHANGELOG.

### Added

- **Two `$0` read-only dev instruments** for the migrated host.
  [`scripts/dev/spike_migrated_queue_read.py`](scripts/dev/spike_migrated_queue_read.py) reads
  a project's generation queue by listening to the page's own traffic — establishing that the
  listing arrives on **`Zzl0ze`**, not the `jwpduf`/`as29s` progress polls, which is what a
  future `gflow video status` ([#741](https://github.com/ffroliva/gflow-cli/issues/741)) should
  read. [`scripts/dev/spike_migrated_upload_wire.py`](scripts/dev/spike_migrated_upload_wire.py)
  drives the real `_upload_via_toolbar` with a listener on every request, which is how the
  consent dialog above was found. Neither is wired into the CLI.

- **Flow's agent mode no longer bricks the account for every later run.** On the migrated
  `flow.google.com` host the composer carries an **agent-mode chip**
  (`button.agent-mode-chip[aria-pressed]`). Pressed, Flow swaps `flow-prompt-box` for
  `flow-creative-agent-prompt-box`: the `.settings-trigger-button` this driver waits on stays
  in the DOM but gains a bare `hidden` (`display: none`, 0×0, not hit-testable), so
  `wait_for(state="visible")` could never pass and every run died at 30 s as
  `UiSelectorDriftError` (exit 23) — telling the user to file a frontend-drift bug about a
  frontend that was working fine. Flow **remembers the chip per account**, so one click in a
  browser broke every subsequent `gflow video t2v`, with nothing on the CLI to say why or how
  to undo it. `ensure_editor` now leaves agent mode before the readiness gate, and if the
  classic composer still does not come back it says *that* instead of blaming drift. Measured
  2026-09-08 on two accounts, $0 —
  [`scripts/dev/spike_migrated_composer_arms.py`](scripts/dev/spike_migrated_composer_arms.py),
  finding in
  [`docs/superpowers/spikes/2026-09-08-migrated-composer-agent-mode-hides-settings.md`](docs/superpowers/spikes/2026-09-08-migrated-composer-agent-mode-hides-settings.md).
  The reporter's suggested anchor (`aria-label="Configuración"`) is not used: it is a translated
  label, and the chip's own component class plus `aria-pressed` carry the same identity in every
  locale. ([#749](https://github.com/ffroliva/gflow-cli/issues/749))

  **Follow-up ([#752](https://github.com/ffroliva/gflow-cli/issues/752)):** the fix worked and
  its diagnostics did not. Three states were collapsed into one message — the chip was clicked,
  the chip was found but the click was blocked, the chip was clicked and the mode is still on —
  and all three read as *"the chip was clicked to leave it … the mode may be pinned"*. A modal
  eating the click sent the user to toggle a chip; genuine selector drift **after** the mode was
  successfully left was reported as a pinned mode, so the drift bug never got filed. The chip's
  `aria-pressed` is now read back before that claim is made, a blocked click raises at once
  instead of waiting out the 20 s recovery window (worst case 55 s → 35 s), the click's own
  exception is chained rather than truncated into a log line, and `_open_pane` — the same gate
  one step later — guards on **visibility** rather than `count()`, so a mode flip mid-run maps
  to exit 23 naming agent mode instead of escaping as a bare Playwright timeout. Searchable
  entry added to [KNOWN_ISSUES.md](KNOWN_ISSUES.md), which the shipped message gave a user no
  way to find.

## [0.71.0] — 2026-09-07


### Fixed

- **`--format-prompt` could submit an EMPTY prompt and log it as success.** The
  observed-rewrite gate compared `abs(len(current) - len(typed)) >= 16`, and `abs` accepts
  change in either direction. Flow **clears** the composer before repopulating it, so a poll
  landing in that window read `""`, `abs(0 - 19) = 19` passed the gate, and `_send_prompt`
  called `_click_submit` on the very next line — submitting nothing, on a path that spends
  image quota, while `ui_automation.prompt_formatted` logged `prompt_len_after=0`
  (`prompt_hash=e3b0c442`, the SHA-256 of the empty string).

  Silent, billed, and self-certifying: a user hitting it would see a charge, an empty
  result, and a log line saying it worked. It is also the exact defect the same release
  fixes — a success signal that fires on the **absence** of the thing it measures — rebuilt
  inside its own fix.

  The gate now requires **growth** (`len(current) >= len(typed) + MIN_DELTA`) rather than an
  absolute delta, plus a settle check: two reads one poll-interval apart must agree, because
  the single discrete swap measured live was sampled at 250 ms and a partial write between
  samples was never ruled out. Found by an adversarial review of the fix, not by the fix's
  own tests. ([#745](https://github.com/ffroliva/gflow-cli/issues/745))

- **The entity guard recorded a cause that was wrong, and it is retracted.** The
  `reference_entities` refusal in `_unported_form` said the submit *"never produces a
  YhhmEf/eb1hJf/MZZa6b reply"*, cause unknown, undiagnosable without fixing
  [#722](https://github.com/ffroliva/gflow-cli/issues/722). Reading the wire live shows
  otherwise: `MZZa6b` **does** reply, with a null payload and an error slot, and the generation
  is **accepted and queued** — Flow derives an `abra_r2v_8s` model key and renders it. What
  fails is the observer: a null payload never names a media id, so `submit_and_observe`'s
  `submitted` future never resolves and `SUBMIT_REPLY_BUDGET_S` (60 s) expires. That budget's
  own comment records its calibration — *"the submit reply arrived 4.0–4.6 s after the click"* —
  against an idle queue, while Flow allows **five concurrent generations** and throttles
  per-minute throughput after heavy daily use. The run exits 9 `TransportTimeoutError` while the
  video is still rendering. The guard **stays** (a timeout reported on a generation that is
  actually running is worse for the user than an explicit refusal) but its reason is now
  accurate and the fix is named beside it: on a null submit payload, fall through to the
  `jwpduf`/`as29s` status poll. Two earlier comments on that guard, including one added in this
  release, asserted the wrong cause.
  ([#723](https://github.com/ffroliva/gflow-cli/issues/723),
  [#742](https://github.com/ffroliva/gflow-cli/pull/742))
- **`docs/CHARACTER.md` and `docs/CHARACTER_RECON.md` disagreed on the voice wire case, and one
  was wrong.** CHARACTER.md called the Capitalized UI name canonical while flagging the question
  UNVERIFIED; CHARACTER_RECON.md recorded `presetVoiceId: "gacrux"` and stated the preset id is
  the lowercased name. A live run settles it: `sent='Charon' stored='Charon' identical=True`.
  Both documents now also record that `personalityNotes` is **Agent-scoped** — Flow's own editor
  says *"The Flow agent can use this information to help craft scenes with your character"* — so
  it is not a control on the audio engine and should not be expected to steer a `t2v`/`r2v`
  performance. ([#736](https://github.com/ffroliva/gflow-cli/pull/736))
- **The "+ New project" CTA is found by structure again, not by English.** Its Tier-1 anchors
  all targeted the `add_2` ligature. The migrated `flow.google.com` gallery renders **`add`**
  under a `<mat-icon>` and renders `add_2` nowhere on that surface, so every structural entry
  missed and the CTA was reached only by `button:has-text('New project')` — the localised-text
  anti-pattern Tier 1 exists to avoid, and one that fails outright on a non-English migrated
  profile. Tier 1 now leads with a class-only `add` anchor covering both carriers; measured on
  the live gallery (control: 47 ligature nodes) it matches 1 where every previous entry
  matched 0.

  Also removed: `button:text-matches('^\+\s+\S+$', 'i')`. It is not a valid Playwright
  selector and **raised on every evaluation** — observed twice against the live gallery — with
  `except Exception: continue` swallowing it, so it had never matched anything on any host
  while costing a round trip per attempt.

  **This reverts the guard added moments earlier in the same release.** That guard raised
  `FlowHostMigratedError` claiming the migrated host "renders no '+ New project' control gflow
  can drive". It was an unproven negative, generalised from a sweep of two other surfaces to a
  third that was never probed, and a live run disproved it in one click by creating a project
  there. On a non-EN migrated profile it would have told the user that host has no such
  control — false, and a dead end — when the real fix was to anchor on `add`.
  ([#730](https://github.com/ffroliva/gflow-cli/issues/730))

- **~~A migrated-host gallery no longer reports a missing control as selector drift.~~ REVERTED WITHIN THIS RELEASE — kept for the record, see the bullet above.** The guard described below shipped and was removed again before the tag, because a live run created a project on that very surface in one click. The net change in v0.71.0 is the one above: the CTA is anchored structurally on `add` instead of by English text. Nothing in the paragraph that follows is behaviour you will find in this release.
  `NEW_PROJECT_SELECTORS` anchors on the `add_2` ligature. The migrated `flow.google.com`
  frontend renders **`add`** and renders `add_2` **nowhere** — composer `add=1/add_2=0`,
  editor `add=2/add_2=0`, measured with per-surface controls. That is a ligature *name*
  drift, not the carrier split, so a `mat-icon` twin would not have helped. Reaching the
  sweep there produced `Could not find 'New project' CTA on Flow gallery`, whose remediation
  is "check for a newer release, then file a frontend bug" — unfixable by the reader, and
  pointing at the wrong culprit, exactly as a credit shortfall once reported as frontend
  drift. It now raises `FlowHostMigratedError` naming the host and the way forward
  (`--project`, which every migrated path already requires). On labs a missing CTA is still
  reported as drift, because there it genuinely is.

  No production path reaches this today — `migrated_can_serve` refuses without a
  `project_id`, `ensure_editor` navigates straight to the project URL, and `character create`
  requires `--project`. The `add_2` drift is therefore harmless **because of those guards**,
  which is precisely what a future port relaxes; the measured fact now sits beside the
  constant so the next person to un-guard a path meets it.
  ([#730](https://github.com/ffroliva/gflow-cli/issues/730),
  [spike](docs/superpowers/spikes/2026-09-07-ligature-carrier-and-name-drift.md))

- **Flow's own diagnostics were blind on the migrated host, and two selectors were broken behind
  it.** `gflow`'s incident-bundle DOM dump queried `i.google-symbols, span.google-symbols`, and
  `diagnostics.py`'s `STRUCTURAL_DOM_JS` queried `i.google-symbols` — so on `flow.google.com`,
  where every Material Symbols ligature rides a `<mat-icon>`, **both reported zero ligatures**.
  The instrument used to diagnose selector drift was blind to the host the drift lives on. That
  is why [#727](https://github.com/ffroliva/gflow-cli/issues/727) and
  [#731](https://github.com/ffroliva/gflow-cli/issues/731) stayed invisible, and why an incident
  bundle from a migrated user named no ligatures at all. Both queries are now class-only.

  Two selectors were broken behind that blindness. `SUBMIT_BUTTON_SELECTORS` was **working by
  luck**: its two tag-qualified entries matched nothing on the migrated host and the submit only
  landed because a third `has-text` entry matches the `<mat-icon>`'s *text* — observed live as
  `prompt_submitted via="button:has-text('arrow_forward')"`, after paying two misses per submit.
  `IMAGE_MODEL_PICKER_TRIGGER` had neither twin nor fallback, so its miss was total and silent:
  the picker is best-effort, so generation simply proceeded on whatever model tier the editor
  opened at. Both now anchor on the `google-symbols` **class**, which sits on the labs `<i>` and
  the migrated `<mat-icon>` alike — verified against a real CSS engine, offline, in
  `tests/api/transports/test_ligature_carrier.py`.

  `SUBMIT_BUTTON_SELECTORS` also moves from `:text` to **`:text-is`**. `:text` is a substring
  match and accepts `arrow_forward_ios`, a real Material Symbol; the `<i>` qualifier had been
  containing that, and dropping it for the class-only carrier made the over-match reachable on
  the submit path. The two-carrier fixture caught it as `matched 3 of 2` before it ran live.
  ([#730](https://github.com/ffroliva/gflow-cli/issues/730),
  [spike](docs/superpowers/spikes/2026-09-07-ligature-carrier-and-name-drift.md))

- **`character create --format-prompt` works again — both halves of it.** The flag had two
  independent faults, and fixing only the first would have left it just as useless. On the
  migrated `flow.google.com` host
  all three entries of `PROMPT_FORMAT_SELECTORS` missed, so the flag degraded to a no-op:
  `ui_automation.format_button_not_found`, exit **0**, prompt submitted as
  typed, and the image quota spent on a run whose requested prompt-engineering step never
  happened. The button was never absent. Measured on 2026-09-07 with
  `scripts/dev/spike_character_prompt_format.py` (`$0` — navigation, one free `createEntity`,
  DOM reads and typing; two control anchors, so a flat zero could not be mistaken for
  absence): it renders as
  `<flow-format-prompt-button>`, and the Angular frontend carries the unchanged
  `personal_recommendations` ligature in **`<mat-icon>`** rather than `<i>` — the same carrier
  split fixed for `add_2` / `arrow_drop_down` / `accessibility_new` in #703, which this constant
  was not swept with. The EN `span:text-is('Format')` fallback missed too and is **deleted**
  rather than translated: the button's own `aria-label` reads `"Formatar"` on a pt account, and
  display labels are banned as anchors. The cascade now leads with the custom element and covers
  both carriers. ([#727](https://github.com/ffroliva/gflow-cli/issues/727),
  [spike](docs/superpowers/spikes/2026-09-07-character-format-button-anchor.md))

- **`video t2v --reference-entity` no longer bills a clip that ignores the entity.** On the
  migrated `flow.google.com` host the "character references are not ported" refusal lived inside
  the r2v branch of the routing gate, so a t2v request returned from that gate before its
  `reference_entities` were ever inspected — and nothing downstream attaches one there
  (`attach_start_frame` is i2v-only, `attach_references` and the chip verification are r2v-only).
  The run was submitted and **billed**, returning a plausible clip with an unbound face. That is
  strictly worse than the exit 36 it was meant to give: a refusal is free and honest. The
  sibling gate `migrated_can_serve` did refuse, but it only feeds `prefer_migrated`, and an
  account Flow has already moved is routed by its URL without consulting it — so the refusal was
  unreachable for exactly the accounts that needed it. The check is now mode-independent and
  ahead of every early return. ([#716](https://github.com/ffroliva/gflow-cli/issues/716))
- **A credit shortfall is no longer diagnosed as a moved frontend.** On the migrated
  `flow.google.com` host, an account whose balance is short **for the model it asked for**
  produced `UiSelectorDriftError` (exit 23) — *"A Flow editor UI element could not be
  located — Google may have updated their frontend. Check for a newer gflow-cli release,
  then file a bug"*. Flow does not **disable** the submit control, it **replaces** it:
  `arrow_forward` disappears and a `prompt-warning-button` carrying
  `aria-label='Insufficient credits warning'` takes its place, so the anchor's absence
  tracks the credit state, not the frontend. Measured by A/B on 2026-09-07 —
  `scripts/dev/spike_migrated_submit_anchor.py`, same probe and same code ~60 s apart,
  two accounts rendering the mirror image of each other. The wallet was **not** empty:
  it held **50** credits and the run asked for `--model veo-quality`, which costs **100**.
  That distinction is the actionable half — "you have no credits" is a dead end for
  someone holding 50, while "short for this model" has a remedy: pick a cheaper tier
  (`veo-lite` is 10). Every path that gives up on the submit control now checks for the
  warning before naming a culprit, and reports the new `InsufficientCreditsError`
  (**exit 37**) instead. Genuine drift — a missing anchor with no warning beside it —
  still reports 23. Beyond the wrong message, the old behaviour manufactured
  frontend-drift bug reports that no code change could ever fix.

### Changed

- **`--format-prompt` now waits for the rewrite, and `ui_automation.prompt_formatted` means it
  happened.** This is the second half of the #727 fix and the half that made the flag useful.
  Flow rewrites **server-side** — a `batchexecute` round trip reaching the composer at ~5.4s
  (measured, `denon82`) — while the old code waited `_jitter_ms(500)`, logged
  `prompt_formatted` and returned; `_send_prompt` submits on the very next line. So the flag
  shipped the prompt the user typed and discarded the rewrite on **every** run, with a success
  event in the log and exit 0.

  **The defect was never the duration. It was reporting a success we had not observed** — the
  absence of a completion inside a window we chose, recorded as a completion. Same class as a
  20s selector timeout read as "the feature is absent" and a bundle captured after teardown
  read as "the DOM was gone". This one was the worst of the three because it failed toward
  **success**: a premature green looks exactly like the feature working, so nobody investigates
  a pass.

  `format_character_prompt` now polls the bound composer until its text actually changes, and
  returns `True` only then. The gate is the DOM, not the wire — the `batchexecute` response
  arrives **4.2s before** the text settles, so awaiting it would reproduce the same early
  submit. Comparing against the string gflow inserted is locale-invariant by construction, and
  a **length delta** rather than `!=` keeps Slate's whitespace normalisation from re-reporting
  the same false success. Telemetry carries lengths and a stable hash, never the prompt text:
  Flow *elaborates* a terse description into a detailed physical one, so the rewrite is more
  PII-dense than the input.

  New events: `format_button_clicked` (the old semantics), `format_not_observed` (clicked, no
  rewrite inside the budget — it does not claim Flow failed, since an unchanged box also covers
  Flow declining or judging the prompt already formatted).

  **Two user-visible consequences.** A create with `--format-prompt` takes a few seconds longer
  for the rewrite itself, and — because the reshaped prompt is longer and more detailed — the
  generation is materially slower: **406s vs a 210s control** on the same account and prompt,
  live-verified 2026-09-07.
  ([#727](https://github.com/ffroliva/gflow-cli/issues/727),
  [spike](docs/superpowers/spikes/2026-09-07-format-click-is-not-a-format.md))

- **Retracted a false "measured" claim about the migrated composer.** A code comment asserted, as
  "measured, not assumed", that the migrated project composer "has no image-generation mode".
  Falsified live on 2026-09-07: its settings overlay opens to six radiogroups / sixteen radios and
  the first is `[imageImage, videocamVideo]`, present and hit-testable, with the VIDEO option
  carrying `aria-checked`. This reproduced an enumeration already committed on 2026-09-04,
  exactly, on a different account. That does **not** establish that `image` works there — nothing
  was clicked on the mode axis and nothing was submitted — only that the claim it cannot is
  unfounded. Stating it more strongly would repeat the defect being retracted. The guard stays
  until the port lands, but it no longer tells anyone the host cannot do this. ([#692](https://github.com/ffroliva/gflow-cli/issues/692),
  [spike](docs/superpowers/spikes/2026-09-07-migrated-composer-has-an-image-mode.md))
- **A spike that cannot reach its surface now fails instead of concluding.**
  `spike_migrated_image_capability.py` opened the settings overlay best-effort and swallowed the
  exception, so it printed "the migrated composer looks VIDEO-ONLY" even when it had never opened
  the panel — and that sentence became the retracted claim above. It now raises
  `SpikeUnreachedError` and exits 3 with "This is a failed measurement, NOT evidence of absence".
  Two features have now been declared absent by a probe that failed silently; the first was
  `character create`, killed by a single 20 s selector timeout.

### Added

- **`gflow character create --voice` is now verified end to end.**
  `tests/e2e/test_character_create_e2e.py::test_character_create_attaches_voice_and_personality`
  drives a live create then reads the character back from Flow. Until it existed, a repo-wide
  grep for `--voice` across `tests/e2e/` matched **nothing**: every voice test was a unit test
  of the hardcoded `VOICES` constant, and the one that looked live parsed a fixture. A voice
  that silently failed to attach was invisible to the whole suite while the command exited 0.
  Personality is asserted hard, unlike the sibling UTF-8 test which guards it as
  `if shown_personality:` and passes vacuously when the field is absent.
  ([#736](https://github.com/ffroliva/gflow-cli/pull/736))
- `scripts/dev/spike_entity_submit_rpcs.py` — attaches a character, submits, and logs **every**
  `batchexecute` rpcid rather than only the three in `SUBMIT_RPCS`, plus the submit request's
  model key. `scripts/dev/spike_project_media_status.py` — reads a project's generation state
  read-only, `$0`, submitting nothing.
  ([#741](https://github.com/ffroliva/gflow-cli/issues/741))
- **`video-production` skill § 4b-bis — the whole recipe for a cast with VOICES.** A character
  entity is the only thing that carries a voice; a plate carries face and wardrobe as pixels and
  the engine invents a new voice per clip. Measured across three plate-bound takes of one
  character: **88 / 103 / 118 Hz**, three different actors, against a **4.3 Hz** engine noise
  floor on an identical prompt repeated three times. The skill said to prefer rung 1 and never
  said what skipping it costs, so a production could reach a finished cut before anyone noticed
  the cast had no voices.
- `scripts/dev/spike_host_lane.py` — names a profile's lane (labs / migrated / **signed out**) in
  one $0 run. It reports `SIGNED_OUT` as a distinct verdict and refuses to name a lane there,
  because a signed-out profile is otherwise indistinguishable from a migrated one: with no
  session, `labs.google/fx/…` renders its marketing shell and `flow.google.com/project/<id>`
  redirects to `/about`. Read either in isolation and you conclude "this account was moved" from
  a dead cookie.
- `scripts/dev/spike_migrated_composer_mode_axis.py` — hard-error probe that opens the migrated
  composer's settings overlay and enumerates its radiogroups.
- `scripts/dev/spike_format_prompt_effect.py` — measures whether clicking Format actually
  rewrites the prompt, and when. `$0`, never submits.

## [0.70.0] — 2026-09-06


### Fixed

- **`-o <existing directory>` no longer costs you a clip.** `--output` on `video t2v` / `i2v` /
  `r2v` and on `image t2i` / `i2i` accepted a path that was already a directory. Nothing checked
  it until `_relocate_video_output` called `Path.replace()` onto the target, long after Flow had
  rendered and billed the clip: `PermissionError: [WinError 5]`, surfaced as a bare
  "Unexpected error" (exit 1), with the paid mp4 orphaned under a bare UUID name in the working
  directory. Found by dogfooding an r2v run on 2026-09-06 — two clips billed, neither saveable.
  All five option declarations now carry `dir_okay=False`, which Click enforces while parsing, so
  the run aborts in under a second at zero cost. (A sixth declaration already had it; the rest had
  drifted from it.)

- **`gflow character create` works on the migrated `flow.google.com` host.** It had never been
  broken there — gflow was not driving it. The readiness gate waited for
  `div[role="textbox"][data-slate-editor="true"]`, a React/**Slate** anchor; the migrated
  frontend is Angular and renders the same editor with **ProseMirror**, so the gate timed out
  after 20 s and the surface was read as absent. v0.69.0 then hardened that misreading into a
  `raise_if_migrated` guard that aborted with exit 36 *before* probing the DOM, turning "our
  selector missed" into a confident, non-retryable "this host will never do it". The gate now
  accepts both anchors, the guard is gone, and the picker/result paths follow:

  - body mode is anchored on the migrated editor's `<flow-slot-chip-button>` component
    boundary (there is no `add_2` control there at all), its settle signal is the face
    reference mounting from `flow-content.google/image/…`, and the prompt-box counter now
    counts through the readiness anchor instead of Slate only — it reported 0 boxes on an
    editor whose box was mounted and visible. `--body-prompt`, `--voice` and `--personality`
    all complete on the migrated host as a result.
  - each slot takes **its own** `primaryMediaId`, read from the project listing. The entity
    exposes only a thumbnail id, and handing that to every slot made the body slot claim the
    face's media — which `commit_workflow` then PATCHed onto the body workflow, corrupting it.
    Reading Flow's own value makes that commit a no-op.
  - the portrait is read back off the **entity** when the labs `batchGenerateImages` wire stays
    silent. The migrated host generates over its own `batchexecute` (rpcid `ogiZ0b`), so the
    listener timed out on work that had already succeeded — the entity carried a workflow id and
    a thumbnail media id the moment the timeout fired. The ids now come off the entity itself,
    which proves the character binding by construction rather than trusting a self-reported
    `parentEntityId`, and the image is downloaded so `--output` and `image_paths` behave the
    same on both hosts.

  Verified live on a moved account: `display_name` patched, workflow id and thumbnail bound,
  file on disk, and `--model nano2` / `--model nanopro` each selecting the tier asked for.
  Recon: `scripts/dev/spike_migrated_character_*.py`.

- **`character create --model` is now deterministic: it applies the tier you asked for, or it
  fails.** The character model picker was best-effort — every failure path logged a warning and
  let the generation run on whatever tier the editor happened to show, so `--model nano2` could
  quietly return a Nano Banana Pro image with nothing in the output saying so. Three separate
  faults did exactly that: it skipped the click entirely when `nano2` was requested (assuming
  Nano Banana 2 was the editor default, which is true on labs and false on `flow.google.com`);
  its option selector `:has-text('…')` was unanchored, so `.first` resolved to `<html>`; and its
  menu-item lookup was unscoped, so `[role='menuitem']` mixed the open menu's entries with
  hidden ones from the editor's other menus and `nth(i)` clicked a node that could not be
  clicked. The menu also offers **three** tiers, not the documented two, and `Nano Banana 2` is
  a prefix of `Nano Banana 2 Lite`.

  Now: entries are read from the *visible* menu, matched in Python with an explicit exclusion,
  an ambiguous or absent match refuses rather than guessing, and the selection is **verified by
  re-reading the chip** rather than trusting the click. Anything else raises — `ConfigurationError`
  for a tier the menu does not offer, `UiSelectorDriftError` for a picker that cannot be driven.
  Aborting here is free: the picker runs before the prompt is submitted, so a refusal costs no
  quota and no credits, while proceeding produces a paid artifact from the wrong model. Verified
  live: four consecutive runs alternating `--model nano2` / `--model nanopro`, correct tier every
  time.

- **A failed `character create` no longer strands an "Untitled Character" in the project.** The
  saga persists before it spends, and deliberately keeps its STARTED row so a retry can resume —
  but that row is keyed on `(project_id, name)`, so a retry under any other name missed it and
  minted a second entity, leaving the first orphaned with `refs=0` forever. A failure with no
  slot committed now rolls the free entity back and marks the row FAILED. It asks the **backend**
  first: an empty local `workflow_ids` means only that this process failed to read a result, and
  on the migrated host a portrait generated fine while the client timed out — deleting on the
  local signal alone would have destroyed finished work.

- **PR-triage autopilot: stop re-alerting a deferred PR on every push.** The `DEFERRED_SIZE` and
  `NEEDS-HUMAN` gate branches deduped on `(pr, head_sha, status)`, so every push to an oversized
  PR looked new to the ledger and re-sent a byte-identical "needs a manual review" mail on the
  next hourly cycle. PR #683 produced three on 2026-09-06 (2130 / 2500 / 3066 lines) — same
  verdict, same required action. Now dedupes on the PR's latest ledger status via a new
  `latest_status()` helper: one alert per gate trip, and a PR that trips, gets fixed and reviewed,
  then regresses still alerts again. Ops tooling under `scripts/autopilot/`, not a Flow surface,
  so no e2e applies. ([#697](https://github.com/ffroliva/gflow-cli/issues/697))

- **A reCAPTCHA mint that fails after the migrated-host handoff now reports exit 36, not exit 1**
  ([#692](https://github.com/ffroliva/gflow-cli/issues/692)). The `raise_if_migrated` guard added
  in #678 is a point-in-time read of `page.url`, and Flow's handoff to `flow.google.com` is a
  **client-side** navigation that can land after it. The bootstrap's own `await_url_settled` does
  not close that window either — it is skipped entirely for a profile latched at
  `NOT_REDIRECTED`. The guard is now re-run on the mint's failure path, which costs nothing when
  the mint succeeds and classifies correctly whenever the hop lands, rather than depending on it
  landing before one particular line. A genuine labs-side reCAPTCHA failure still surfaces as
  `RecaptchaError`.

  **The re-check now polls for a bounded 1.5 s rather than reading once.** A single instantaneous
  read still lost the race: Playwright updates `page.url` on `framenavigated`, so a mint that dies
  *while* the navigation is committing reads the old host on an account that is in fact migrated,
  and the run exited 1. Polling turns "who won this instant" into "did the hop land at all". It is
  the error path, so a successful mint never waits.

  The re-check catches **any** mint failure, not just `RecaptchaError`. `TokenMinter.mint` guards
  only its second `page.evaluate`: `site_key()` → `discover_site_key` runs an unguarded one, and
  the minter is rebuilt per call so that unguarded call runs every time. A hop mid-mint destroys
  the execution context, so the likeliest shape of this failure is a **raw Playwright error** —
  which a `RecaptchaError`-only net would miss entirely. Nothing is swallowed: the original
  exception propagates untouched unless the page turns out to be migrated.

  **Scope, stated honestly:** the reporter's failure could **not** be reproduced locally. On a
  migrated, `NOT_REDIRECTED`-latched profile the hop wins the race and v0.69.0 already returns
  exit 36 — verified live, before and after this change. So this hardens a race that is real in
  the code but unobserved here; it is not a confirmed fix for #692, which stays open.

### Added

- **`gflow video r2v` from local `--ref` files runs on the migrated `flow.google.com`
  host** (#639). Each file is uploaded through the same editor toolbar path i2v already
  uses, so the app's own `maseQ` reply names the media id, and is then attached as an `@`
  **mention** in the prompt — references are not a chip slot on this host.

  Three measured details shape it. The Ingredients submit is rpcid **`MZZa6b`** (t2v
  `YhhmEf`, i2v `eb1hJf`) — watching only the others is why this looked for several rounds
  of recon like r2v never submitted at all. A mention is committed by **Enter**; a typed
  query alone leaves the picker open and inserts nothing. And mentions need real key
  events where prompt text needs `insert_text` (a newline must not submit), so the two
  cannot share a path.

  The submit body is asserted to carry every uploaded id, and a run whose references have
  not all attached is refused **before** submit (exit 32) — the failure mode being a
  full-price clip with none of the user's references on it. A reference the picker misses
  is retried, since its search index does not always hold a fresh upload on the first
  query. References by `@Name` and character entities (`--reference-entity`) stay on labs,
  for the same reason a frame by UUID does: the picker exposes no media id to anchor on.
  Live-verified end to end with two local refs and `--model veo-lite-lp`, and confirmed
  semantically by the account owner: the presenter in the output is the person from the
  first reference and the product is the one from the second, so both references are
  genuinely bound rather than merely accepted.

  **`--duration` is refused on this path (exit 11), and an r2v run pins 8s for itself.**
  Flow offers reference-to-video only at its base 8s tier on this host. At 4s or 6s it does
  not refuse: it flattens the reference mentions into plain prompt text and submits
  `veo_3_1_t2v_lite_4s_low_priority` — a full-price text-to-video clip carrying the file
  *names* and none of the images. The editor remembers the last duration, so a run passing
  none was inheriting a degrading one. Measured at zero credits across three route-blocked
  runs varying only the duration (`scripts/dev/capture_migrated_r2v_production_submit.py`).
  Note the media slot carries the reference ids even in the degraded submits, so the model
  key — not the ids — is what distinguishes a bound run from an accepted one.

  **Correction to the first cut of this feature**, kept here because the claim was public:
  the submit-body assertion above was written and unit-tested but **never registered** on
  the r2v path — `page.on("request", …)` was gated on the i2v `expect_media_id`, which is
  always `None` for r2v. The live run and its e2e evidence therefore prove the references
  bound; they do not prove a lost one would have been caught. Fixed, along with the model
  key regex the diagnostic reads (it matched only mode-infixed keys, and a *mode-less* key
  is precisely what an r2v body carries when the picker inserted nothing), and covered by a
  round-trip test that drives `submit_and_observe` and asserts the check actually fired
  rather than calling it directly.

- **`recaptcha_mint_failed_off_migrated_host`** — when a mint fails and the page still reads as
  `labs.google`, the page URL is now logged. That is the one observation which distinguishes the
  race above from a genuine labs-side reCAPTCHA break, and it makes the next incident bundle
  self-sufficient instead of costing a round trip to the reporter.

## [0.69.0] — 2026-09-06

### Added

- **Read-only Flow balance inspection:** `gflow credits user`, `gflow credits list`, and the
  matching `gflow_get_credits` MCP tool report current
  balances and account tiers from saved profiles. Multi-profile inspection preserves partial
  successes and emits stable JSON for automation. Saved cookies + ordinary HTTP are the primary
  path, with browser-backed retrieval only as a fallback; cookies remain scoped to `labs.google`,
  and no copied bearer token or browser API key is stored. The reported balance funds Veo video;
  image generation uses separate per-model daily quotas.

- **Image-to-video from a local start frame on the migrated `flow.google.com` host**
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639), slice 1). `gflow video i2v
  --initial-frame <local file> --project <id>` now runs on the new host — on a moved
  account, and by default (`GFLOW_CLI_FLOW_HOST=auto`) on an unmoved one too. The port
  is UI-driven and observed, never replayed: the composer selects the Frames submode,
  uploads the file through the editor's own toolbar Upload entry and reads the media id
  off the app's `maseQ` reply, finds the upload in the Start-frame picker under its file
  name (the picker exposes no media id in its DOM), and only then submits. **An unbound
  chip is refused before the click** — exit 23, zero credits — because an empty Frames
  submit silently goes out as text-to-video (the labs #125 shape). The app's submit
  *request* is then inspected as it leaves: a body without that media id, or carrying a
  `_t2v_` model key, fails the run with `WireFormatError` (exit 7) naming what Flow was
  actually asked to make — after the fact, since the request is already on the wire.
  An upload Flow refuses is exit 27 on route `batchexecute:maseQ`; a file the picker
  never lists after three searches is exit 32. For i2v the submit rpc is `eb1hJf` (t2v
  stays `YhhmEf`), and an i2v request with no `--model` binds the veo-lite default here
  exactly as it has always done on labs (#125). Not ported in this slice and named in
  the exit-36 detail: `--end-frame`, a frame given by media UUID or `@Name`, and r2v.
  A "Get started" modal over a fresh migrated editor is now dismissed before the run.
  Recon: `docs/superpowers/spikes/2026-09-05-migrated-frames-attach.md`.

- **`--model veo-lite-lp` is drivable on the migrated `flow.google.com` host.** It was
  the one tier the migrated model map omitted, so an account Google has already moved
  could not select it at all: `_select_model` refused with `ConfigurationError` (exit
  11, "not available on the migrated Flow host") before ever reading the live menu.
  The omission was not an oversight — the tier's full menu label is unknown, because
  Flow has never rendered the entry on any account gflow has driven (the 2026-08-14
  two-account capability matrix, #650's duration capture and v0.61.0's refusal A/B all
  recorded a picker MISS), and the migrated map is keyed by label. It is now matched
  the way the labs driver has matched it since #539 — by the `[Lower Priority]` tag
  alone. **The entry has now been captured** (2026-09-05, a migrated account): the menu
  renders `Veo 3.1 - Lite [Lower Priority]`, and that account's picker was already
  *defaulted* to it — presumably why every earlier capture missed the entry, having been
  taken on accounts Flow was not throttling. Matching stays on the tag rather than the
  newly-known label: one account's rendering, and a tag Flow appends to whichever tier it
  throttles survives that tier changing. Verified live at $0 by driving `_select_model`
  for all five tiers and reading the picker back after each switch — including the
  lower-priority tier reached through the menu — plus one real 8 s generation on it.
  Routing is deliberately unchanged: `veo-lite-lp` still does not make
  `migrated_can_serve` pull an **unmoved** account onto the new host, since Flow appears
  not to offer the tier to accounts it is not throttling.
  Capture: `docs/superpowers/spikes/2026-09-05-migrated-model-menu-lower-priority.md`.

### Changed

- **`video-production` skill, epoch 1: the reference cap now routes instead of only
  forbidding.** A scored rollout picked `veo-quality` for a two-reference shot while
  correctly reciting that its reference cap is 0 — the skill stated the prohibition in two
  places and named the substitute in none, and the remedy lived only in the reference files
  an agent may never load. Step 4 now carries the rule: the reference count picks the model
  before quality does, `omni-flash` for a single generation needing references and quality
  together, a `veo-lite` variant when 3 refs is enough — and `video chain` is called out as
  the exception, since it refuses `omni-flash` outright. Validated by a controlled A/B on
  one model with the document as the only variable: 0.00 → 0.90.

- **The SkillOpt harness uses the project's own `GFLOW_CLI_LLM_*` settings.** It carried a
  second, parallel provider configuration — its own `--provider anthropic|openai` switch,
  its own key env vars and its own `--base-url` — while `Settings.llm_base_url` /
  `llm_api_key` / `llm_model` already drove the prompt tools. Any OpenAI-compatible endpoint
  works through the one setting (OpenAI, OpenRouter, LiteLLM, freellmapi, a local gateway,
  Google's compat endpoint); both LLM SDK dependencies are gone, and the harness now
  inherits the URL validation its own flag used to bypass. It requires `uv run`. A scoring
  bug is fixed with it: float accumulation made `1.0 - 0.3 + 0.1` fall short of the `>= 0.8`
  PASS threshold, so a task at exactly the threshold graded PARTIAL while printing "0.80".


### Fixed

- **Moved accounts: `image t2i` / `i2i` (and `upscale`, `extend`) now exit 36, not a
  bare `RecaptchaError` exit 1 (#673).** The labs client mints the reCAPTCHA token on
  the pool's bootstrap page *before* the UI transport runs, so none of the transport's
  migration guards could fire; on a moved account that page is the `flow.google.com`
  project grid after the client-side handoff, which loads no
  `recaptcha/enterprise.js`, so site-key discovery raised `RecaptchaError` — a
  `RuntimeError` unmapped in `EXIT_CODE_MAP`: exit 1 "unexpected", with a remediation
  about headless Chrome. `_mint_recaptcha_token` now runs the same one-line
  `raise_if_migrated` guard the transport uses, so the distinct, non-retryable exit
  36 and its migration remediation come back within seconds, before any submit.
  Reproduced and re-verified on a moved maintainer account at zero credits (exit 1 →
  exit 36); the new
  `tests/e2e/test_migrated_host_e2e.py::test_e2e_image_on_a_moved_account_exits_36_not_recaptcha`
  (`e2e_auth`, $0) is the regression.

- **The migrated model picker could bind a tier the user did not ask for.** The port
  matched menu entries by case-insensitive *substring* and took `.first`, so on an
  account whose menu carries a lower-priority sibling, `--model veo-lite` also matched
  `Veo 3.1 - Lite [Lower Priority]` and Flow billed whichever Angular happened to list
  first. The same substring ran against the picker button's read-back, where a pane
  already showing the lower-priority tier satisfied `startswith("Veo 3.1 - Lite")` and
  returned "already selected" without opening the menu — silently keeping the wrong
  tier. This is the ambiguity #539 fixed on labs.google (whose selectors carry
  `:not(:has-text('[Lower Priority]'))`) and which this port had dropped. Ordinary
  tiers now exclude the tag on both paths, and a matcher hitting more than one live
  entry **refuses** (exit 11) naming every candidate rather than guessing which one
  Flow would bill. Confirmed against the real button text on a throttled account:
  `"Veo 3.1 - Lite [Lower Priority] arrow_drop_down".lower().startswith("veo 3.1 - lite")`
  is `True`, so pre-fix `--model veo-lite` there generated on the throttled tier without
  ever opening the menu.

- **Switching `--model` on the migrated host broke the next run** — reported as "run 1
  with a new model dies, run 2 with the same model works, run 3 with another model dies
  again". Picking from the model menu leaves Angular with **two** stacked overlays (the
  settings pane and the menu opened over it) and each Escape dismisses exactly one, so
  `_close_pane`'s single press closed only the menu and left the settings pane covering
  the composer. `send_prompt`'s click then failed actionability and surfaced ~5 s later
  as a bare `TimeoutError` naming `[contenteditable='true']`, pointing nowhere near the
  pane. A repeat run binds the model at the button read-back, never opens the menu and
  never stacks the second overlay — which is exactly why re-running the same model
  worked. Measured at $0: after a switch the composer's bounding box is *identical* for
  12 s (it was never unstable) while `.cdk-overlay-pane:visible` stays at 1; one more
  Escape takes it to 0. `_close_pane` now escapes until no overlay is visible, bounded,
  and raises pre-submit if one will not close rather than leaving the composer click to
  report it. The old read-back did fire `migrated.pane_still_open` — as a warning the run
  ignored; the observation was there and only the consequence was missing.

- **A migrated run that short-circuited model selection logged nothing.** `_select_model`
  returning at its button read-back emitted no event, so a field timeline could not tell
  "bound the tier you asked for" from "never touched the picker" — answering that for the
  2026-09-05 run took a separate probe. It now logs `migrated.model_already_selected`
  with the observed button text.

## [0.68.0] — 2026-09-05

### Added

- **`gflow update` — self-update in place.** Runs the package manager that
  installed gflow-cli, read off the install itself rather than guessed from
  `PATH`: `uv-receipt.toml` in the venv root → `uv tool upgrade gflow-cli`,
  `pipx_metadata.json` → `pipx upgrade gflow-cli`, otherwise that venv's own
  `python -m pip install --upgrade gflow-cli`. Asks PyPI first and runs nothing
  when already current; if PyPI is unreachable the manager still runs. After an
  upgrade it re-reads the venv's Playwright version and prints the
  `playwright install chromium` hint only when it moved. `--check` reports
  installed vs latest plus the command that would run; `--json` returns the
  same as a document. The outcome is verified against the venv, not the
  manager's exit code: on Windows the running `gflow.exe` launcher holds its
  own file open, so `uv tool upgrade` installs the new wheel and then exits 1
  copying the launcher — measured — and that is reported as an upgrade with a
  note, because the launcher only points at the venv's python and keeps
  working. Editable / local / VCS / source installs, a manager binary missing
  from `PATH`, a `uv venv` with no `pip` module, and a manager run that leaves
  the version unchanged all surface as `ConfigurationError` (exit 11) — except
  the one honest no-op: PyPI unreachable, manager exit 0, nothing changed, which
  is exit 0. Deliberately no MCP twin (a server must not replace its own code under a live
  session) — recorded as a reasoned exemption in the parity test.

### Changed

- **The once-a-day update notice (#479) is now a banner.** On a terminal it is
  a bordered panel on stderr naming the new version, `gflow update`, and the
  release-notes link; when stderr is piped it stays one plain yellow line so
  logs and `2>&1 | jq` pipelines see one line per event. Same cache, same
  gates (`GFLOW_CLI_UPDATE_CHECK=0`, CI, non-index installs). The notice text
  points at `gflow update` instead of listing three manager commands.
- **CONTRIBUTING.md now routes contributors — and their coding agents — through the
  same lifecycle AGENTS.md defines.** A phase → skill → artifact table (issue
  assessment, predict, scenario/plan, check with the step 1b mirror sweep,
  live-verify, council review, sonar, known-issues) says what a PR is expected to
  have gone through and what it leaves behind for the reviewer; the PR template
  gains a matching *Lifecycle* checklist; the quality-gate list is now identical to
  AGENTS.md's (it had drifted to six of nine commands).


### Fixed

- **Migrated host: `video t2v` no longer fails on the submit-enable race (#670,
  @ChandraLiuswanto).** The Angular composer on `flow.google.com` flips the
  `arrow_forward` button from `disabled` roughly 100 ms after `insert_text`
  lands, and the composer read it synchronously, so a fully migrated account got
  `UiSelectorDriftError` ("missing or disabled after the prompt was typed",
  exit 23) on every run before anything was submitted. The composer now waits
  up to 5 s (100 ms polls) for the button to enable; a button that never
  enables is still selector drift, now worded as "stayed disabled for 5s".
  Measured on a moved account: `insert_text` → enabled at the 107 ms sample;
  with the wait, veo-lite t2v completed in 62 s.

## [0.67.0] — 2026-09-05

### Added

- **Text-to-video on Flow's migrated `flow.google.com` host** (#639). An account
  Google has moved off labs.google no longer exits 36 on `gflow video t2v`: the new
  migrated composer drives the Angular editor (option-group radios, model menu,
  `contenteditable` composer, `arrow_forward` submit) and then *observes* the app's
  own `batchexecute` replies — `YhhmEf` submit, `jwpduf` status, `as29s` result —
  before downloading the clip. Under the default
  `GFLOW_CLI_FLOW_HOST=auto`, flow.google.com is now the **default host for every
  request it can serve** — t2v with `--project`, on moved and unmoved accounts
  alike (the new host serves both); what it cannot serve yet keeps the labs
  driver on an unmoved account. `flow.google.com` forces it for everything,
  `labs.google` is the kill switch. `--project` is required on
  that host for now; everything except t2v still exits 36 there. Recon with two
  real generations: `docs/superpowers/spikes/2026-09-05-migrated-host-wire-protocol.md`.

### Changed

- **Exit 36 (`FlowHostMigratedError`) is no longer retryable** (#639). Two $0 spikes
  settled the mechanism: labs.google serves a normal 200 to a fully authenticated
  session, then the app itself runs `location.replace('https://flow.google.com' +
  path)` from a `useEffect`, gated on a server-assigned per-account config boolean.
  It is a one-way rollout — 5/5 and 7/7 on a flagged account — not the per-page-load
  flap the error text claimed, so once an account is flagged a retry never lands the
  old frontend. The remediation, the `_mode_switch_error` fallback, `docs/USAGE.md`,
  `docs/MCP.md`, `KNOWN_ISSUES.md` and `docs/PROJECT_STATUS.md` no longer invite a
  retry, and the MCP, worker and `--json` envelopes carry `retryable: false`.
  Detection is unchanged from v0.66.2: Playwright updates `page.url` in the same
  tick it emits the hop's `framenavigated`, so re-checking it wherever the run is
  about to spend time — the shape the reporter measured at 4.1 s — was already right
  (maintainer A/B on the same machine and profile: 16.0 s vs 16.6 s on unmodified
  `develop`, Chrome launch included).

- **`--duration` now accepts 4s/6s/8s on the Veo 3.1 models** (#650, @stgmt); `10`
  stays `omni-flash`-only. Flow's duration control turns out to be account/cohort-
  dependent — some accounts render the row for Veo, some render none, on the same
  frontend — so the static table that refused it everywhere was wrong for part of
  the userbase. `supports_duration()` is gone; one shared
  `validate_duration_for_model()` now backs the DTO, CLI, chain, movie manifest and
  MCP surfaces. On an account **without** the control the run now reaches the browser
  and aborts pre-submit with no credits spent — exit 23 on the labs driver, exit 11
  on the migrated `flow.google.com` host, where the maintainer cohort renders the
  duration row for Omni 1.1 Flash only (measured 2026-09-05) — instead of refusing
  instantly at the CLI edge — a deliberate trade, since a static per-model table
  cannot express a per-account capability.


### Fixed

- **`--model` on the migrated host selected the model and then lost the settings pane**
  (#665). After the model menu — a second overlay — opened and closed, the driver
  resolved `.cdk-overlay-pane.last` to the detached menu pane, so every axis after the
  switch read "0 option groups". The pane is now the overlay that contains the option
  groups; a regression test keeps a stale menu pane as the last overlay.
- **MCP `gflow_generate_video` accepted any `duration` when `model` was omitted**
  (#659): `duration=99` queued and burned a browser run. The tool now validates the
  value against the supported set regardless of model, like the CLI's choice list.

## [0.66.3] — 2026-09-03


### Fixed

- **`<html lang>` was read before the app set it, so every account whose URL could not answer
  resolved to `en` ([#651](https://github.com/ffroliva/gflow-cli/issues/651)).** Flow serves an
  **`en` shell** and rewrites `lang` during hydration. The single early read added by
  [#643](https://github.com/ffroliva/gflow-cli/issues/643) therefore returned the shell value —
  and the accounts it hit are exactly the ones #643 was written for: those where the URL carries
  no locale segment. Reported by
  [@maipmacrothorax-75](https://github.com/maipmacrothorax-75) on a pt-BR account resolving `en`
  while both pages served `<html lang="pt">`, with the mechanism offered explicitly as a guess.

  The guess is confirmed, and it reproduces on the **old** host — so this was never a migration
  bug. Measured on a pt account, two consecutive loads:

  | t (ms) | `lang` | `readyState` |
  |---|---|---|
  | 887 | `en` | interactive |
  | **1510** | `en` | **complete** |
  | 2092 | `en` | complete |
  | **2488** | **`pt`** | complete |

  **`readyState` is not a usable signal** — it reaches `complete` a full second *before* the
  flip, so the obvious "wait for complete, then read" would have shipped the same bug with more
  code. The DOM node count oscillates (136 → 300 → 249 → 251) and does not discriminate either.
  Nothing cheap predicts the flip, so `_resolve_account_locale` now **observes** it: read once,
  bounded-wait for the value to change, re-read.

  A timeout is an **answer**, not a failure — either the account's locale genuinely equals the
  shell default, or the page never hydrated in the window. Both leave the first read as the best
  available answer, which is exactly the previous behaviour, so the branch can never be worse
  than what it replaces. It is logged as `client.account_locale_lang_unchanged` so the field can
  tell the two apart. Cost: an account whose locale **is** the shell default pays the 4 s bound
  once per process.

## [0.66.2] — 2026-09-03


### Fixed

- **v0.66.1's migrated-origin fast-fail never fired on a real run
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639)).** The guard read `page.url` once,
  at `get_ui_driver` entry — but `routes.project_editor_url` only ever builds a `labs.google`
  URL and the hop to `flow.google.com` is a *post-`goto`* redirect that neither settle path
  waits for (no locale → `_settle_if_redirecting` returns immediately; a known locale →
  `await_url_settled` short-circuits because the labs URL already matches the localised shape).
  So the guard classified a pre-redirect URL, declined, and the run paid ~54 s before failing
  anyway through the slow selector-probe path. Measured by the reporter on three consecutive
  v0.66.1 runs: **57.0 / 57.1 / 58.3 s**, with `ui_driver.migrated_host_bail` absent from the
  timeline entirely. The host check is now a shared `raise_if_migrated` helper called at the
  three points the run is *about to spend time* — `get_ui_driver` entry, each `detect_ui_mode`
  poll tick, and `_exit_agent_mode` once the media panel is found absent — so it adds no wait
  and no navigation to the old host, and aborts as soon as the redirect is observable. The
  event now names its call site, so the fast path is visible in a field timeline instead of
  inferred. Two blanket `except Exception` handlers that would have demoted the abort to a
  warning now re-raise it.

- **A `NOT_REDIRECTED` locale cache was an absorbing state, which made the #643 `<html lang>`
  recovery unreachable on exactly the profiles that needed it
  ([#643](https://github.com/ffroliva/gflow-cli/issues/643)).** `_bootstrap_and_resolve_locale`
  returned *before* `_resolve_account_locale` — the only site of that recovery and the only
  caller of `next_locale_state` — so nothing could ever move a latched profile off the state.
  Every profile that saw two migrated loads on ≤0.66.0 latched this way. `NOT_REDIRECTED` now
  skips the settle only, and still reads the locale: measured 56/56 on a latched profile whose
  page declares `lang="en"` on every load. The 4 s settle stays skipped — deleting the early
  return outright was rejected, because on that account the cached "not redirected" is a true
  observation.

- **A `<html lang>` locale was treated as evidence that Flow redirects the account, which
  switched the URL settle back on permanently ([#643](https://github.com/ffroliva/gflow-cli/issues/643)).**
  Shipped in v0.66.1 and present on `develop`: #643's `<html lang>` fallback returns a segment for
  an account Flow serves **bare** and never redirects, and `next_locale_state` recorded it as the
  cached state. Every later bootstrap then saw `cached != NOT_REDIRECTED`, settled, and burned the
  full 4 s `URL_SETTLE_TIMEOUT_MS` waiting for a redirect that never comes — the exact cost #587
  exists to remove, on any non-redirecting account with a `lang` attribute. Only a **URL-derived**
  segment is now folded into that cache; the lang-derived one is used in-process to build URLs and
  never persisted. Measured on a real profile: warm bootstrap **7.41 s → 2.66 s**, with the locale
  still recovered.

- **`docs/MCP.md`'s retryable-class list was incomplete**, which would have told an MCP agent not
  to auto-retry failures the envelope marks `retryable: true`. It omitted `FlowHostMigratedError`,
  `UiModeUnavailableError` and `SyncPartialError`; it now matches `errors.RETRYABLE_ERRORS`.

## [0.66.1] — 2026-09-03


### Fixed

- **A migrated-origin run spent ~36 s discovering a failure knowable in microseconds
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639)).** `flow.google.com` renders none
  of the controls gflow drives, so every DOM probe is doomed before it starts — yet the run
  still burned the full `detect_ui_mode` poll window (~8 s, both arms missing), the crop
  selector cascade (~24 s) and the URL settle (4 s) before raising `FlowHostMigratedError`.
  Because the rollout flaps per page load and callers retry on exit 36, that cost was paid on
  **every attempt** of a retry loop. `get_ui_driver` now checks the host first and fails fast
  with the same retryable exit 36. The old host is untouched and still gets full DOM detection;
  a page whose URL cannot be read still probes rather than bailing, so a transient is never
  mistaken for a migrated origin.

- **Locale resolution was blind on `flow.google.com`, and silently discarded a locale it had
  already learned ([#643](https://github.com/ffroliva/gflow-cli/issues/643)).** The migrated
  origin serves `/project/<id>` with no `/fx/<locale>/tools/flow` segment, so
  `locale_segment_from_url` could never match there. The locale had not disappeared — it moved
  into `<html lang>`, which stays correct on the migrated host. Two measured consequences:
  `next_locale_state("pt", None)` returned PROVISIONAL, **demoting** an already-learned locale
  on every migrated load (so a fully-migrated account could never learn it again, undoing
  [#587](https://github.com/ffroliva/gflow-cli/issues/587)); and `await_url_settled` burned the
  full 4 s timeout per navigation waiting for a shape that can no longer exist. gflow now falls
  back to `<html lang>` when the URL carries no segment, and skips the settle wait entirely on
  the migrated origin.

  The fallback is evidence-backed, not assumed: measured on two accounts (`en` and `pt-BR`),
  `<html lang>` **agreed with the URL segment wherever both existed**. Unlike
  `navigator.language` — which reports the value gflow itself sets — it is server-rendered by
  Flow. Where Flow does state the locale in the URL, that stays authoritative.

## [0.66.0] — 2026-09-03


### Fixed

- **Flow's migration to `flow.google.com` was reported as selector drift
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639)).** Google is moving Flow
  off Labs onto its own origin. The migrated frontend renders **zero** Material Symbols
  `<i>` elements, so every gflow selector — cohort detection included — misses at once,
  and the run died with `UiSelectorDriftError` (exit 23, `retryable: false`): an error
  that reads like the selectors rotted and sent operators hunting for the wrong cause.
  The rollout **flaps per page load** — the same account and project land on the old
  host on one navigation and the migrated one on the next — so a re-run frequently
  succeeds, but the non-retryable classification made automated callers give up.
  gflow now recognises the migrated origin and raises the distinct, **retryable**
  `FlowHostMigratedError` (exit 36) naming the migration. Applies to CLI and MCP alike
  (both route through the shared mode-switch raise site, and `retryable` has a single
  source of truth). **This does not add support for the migrated frontend** — that is
  separate work; see [KNOWN_ISSUES.md](KNOWN_ISSUES.md).

- **A migrated page load was misread as a logged-out session
  ([#639](https://github.com/ffroliva/gflow-cli/issues/639)).** `_check_logged_in`
  hard-required `labs.google` in the URL, so a perfectly valid authenticated session on
  the migrated host failed the gate and drove a pointless re-auth. It now accepts both
  Flow origins.

### Security

- **The authenticated-session URL gate matched hosts by substring.** `_check_logged_in`
  tested `"labs.google" in page.url`, which any foreign URL satisfies merely by carrying
  the string in its path or query (`https://evil.example/?next=labs.google/fx/tools/flow`).
  The host is now parsed and matched exactly.

### Changed

- Incident bundles from a `flow.google.com` load previously reported
  `url.host_category: "other"` / `url.route: "other"`, hiding the most useful fact about
  the failure. The migrated origin is now classified as `flow_app`, with the same
  identifier reduction applied.

Live-verified 2026-09-03 at zero credits against the **real** migrated frontend, on an
account inside the rollout: `flow_host_kind: "migrated"`, `_check_logged_in: true` (it was
`false` before the fix), and `_mode_switch_error` returning `FlowHostMigratedError` / exit 36 /
`retryable: true` — while a credit-free `image t2i` minutes earlier landed on the old host and
completed exit 0, proving no regression. See
[docs/LIVE_VERIFICATION_v0.66.0.md](docs/LIVE_VERIFICATION_v0.66.0.md).

## [0.65.0] — 2026-09-02


### Fixed

- **`gflow video chain` and `gflow movie run` died MID-SPEND on `duration` × `model`
  ([#634](https://github.com/ffroliva/gflow-cli/issues/634),
  [#635](https://github.com/ffroliva/gflow-cli/issues/635)).** The same defect
  [#632](https://github.com/ffroliva/gflow-cli/pull/632) fixed for single-clip i2v, but
  on these two surfaces it crashed *after* earlier links or scenes had already rendered
  and billed — surfacing as exit 1 `"Unexpected error"` with the explanation lost.

  For chains it was not an occasional mismatch but a **guaranteed** crash:
  `supports_duration()` is True for `omni_flash` alone, and chains reject `omni_flash`, so
  no model a chain can use has a duration control. Every manifest `duration` was
  unsatisfiable by construction — **including the one shipped as the documented example**
  in `docs/USAGE.md`, which a test pinned as valid.

  Tracing it surfaced a second hole: the `omni_flash` rejection only ever tested the
  *chain-level* model, while `_build_link_request` prefers a per-link override — so
  `"model": "omni-flash"` on a link walked past the invariant. Both now validate every
  link's effective model before link 0 renders, and `--dry-run` refuses what the real run
  refuses.

  **BREAKING:** a `movie.toml` scene pairing a Veo model with a `duration` parsed before
  and now fails at parse with exit 11. That combination could never have rendered; it
  previously failed later and more expensively. Scene `duration` requires
  `model = "omni-flash"`.

- **`gflow video i2v --duration` with no `--model` died as `"Unexpected error"`
  ([#630](https://github.com/ffroliva/gflow-cli/issues/630)).** An omitted `--model` on
  i2v is not "no model" — it binds `veo-lite`, which renders no duration control, so the
  guard was bypassed in exactly the default case and the DTO's bare `ValueError` escaped
  as exit 1. It now exits 2 naming the model and the fix. MCP had the same hole and
  queued the task before failing; `gflow_generate_video` now returns a 400 up front.

- **The `referenceEntity` guard was unobservable, and its e2e could not fail
  ([#620](https://github.com/ffroliva/gflow-cli/issues/620)).**
  `tests/e2e/test_entity_smuggling_e2e.py` wrapped both checks in `if bodies:` /
  `if modified:`, so it passed whether the guard fired or never fired — and the second
  block only *printed*. It sat through #615 without noticing.

  Fixing the assertions alone would not have been enough: the guard logged only when it
  *stripped* something, so "never ran" and "ran, nothing to strip" were identical silence.
  `ui_automation.batch_request_intercepted` now fires on every intercepted request from a
  `finally` — every exit, including the parse-error branch — carrying
  `had_reference_entities`, `modified` and `outcome`. **Absence of the event is now
  evidence**, which is what turned the question blocking #615's fix into a measurement.

- **Image e2e tests were priced in credits they do not cost.** `pyproject.toml` markers,
  `docs/E2E_TESTING.md`'s cost table, `tests/e2e/conftest.py`, `CONTRIBUTING.md`,
  `docs/USER_GUIDE.md` and ~20 strings across 13 files claimed image generation spends
  credits. Only video (Veo) does; images draw on a **daily cap**, which is a rate limit,
  not a charge. `scripts/canary/run_canary.py` carried the same error as a code constant
  misnamed for four of its five entries (`_CREDIT_MARKERS` → `_MANUAL_ONLY_MARKERS`,
  behaviour unchanged — the refusal is about not driving a live browser unattended). A
  cost model that overstates the price of a free test discourages running it, and the test
  it discouraged is the one that would have caught #615.

- **The `referenceEntity` guard never ran, on any image or video generation
  ([#615](https://github.com/ffroliva/gflow-cli/issues/615)).**
  `_intercept_reference_entities` strips character entities the caller did not
  request, so a "poisoned" entity left in the Flow composer cannot smuggle itself
  into an unrelated generation. It had never fired once, on any released version.

  The route glob `**/batchGenerateImages` requires the final path segment to equal
  `batchGenerateImages`, but the real endpoint is `.../flowMedia:batchGenerateImages`
  — so it could never match. The **video** guard was dead for the same reason
  (`.../video:batchAsyncGenerateVideoText`), which the original report does not
  mention. Registration also moved from the page to the browser context, which
  covers worker-delegated requests the page level cannot observe.

  The failure was invisible because the response listener does a substring test and
  kept working normally, and because the guard logged only when it *stripped*
  something — so "never ran" and "ran, nothing to strip" were identical silence. It
  failed **open**, quietly. Reported by
  [@DioServis](https://github.com/DioServis), who separated both causes.

  **Verified live**, A/B-controlled at zero credits: with the fix absent the guard
  never fired and the test failed; with it present the guard fired and the test
  passed — same account, same prompt, one variable. That also settles whether Flow
  delegates to a dedicated Web Worker (it does; `context.route` suffices) and
  confirms the request rewrite does not corrupt the body. See
  [docs/LIVE_VERIFICATION_reference_entity_guard.md](docs/LIVE_VERIFICATION_reference_entity_guard.md).

  **Coverage is partial by construction:** direct-wire routes issued through
  Playwright's `APIRequestContext` are not routable at all and bypass the guard
  regardless of matcher — tracked in
  [#619](https://github.com/ffroliva/gflow-cli/issues/619).

## [0.64.0] — 2026-09-02

### Added

- **`gflow video i2v --model omni-flash --end-frame` now works** ([#626](https://github.com/ffroliva/gflow-cli/issues/626)).
  Google shipped first-and-last-frame generation for Omni 1.1 Flash, so the
  guard that rejected that combination with exit 17 is gone:

  ```bash
  gflow video i2v ./start.png "she turns toward the window" \
      --model omni-flash --end-frame ./end.png --duration 10
  ```

  omni-flash is the only model that also exposes `--duration`, so this is the
  one route to a 10-second first+last interpolation.

### Changed

- **i2v end-frame safety moved from a static table to a post-submit route
  check.** gflow used to decide which models could carry an end frame from a
  hardcoded capability list, which silently went stale when Google shipped the
  feature. It now verifies the route Flow *actually* used: a run that carried an
  end frame but came back on `batchAsyncGenerateVideoStartImage` — Flow dropping
  the frame at submit and billing a clip that was never interpolated — fails
  with `WireFormatError` instead of being reported as a success. This also
  catches a partial or staged rollback on any account, which the old table
  could not.

  **Breaking for scripts** that branched on exit 17 for `omni-flash` +
  `--end-frame`: that combination now succeeds. Exit 17 is unchanged for
  `gflow video chain --model omni-flash`, which is still rejected (chain-scale
  seeded i2v remains unverified).

- **MCP↔CLI parity is now a duty of every pipeline phase** (contributor-facing).
  `tests/mcp/test_cli_parity.py` is command-level: it fires when a new CLI *leaf*
  lacks a mapped MCP tool, and stays green while an option goes unmirrored, a
  queued-payload key goes unread, or a tool docstring asserts a restriction the
  CLI no longer has. #626 shipped exactly that third case — `mcp/tools.py` and
  `docs/MCP.md` kept telling agents `omni_flash` was rejected for i2v-with-frames
  through a fully green pipeline. Each skill now owns a slice: `issue-assessment`
  names affected surfaces, `predict` scopes the MCP blast radius, `scenario` adds
  **D13**, `plan` makes the MCP mirror **task 6** (not optional when task 5
  exists), `pr-council-review` adds **D15**, `check` adds **step 1b** (the
  canonical six mirror axes), `live-verify` treats the MCP queued path as
  separate code, and `doc-review` grades a *false* MCP claim as release-blocking.
  Automating the mechanically checkable part is tracked in
  [#628](https://github.com/ffroliva/gflow-cli/issues/628).


### Fixed

- **`AGENTS.md`'s Impeccable Routine was missing `generate_website_docs.py --check`**,
  which `skills/check` already ran. Following the shorter list produced a green
  local run against a stale `website/docs/` mirror and a red CI. The two lists now
  agree.

## [0.63.0] — 2026-09-01

### Added

- **`gflow video extend` — continue a clip past Flow's 8-second ceiling.** Veo's
  extend route generates a new 8s segment seeded server-side from the source
  clip, so motion and audio carry across the join instead of restarting from a
  still (which is what `video chain` does, and why it needs a fade guard). Pass
  one prompt per segment, or `--segments N` to reuse the last one:

  ```bash
  gflow video extend <media-id> "the wave recedes" --project <id>
  gflow video extend <media-id> "drifts out to sea" --project <id> -n 4 -o long.mp4
  ```

  The result is a Flow Scene; `-o` renders it to a single mp4 through the
  existing credit-free server-side concat.

  > Known limitation, found in live verification: a segment carries ~7s of real
  > content though Flow advertises and bills 8s, so each internal seam of a
  > multi-segment render is preceded by ~1s of frozen frame and silence. Single
  > segments are unaffected. Details and the open questions are in
  > [KNOWN_ISSUES](KNOWN_ISSUES.md).

  - **The model key is resolved per run, never hardcoded.** Flow's extend family
    is tier-gated — `_ultra` variants are Advanced-only and read `UNAVAILABLE`
    elsewhere — so the key comes from the account's own capability listing,
    picking the cheapest orderable model exactly as Flow's own UI does. A pinned
    key would 403 forever on the wrong tier.
  - **Costs are shown before anything is submitted**, and a pre-flight balance
    check refuses a run the balance cannot finish. `--dry-run` prints the plan
    without opening a browser.
  - **Serial by construction, and paced.** Segments submit one at a time with a
    non-zero default jitter (`GFLOW_CLI_JITTER_RANGE`). A refusal aborts with
    completed segments preserved and is never auto-retried.
  - `1:1` is refused up front — Flow publishes no square extend model.


### Fixed

- **Ctrl+C during a billed run said nothing.** `run_with_handlers` exited 130
  silently, so a user who interrupted a multi-segment run could not tell whether
  anything had been charged or how to resume. It now reports credits spent,
  segments completed and the resume handle. Fixed at the shared boundary, so
  `video chain` and `movie run` gain it too.
- **`sessionId` was not redacted.** `redact_metadata` covered `token` and
  `recaptchaToken` but not `sessionId`, which the extend request carries. Not a
  credential, but account-correlatable, and it would otherwise reach any logged
  request body or diagnostics bundle verbatim.

- **The offline test suite could `git checkout develop` in the developer's own
  clone ([#605](https://github.com/ffroliva/gflow-cli/issues/605)).** git's
  repository discovery walks *up* from `cwd`, and `--basetemp=tmp/pytest` puts
  every `tmp_path` inside this repository, so an autopilot test whose temp `.git`
  went missing had its `git checkout develop` silently resolved against the real
  working tree — moving the developer off their branch mid-run (reflog-confirmed,
  Windows-only, intermittent). Two independent guards now close it:
  `scripts/autopilot/pr_triage_autopilot.py` pins every git call with
  `--git-dir`/`--work-tree`, so a `repo_dir` that is not a repository fails loudly,
  raising with git's own `fatal: not a git repository` text rather than
  retargeting whatever clone encloses it (this also
  hardens the VPS triage path against a mistyped `--repo-dir`), and
  `tests/conftest.py` sets `GIT_CEILING_DIRECTORIES` to pytest's basetemp so no
  test can walk out of its temp dir into this repo. What removed the temp `.git`
  is still unexplained — it now surfaces as a plain "not a git repository" rather
  than a silent branch switch.

## [0.62.1] — 2026-08-30


### Fixed

- **`--model omni-flash` was unselectable after Flow renamed the picker entry
  `Omni Flash` -> `Omni 1.1 Flash`
  ([#604](https://github.com/ffroliva/gflow-cli/pull/604)).** Every explicit
  `--model omni-flash` run failed with `VideoModelSelectionError` (exit 18) — the
  fail-loud gate worked, so no credits were spent and nothing was billed to the
  wrong tier, but the model could not be chosen. The selector now spans the
  injected version segment, so it matches the old label, the current one, and the
  next bump, while staying unique against the four `Veo 3.1 - *` tiers and
  excluding any future `[Lower Priority]` Omni variant. The same
  literal is fixed in `scripts/dev/spike_omni_flash_i2v_ui_recon.py`. The CLI
  alias (`--model omni-flash`) and the enum value (`omni_flash`) deliberately did
  not change — they are gflow's own contract for chain files, resume state, and
  JSON output. Why `has-text` broke, and when *not* to widen a selector this way:
  [KNOWN_ISSUES.md](KNOWN_ISSUES.md), 2026-08-30 correction.

### Added

- **[`docs/ACCOUNT_SAFETY.md`](docs/ACCOUNT_SAFETY.md) — one honest page answering
  "will this get my account flagged?"
  ([#602](https://github.com/ffroliva/gflow-cli/issues/602)).** Two Reddit
  commenters asked the same question from opposite directions on the same day, and
  the answer existed only as fragments across README, `DISCLAIMER.md`,
  `DEBUGGING § WAF cadence`, `KNOWN_ISSUES` and `CONFIGURATION` — findable if you
  already knew where to look, invisible to someone deciding whether to install.
  The page separates the three things people conflate (a quota limit, a per-profile
  WAF block, an account ban — only the first two have ever been observed here),
  states what the tool does to stay unremarkable (headed real Chrome because
  headless is an instant 403, ±25% randomisation on every interaction, 0.5–1.5 s
  submission pacing, one project per multi-prompt run, isolated per-account
  profiles, refuse-don't-retry), what it deliberately does **not** do (no proxy
  rotation, no fingerprint spoofing beyond the opt-in patched engine, no headless
  unlock, no pretence that it isn't automation), the knobs worth turning, the
  [#241](https://github.com/ffroliva/gflow-cli/issues/241) field data on what
  actually triggered a 403, and what cannot be promised. Linked from the README
  banner, `docs/INDEX.md`, and back-linked from all three deep sources; published
  to the docs site under Getting started.

- Clarified in [CONFIGURATION](docs/CONFIGURATION.md#gflow_cli_jitter_range) that
  `GFLOW_CLI_JITTER_RANGE` paces *submissions between prompts* and is a different
  mechanism from the always-on ±25% per-interaction randomisation — the two were
  easy to read as one knob.

## [0.62.0] — 2026-08-28

### Changed

- **`--ui-mode auto` (the default) now requires the *classic* Flow arm for image
  generation ([#595](https://github.com/ffroliva/gflow-cli/issues/595)).** `auto`
  used to bind whatever the composer rendered, so an account that Flow moved into
  its **agentic** cohort — observed live on two accounts on 2026-08-27 — took a
  path that cannot satisfy an image request and failed with either
  `image_mode_tab` selector drift (exit 23) or a `WireFormatError` about video
  bytes. Neither error named the cause, and the workaround
  (`GFLOW_CLI_PREFER_CLASSIC=1`) had to be discovered from an error message.
  `auto` now means "no arm was asked for" and resolves to `classic`, matching the
  rule video has followed since [#299](https://github.com/ffroliva/gflow-cli/issues/299).
  The bind still attempts classic recovery first and the cohort flaps per page
  load, so a run only aborts (`UiModeUnavailableError`, **exit 28**, pre-submit,
  zero credits) when the arm is genuinely pinned — and that abort is retryable.
  The agentic arm stays reachable, but only when asked for by name
  (`--ui-mode agentic` / `GFLOW_CLI_UI_MODE=agentic`) or by need (`-i` agent
  instructions, which are agentic-only and still force it). The image **batch**
  path carried its own inline mode resolution and so kept binding `auto`; it now
  routes through the same policy as the single-prompt path.


### Fixed

- **An announcement modal that mounts *during* a batch generation no longer
  silently changes the next prompt's settings**
  ([#593](https://github.com/ffroliva/gflow-cli/issues/593) follow-up). #593 left a
  stated gap: call sites that neither route through `_probe_selector_cascade` nor
  sit behind a navigation gate were still unguarded, and the set had not been
  enumerated. Auditing all 73 click/fill/press sites in the UI transports found
  exactly one that survives the "can a modal actually land here?" test — the image
  **batch** loop's per-prompt boundary. A batch dismisses overlays once, during
  setup; from prompt 2 on, the settings clicks are the first act after a
  multi-second generation wait on a page that never navigates. This one is worse
  than a timeout: `_open_gen_settings_panel` returns `False` when no selector
  matches and the caller falls back to Flow's current defaults, so a modal that
  mounted during prompt 1 did not fail prompt 2 — it generated it at the wrong
  aspect/count. The boundary now runs the same `_require_unblocked` check the
  navigation epochs use (one probe on the happy path), so the run aborts with
  exit 23 and a screenshot instead of producing a quietly wrong image.

- **A Flow announcement modal no longer wedges a run with an unexplained timeout
  ([#593](https://github.com/ffroliva/gflow-cli/issues/593)).** When Google ships a
  feature, Flow puts a full changelog dialog over the editor and sets
  `body { pointer-events: none }` while leaving the app neither `aria-hidden` nor
  `inert` — so every control reads visible and enabled yet never receives a click,
  and Playwright's actionability wait runs to timeout with no message. Measured live
  on two accounts (2026-08-27, pt and en), which is also how the four failure paths
  below were found:
  - The gallery "+ New project" sweep ran with **no overlay check at all** — the one
    navigation epoch that had none. A modal there cost 18 selectors x Playwright's
    30 s default click timeout and then reported `Could not find 'New project' CTA`,
    which is the wrong error about the wrong thing. It now dismisses first and the
    click carries an explicit 5 s timeout.
  - Dismissal **verifies itself**. It previously returned success the moment a click
    landed, so a dismissal that changed nothing still logged `overlay_dismissed` and
    the run timed out somewhere unrelated — the success event lied. It now re-probes
    and reports honestly, with a new `ui_automation.overlay_postmortem` warning.
  - A persistent block now **aborts pre-submit at $0** with exit 23 and a screenshot
    (probe `overlay_close_button`) instead of hanging. A transient is not enough to
    trigger it: Flow's own menus set the same property while open, so the guard
    re-probes after a settle.
  - **The modal can mount *after* the navigation gate**, which is how it kept winning.
    Flow hydrates on its own schedule, well past `domcontentloaded`, so dismissal at
    the navigation boundary can run before the dialog exists — then the dialog appears
    and covers a control that is present and enabled, and the selector cascade reports
    drift for an element that is perfectly fine. A failed probe now checks the overlay
    state before believing itself, and dismisses and re-probes once. The guard lives in
    the one cascade every probe routes through, so all ten call sites are covered.
    Verified live on a third account (2026-08-27): before the fix, `image_mode_tab`
    raised `UiSelectorDriftError` with the announcement on screen and **no
    `overlay_detected` in the log at all**; after it, the same command on the same
    account cleared the modal (`setLastAcknowledgedChangeLogId` → 200, 23 s in, i.e.
    from the probe guard rather than the navigation gate) and left the editor
    reachable.
  - The destructive Escape fallback is now **gated on the page actually being
    blocked**, which retires the [#395](https://github.com/ffroliva/gflow-cli/issues/395)
    hazard structurally rather than by comment. That regression pressed Escape on the
    character composer and sent a generation out without `entityContext` — billed,
    silently wrong. A page we can positively see is clickable is never touched.

  Two raw-`goto` e2e tests (`test_sidebar_recovery_e2e`, `e2e_auth` — the nightly
  canary's default tier — and `test_agentic_count_enforcement_e2e`) bypass every
  transport boundary and were unprotected; both now dismiss explicitly, and both stop
  hardcoding `"en"` in favour of the account's own locale (#587).

  **One deliberate behaviour change.** The close-button cascade is now split: the
  changelog-scoped anchor (`[role='dialog']:has(a[href*='changelog']) button`) runs on
  any page because it cannot match one of Flow's own surfaces, while the generic
  selectors (`button:has(i:text('close'))` and friends) and the Escape fallback run
  only once the body is known to be blocked. The cost is that a non-modal banner —
  one that covers a control without blocking the body — is no longer auto-closed by
  the generic selectors. That is the right side of the trade: those same generic
  selectors match the character composer's own close button, #395 spent real credits
  through exactly that door, and `KNOWN_ISSUES` rates the banner case Low and
  transient.

### Added

- **`gflow project list` / `project show` and the MCP `gflow_list_projects` tool now
  emit an account-correct editor URL
  ([#587](https://github.com/ffroliva/gflow-cli/issues/587)).** They previously
  emitted no URL at all: they are network-free catalog reads, so they had no way to
  resolve a locale and correctly declined to guess one. With the locale now cached
  per profile the link is readable offline. An unknown locale still yields the bare
  URL — never a guessed `/fx/en/...`, which is the shape that started this thread by
  being handed to a pt-BR account owner. In the terminal the project id renders as a
  hyperlink, costing no column width.

### Changed

- **The account-locale probe no longer costs ~4 s on every command
  ([#587](https://github.com/ffroliva/gflow-cli/issues/587)).** The probe added in
  v0.61.0 settles the bootstrap navigation to learn where Flow lands. On an account
  Flow does *not* redirect there is nothing to settle, so `wait_for_url` ran to the
  full `URL_SETTLE_TIMEOUT_MS` every single invocation. Measured live 2026-08-27,
  best-of-N per arm: **~6.2 s -> ~2.0 s** setup on the non-redirecting account,
  against an unchanged ~2.8 s -> ~2.9 s on a redirecting one (the control, which
  shows the cold-then-warm ordering is worth nothing on its own). Run-to-run
  variance is over a second, so read the delta as "the 4 s settle timeout", not to
  two decimals.
  The outcome is cached in the profile dir (`.gflow_locale`, a sibling of the
  existing `.gflow_account`). The same guard covers all four `await_url_settled`
  call sites **in the UI transport**; guarding only the editor entry left three
  navigations still paying the timeout. (The three sites in the experimental REST
  transports have no resolved locale to gate on and are unchanged.)

  The cache decides only *whether to wait*, never *where to navigate*. Sending the
  browser to a cached `/fx/{seg}/...` was built, measured, and rejected: Flow
  serves whatever segment it is asked for, so a pt-BR account handed `/fx/de/`
  stayed there and rendered `html lang=de` with no redirect — no correction signal,
  and a wrong-language UI for as long as the stale value lived. That is #580's
  defect in a new hat. The navigation therefore stays bare, which is what lets Flow
  state the account's own answer. Reproducer: `scripts/dev/spike_locale_poison.py`.

  The cache holds **four** states, and the fourth is what keeps it honest.
  `await_url_settled` returns `None` for both "Flow does not redirect this account"
  and "the settle timed out this once", so one slow network could otherwise commit
  to "not redirected" permanently and silently restore #580's post-`goto` race. A
  no-redirect observation is therefore **provisional** until a second run agrees;
  a transient timeout costs one extra probe instead of a lasting defect.


### Fixed

- **A NULL `model` / `aspect` / `project_id` no longer reads back as the string
  `"None"` in `gflow data list images|videos`.** All three columns are nullable in
  the schema (`assets.model`, `assets.aspect_ratio`, `assets.flow_project_id`), but
  both listing constructors wrapped them in a bare `str(...)`, so a NULL became the
  four-character string `"None"` — emitted verbatim into `--json` and
  indistinguishable from a real value. `_row_to_operation_error` in the same module
  already guarded `model` correctly; the two listing paths never got the same
  treatment. `ImageRow` / `VideoRow` now type these fields `str | None` and the JSON
  output carries `null`.

## [0.61.0] — 2026-08-27


### Fixed

- **A requested image model that cannot be selected no longer generates silently
  on a different one ([#586](https://github.com/ffroliva/gflow-cli/issues/586)).**
  `_select_image_model` swallowed every failure, logged a warning, and let the
  generation proceed on whatever the project's picker already held. Observed
  live: `--model imagen4` produced an image on `NARWHAL` and exited **0** —
  confirmed three ways (log, catalog, and `imageModelName` in a HAR). Flow has
  removed `Imagen 4` from its picker, and `has-text('Nano Banana 2')` had become
  ambiguous with the newly-offered `Nano Banana 2 Lite`, so `.first` resolved by
  DOM order. A missing or ambiguous selector now raises `UiSelectorDriftError`
  (exit 23) naming what Flow actually offered, before anything is submitted.

- **A requested video model that cannot be selected no longer generates on a
  different one — and charges for it
  ([#539](https://github.com/ffroliva/gflow-cli/issues/539)).** `_select_video_model`
  refused only on i2v-with-frames; a plain `t2v`/`r2v` miss logged "Flow default
  model applies" and returned, so the run generated on whatever the picker already
  held and spent that tier's credits — veo-quality costs 100 against veo-lite's 10.
  Read live, Flow's picker offers exactly `Omni Flash` / `Veo 3.1 - Lite` / `Fast` /
  `Quality`, so `--model veo-lite-lp` matched nothing and was a reachable,
  credit-spending wrong-model path. Every miss is now fatal (exit 18) naming what
  Flow offered, and an **ambiguous** selector is refused rather than resolved with
  `.first`, which picks by DOM order across tiers that differ 10x in cost. Unlike
  the image arm, refusing is unambiguous here: `--model` defaults to `None` on
  every video command, so reaching the picker means a model was explicitly asked
  for. Verified with a zero-credit A/B against live Flow — the pre-fix code
  returned success for a model Flow does not offer; the new code refuses.

- **Four more navigations settle before acting on the page
  ([#584](https://github.com/ffroliva/gflow-cli/issues/584)).** #580 settled the
  three sites it touched; an audit of every `page.goto` found four more with the
  same defect. The worst is `evaluate_fetch.refresh_auth`, which re-navigates to
  refresh page-context tokens and reported success while the page was still
  moving. Two more (`evaluate_fetch` setup, `sapisidhash` fingerprint capture)
  run `page.evaluate` immediately after navigating, where a mid-flight redirect
  raises "Execution context was destroyed" rather than failing quietly. The
  fourth (`_enter_editor`'s gallery return) ran `_bypass_onboarding` — real
  button clicks — on a page about to navigate away. A new AST-based test pins
  every `goto` to a following settle, so the audit does not have to be redone
  by hand.

- **The nightly canary now runs the version of itself that it just pulled
  ([#582](https://github.com/ffroliva/gflow-cli/issues/582)).** `run_canary.py
  --pull` fast-forwards the checkout and then keeps executing the copy Python
  loaded at startup, so every runner change was silently one night late. This was
  not theoretical: #572 added `-o junit_logging=all` so a preserved RED would
  carry the structlog line that decides #561, and the next run pulled it and
  still produced a RED with zero log output — three REDs untriageable, and the
  failure reads as "the fix did not work". The runner now re-runs itself once
  when a successful pull changed its own source, guarded by both an env var and
  a content digest (either alone prevents a loop), via `subprocess.run` rather
  than `os.execv` so Task Scheduler still sees one process and the real exit code.

- **Editor navigation no longer races a locale redirect on non-`en` accounts
  ([#580](https://github.com/ffroliva/gflow-cli/issues/580)).** `_enter_editor`
  built its URL from a hardcoded `locale="en-US"` that no caller ever overrode,
  so every account was sent to `/fx/en/...`. On a pt-BR account Flow redirects
  that to `/fx/pt/...` **after `page.goto` has already returned** — leaving
  overlay dismissal and prompt submission running against a page about to be
  navigated away. That is how [#395](https://github.com/ffroliva/gflow-cli/issues/395)'s
  "character-route bounce" presented. The client now learns the account's real
  locale from where Flow itself lands (the only trustworthy source: `auth/session`
  carries no locale, and `navigator.language` reports the value gflow sets when
  launching the context), hands it to the transport through the typed
  `TransportSetup` seam, and an independent settle-wait tolerates any redirect we
  did not predict. An unresolved locale omits the segment rather than guessing.
  `gflow character create --locale` now defaults to the account's locale instead
  of `en-US`; the previous hardcoded default meant the character editor — the
  surface #395 was reported against — was still routed to `/fx/en/...` on every
  account, and the character route never waited for a settle at all.

  Live-verified on a pt-BR account with a control arm: the fix navigates
  race-free while the pre-fix path still redirects. Accounts Flow does not
  redirect (e.g. `en`) skip the wait entirely after a single bounded probe, so
  they pay no per-navigation cost.

### Added

- **Server-side model attribution
  ([#586](https://github.com/ffroliva/gflow-cli/issues/586)).**
  `parse_media_attribution` reads `modelNameType` / `seed` / `aspectRatio` from
  the `flow.projectInitialData` listing gflow already fetches — the same payload
  the sync path walks for `name` and discards the rest of. This matters most on
  the **agentic** arm, where those fields were previously synthesised from our
  own request because they live in a Web-Worker SSE stream Playwright cannot
  observe; "not visible to the page" was never the same as "unknowable". Verified
  live: an agentic run that requested `GEM_PIX_2` was attributed `NARWHAL` by the
  server, with a real seed where the catalog held `0`.

## [0.60.0] — 2026-08-25

### Added

- **Selector registry + nightly CI drift probe
  ([#404](https://github.com/ffroliva/gflow-cli/issues/404),
  [#493](https://github.com/ffroliva/gflow-cli/issues/493),
  [#313](https://github.com/ffroliva/gflow-cli/issues/313)).** New
  `gflow_cli.flow_selectors` package: a structured, enumerable inventory of the
  Flow DOM selectors gflow depends on (`Surface`, `Selector`) plus a pure
  grader (`HIT` / `FALLBACK` / `AMBIGUOUS` / `MISS` / `EXPECTED_ABSENT`), so
  selector drift is *named* rather than inferred from a failing test. A $0
  probe (`scripts/probe/run_probe.py`, driven by the `selector-probe` workflow
  on `schedule` + `workflow_dispatch` only) walks the registry against a live
  editor: navigate and read only, never generates. Exit 0 clean / 1 drift /
  2 inconclusive — an expired token or dead project is never published as
  drift.

- **Incident bundles record what was submitted
  ([#528](https://github.com/ffroliva/gflow-cli/issues/528)).**
  `network.json` gains a `generation_requests` array carrying a counts-only
  summary of each outgoing generation submit (body size, reference-entity
  count, reference-field count). The reference shape that triggers a policy 400
  was previously visible only in the stderr stream, so bundles attached to an
  issue could not be diagnosed. Counts and booleans only — no key names, field
  values, or prompt text — matching the existing §5.3 retention boundary.

### Changed

- **All labs.google requests now carry `origin`/`referer`
  ([#578](https://github.com/ffroliva/gflow-cli/pull/578)).** Header
  construction moved into a single `_request_headers()` shared by
  `_post_json`/`_patch_json`/`_get_json`, which previously assembled headers
  inline three times and could diverge per verb. The labs lane now sends the
  same `origin`/`referer` every other lane already sent. A live A/B against
  `project.createProject` showed these headers are **not** required — an
  origin-less mutation still returns 200 — so this is consistency and
  defence-in-depth, not a fix for any observed failure.


### Fixed

- **Content-policy 400s are no longer misclassified as `WireFormatError`
  ([#528](https://github.com/ffroliva/gflow-cli/issues/528)).** An HTTP 400 from
  `flowMedia:batchGenerateImages` or `batchAsyncGenerateVideo*` now raises
  `ContentPolicyError` with remediation that names the levers that actually
  work — reduce to a single face-bearing reference, replace age-explicit person
  descriptors with relational or role nouns — and states outright that
  shortening the prompt does not help. Previously these surfaced as "the
  request was rejected as malformed… retry with a simpler prompt text", which
  sends operators down a path that cannot succeed. Same defect shape as
  [#379](https://github.com/ffroliva/gflow-cli/issues/379) (429), one status
  over, and the self-documenting-errors goal of
  [#380](https://github.com/ffroliva/gflow-cli/issues/380).
- **Video generation gained the 429 branch the image path got in #379.** A
  quota hit on `batchAsyncGenerateVideo*` raised `WireFormatError` instead of
  `RateLimitError`, losing `Retry-After` and the retryable classification.
- **`generate_images_batch` no longer reports a bare, remediation-free
  `GFlowError`** when every response failed — it classifies the first error the
  same way the single-prompt path does.

### Security

- **CI/CD supply-chain hardening
  ([#565](https://github.com/ffroliva/gflow-cli/issues/565)).** Every
  `actions/checkout` step now sets `persist-credentials: false` (12 existing
  steps fixed across `ci.yml`, `deps-watch.yml`, `governance-advisory.yml`,
  `governance-benchmark.yml`, `main-base-guard.yml`, `pages.yml` and
  `release.yml`); the default leaves the job token in `.git/config` for the rest
  of the job. No workflow needed it — releases publish over PyPI Trusted
  Publishing (OIDC) and Pages deploys over `actions/deploy-pages`. A new
  `workflow-audit` job runs [zizmor](https://github.com/zizmorcore/zizmor)
  (pinned, `--offline`) over `.github/workflows/` on every push and PR, so the
  class cannot come back. Its first run also caught two defects the manual pass
  missed: `${{ github.base_ref }}` interpolated directly into a
  `governance-advisory.yml` shell script (template injection — the value now
  arrives through `env:`), and a shared uv cache restored by the publishing
  release job (cache poisoning — caching is now off there). The
  `pull_request_target` trigger in `external-pr-triage.yml` is suppressed inline
  with its rationale, and a changelog-guard workflow was evaluated and declined
  — both decisions recorded in
  [docs/GITHUB.md § Workflow Security Gates](docs/GITHUB.md#workflow-security-gates).

## [0.59.0] — 2026-08-16

### Added

- **Refresh-on-miss: stale catalog names self-heal during generation
  ([#546](https://github.com/ffroliva/gflow-cli/issues/546)).** When a UUID
  reference's picker name-search misses (e.g. the asset was renamed in the
  Flow UI after being cataloged), the transport now consults the credit-free
  `flow.projectInitialData` listing once (~0.5 s) for the *current* name,
  retries the search exactly once, and attaches the existing tile — instead
  of silently downgrading to a duplicate upload. The fresh name is written
  back with `sync.source = "refresh"` provenance (`store` history mode only;
  `redacted` heals the run without touching disk). Applies to `image i2i
  --ref <uuid>` and `video i2v` frame refs; any resolver failure is logged
  and the pre-existing fallback chain proceeds unchanged. Completes the
  [#543](https://github.com/ffroliva/gflow-cli/issues/543) freshness model —
  see [MEDIA_LIBRARY § freshness](docs/MEDIA_LIBRARY.md).

- **`gflow doctor` — read-only pre-flight diagnostics
  ([#542](https://github.com/ffroliva/gflow-cli/issues/542)).** Ten checks
  across the catalog (missing display names / local files / sha256), the
  database (migration drift, WAL state + `PRAGMA quick_check`), stuck
  operations and queue tasks (24h recency threshold), and the environment
  (deprecated env vars, missing Playwright Chromium, auth profiles without
  cookies). Brew-doctor philosophy: diagnoses, never heals — nothing is
  migrated, repaired, or written, and all DB access is strictly read-only.
  Exit `0` when clean, `33` when any warn/fail finding is present (a
  successful diagnosis, not an error class); internal errors keep their typed
  codes (e.g. `16` for `DataStoreError`). `--json` emits an experimental
  machine-readable envelope (`overall_status` + per-check `checks[]` entries).
  Output is redaction-safe: rows are identified by UUID only, paths are
  sanitized, and under `GFLOW_CLI_HISTORY_PROMPTS=redacted` the display-name
  check reports info instead of warn. See
  [USAGE § `gflow doctor`](docs/USAGE.md#gflow-doctor).

- **`gflow data sync --names` — reconcile catalog display names from Flow's
  listing endpoint ([#543](https://github.com/ffroliva/gflow-cli/issues/543)).**
  Sweeps nameless catalog rows project-by-project via the credit-free
  `flow.projectInitialData` listing (~0.5s/project, session-cookie auth, no
  generation surface) and writes back the display names the picker searches
  by — restoring the [#529](https://github.com/ffroliva/gflow-cli/issues/529)
  picker contract (search by name, verify by UUID) for rows recorded before
  their caption existed. Rows whose media no longer exists remotely are
  ghost-marked `sync.status = "missing_remote"` (tombstones, never deletions)
  only when the listing is provably complete. Write-by-default with
  `--dry-run` preview; scoped via `--project` / `--limit` / `--since` /
  `--max-projects`; idempotent re-runs. Refuses under
  `GFLOW_CLI_HISTORY_PROMPTS=redacted` (exit `11`); exit `34`
  (`SyncPartialError`, retryable) when some projects fail mid-sweep. This is
  the remediation `gflow doctor`'s missing-display-name check points at. See
  [USAGE § `gflow data sync`](docs/USAGE.md#gflow-data-sync).

## [0.58.0] — 2026-08-16


### Fixed

- **R2V named remote references (`ref_names`) work again after Flow's picker
  redesign — live-verified end to end (#529 follow-up).** Two UI drifts had
  silently broken the name-attach path on every locale: the picker dialog no
  longer exposes an accessible tree, so the old ARIA role+name tile match could
  never find a result (the tile is now matched by its text, anchored so a
  substring name still cannot attach the wrong asset, tolerating the localized
  media-type badge the tile text appends, e.g. `…Imagem` on a pt profile); and
  clicking a result tile now attaches directly and closes the picker — the
  legacy include-button flow runs only if the dialog stays open. Proven by a
  new live e2e that seeds a t2i image, reads its recorded `displayName` back
  from the catalog by UUID, and generates a real R2V video with it
  (`tests/e2e/test_video_r2v_uuid_name_e2e.py`), alongside a new same-project
  image-picker e2e pinning the #529 exact-UUID-tile happy path.

### Changed

- **Catalog image UUIDs now resolve through Flow display names instead of
  scrolling or UUID/prompt searches (#529).** A headed-Chrome spike against a
  populated Compiled Growth story project proved the picker contract:
  catalog UUID → `workflows[].metadata.displayName` → browser name search →
  exact UUID-in-thumbnail tile. A duplicate-name search surfaced two distinct
  UUIDs and the exact matcher selected the requested identity, with zero scroll
  calls or generation requests. The UI response collector now preserves the
  sibling workflow name so new generated-image catalog rows retain the picker
  search key when prompt history is stored (`history_prompts=redacted` omits the
  potentially prompt-derived caption); image `--ref <uuid>` and I2V frame UUIDs
  are enriched with that name before browser work. UUID, UUID-stem, prompt-hint,
  and unfiltered-grid scroll fallbacks are removed from this path. Image refs
  retain their recorded local-file upload fallback; CLI and MCP I2V frames keep
  the UUID, name, and fallback together for both slots. Local fallbacks are used
  only when their recorded byte count/SHA-256 still matches. A missing/stale
  name or unavailable search input falls through to that verified upload or a
  typed failure—never an unfiltered viewport click, grid scan, or implicit
  Playwright scroll. UUID-backed I2V requests now also activate the post-submit
  route guard that rejects a credit-spent T2V response.
  This supersedes #287's prompt-hint and UUID-grid-scroll guidance; the sanitized
  evidence is recorded in the [#529 picker spike](docs/superpowers/spikes/2026-08-15-picker-tile-alt-text.md),
  and [#541](https://github.com/ffroliva/gflow-cli/issues/541) records the refuted
  prompt-hint hypothesis.

## [0.57.1] — 2026-08-14


### Fixed

- **`gflow video`/`image` can no longer get stuck behind Flow's expanded chat
  sidebar (#493).** Expanding the sidebar removes the classic composer
  **entirely** — no `crop_*` settings trigger *and* no Agent pill — which is
  exactly the fingerprint reported in #493 ("no `crop_*` settings button", "the
  Agente pill matches neither selector"). It also explains the exit code: with
  no agentic indicator on screen either, the cohort detector matches nothing, so
  the run dies as `UiSelectorDriftError` (exit 23) instead of the retryable
  agentic error (25). Recovery hinged on a single selector scoped to the
  sidebar's `edit_square` affordance; a cohort whose sidebar lacks that ligature
  never found the X, so the sidebar never closed and the composer never came
  back. `ensure_media_mode` now falls back to an unscoped close **only** from
  the demonstrably stuck state (no `crop_*` **and** no pill), where the classic
  composer is gone and there is nothing else a close button could belong to.
  Reproduced live and A/B-proven: with the scoped selector neutered the fallback
  recovers; with both neutered it does not.

- **`--duration` now fails fast instead of masquerading as UI drift (#451, #288).**
  Flow's video settings popover is **model-conditional**: only `omni-flash` renders
  a `4s/6s/8s/10s` row, and the Veo 3.1 models render **no duration control at all**
  — verified live on two accounts and two locales. `api/video.py` had claimed "the
  four `VEO_3_1_*` models cap at 8s", which presumed a control that is never drawn,
  so `_select_video_duration` hunted a missing element and died with
  `UiSelectorDriftError` (exit 23) after ~30 s. That is why the bug reproduced
  identically on playwright 1.59 and 1.61 (the version bound was correctly
  exonerated) and why the locale hypothesis was refuted — it was never either.
  `--duration` with a Veo model now exits **2 before any browser work**, naming the
  model and the fix. New `VideoModel.supports_duration()`; the DTO guards it too, for
  API callers.
- **`--reference-entity` no longer advertised on `video i2v`, where it always failed.**
  The flag was registered on `t2v`/`i2v`/`r2v`, but `_validate_i2v_symmetry` rejects
  reference entities on i2v — so the i2v form raised for every caller who believed
  the help text. It is now applied to `t2v`/`r2v` only. The reverse error was in the
  docs: `REFERENCE_STRATEGIES.md`, `USAGE.md` and the `t2v` help text all stated "the
  video path has no `--reference-entity` flag" while `cli_video.py` registered it —
  corrected in all four places.
- **A named remote reference that isn't in the picker now raises a typed error.**
  `--ref-name` searches Flow's picker, which indexes Flow's own short auto-caption —
  not the generation prompt — so a prompt passed as `--ref-name` surfaced as a bare
  Playwright `TimeoutError` after 8 s, with no exit code to branch on and no hint
  that the *name* was the problem. Now `ReferenceNotFoundError` (**exit 32**), listing
  what the picker actually offered.
- `reference_cap_for` now records the live-verified ingredient rule it already
  encoded: `veo-quality` refuses image ingredients (Flow: "You cannot use image
  ingredients with this model") while Omni Flash / Fast / Lite accept them, and a cap
  of 0 *is* the answer to "does this model take ingredients?". Deliberately no second
  predicate — one was written, found to have no production caller, and deleted.

- **MCP `gflow_generate_image` `ui_mode` now matches the video tool's contract.**
  The image tool rejected an unknown `ui_mode` with a flat `error` **string**, so a
  client reading `error["title"]` — the RFC 9457 shape every other 400 from these
  tools uses since #498 — crashed with `TypeError: string indices must be integers`.
  It was also case-sensitive, while the CLI's `--ui-mode` is
  `click.Choice(case_sensitive=False)` and the video tool normalizes. Both are fixed:
  the value is lower-cased and an invalid one returns the standard problem-details
  envelope. Found by `/code-review` against docs that asserted the param "mirrors the
  CLI" — it did not.
- **`GFLOW_MCP_NO_SPEND` documentation corrected (no behavior change).**
  [CONFIGURATION](docs/CONFIGURATION.md) described the falsy set as a literal lowercase
  list, so a reader setting `GFLOW_MCP_NO_SPEND=FALSE` would conclude no-spend was
  **on** when the value is lower-cased before comparison and it is **off**. On the one
  variable whose purpose is a hard guarantee against spending credits, the wrong
  reading failed toward spending. Now states the match is case-insensitive.

## [0.57.0] — 2026-08-14

### Added

- **`--ui-mode` on `gflow video t2v`/`i2v` + `ui_mode` on MCP `gflow_generate_video` (#299 PR-A).** The video path joins the UI-mode policy that images have had since v0.34.0: the transport now binds its driver through `get_ui_driver` (after editor mount + overlay dismissal) instead of a hardcoded classic bind. Video only has a classic driver, so `auto` ≡ `classic`; an env-sourced `GFLOW_CLI_UI_MODE=agentic` (set for image workflows) degrades to classic with a logged warning, while the explicit `--ui-mode agentic` flag (or MCP `ui_mode="agentic"`) is rejected up front — CLI exit 2 before any browser work, since exit 28's "retry may land it" remediation would mislead for a driver that doesn't exist. The worker queue codec round-trips the new payload field (it previously decoded `ui_mode` for image payloads only).

- **`gflow mcp run --no-spend` (#496).** Registration-time gating of the
  credit-spending MCP tools: under the flag (or `GFLOW_MCP_NO_SPEND=1`, which
  also covers `gflow serve`) the `gflow_generate_image` and
  `gflow_generate_video` tools are never registered, so a connected agent
  cannot even see them in `tools/list` — invisible beats refused (no wasted
  calls, no refusal path for prompt injection to probe, no reliance on the
  model honoring an error; pattern ported from teams-mcp's read-only mode).
  Both generate tools are gated because image generation is only
  *empirically* free and no-spend is a hard guarantee. Listing, instructions,
  and other read-only tools stay available.
- **MCP tool `gflow_auth_status` (#497).** A zero-required-arg, credit-free,
  non-interactive Flow session probe wrapping the same fail-closed
  `verify_flow_profile` check as `gflow auth status`. Agents call it before a
  generation tool to fail fast on expired auth — the queue is async, so an
  auth failure otherwise surfaces only later, from the daemon. Returns
  `authenticated` + the verified email, or a problem-details envelope whose
  `remediation_hint` points at the CLI login (or at retrying, for a network
  `verification_error` that re-login cannot fix). `auth status` accordingly
  moves out of the MCP parity exemptions; login/logout stay CLI-only.

### Changed

- **Agentic mode-switching hardened (#299 PR-B).** The agentic direction now uses the same real-click-first + `aria-pressed` verification discipline the classic direction has had since v0.38.x: `mode_control.ensure_agent_mode` replaces the transport's `_force_agent_mode`, which verified via the `tune` ligature (a documented false-positive source) and force-clicked unconditionally — a forced click can flip the DOM without firing the React handler that persists the server-side preference. Unknown editor variants (the #493 shape) no-op with a warning and are never blind-force-clicked, and the sanctioned mode-control reload carries an explicit 15 s timeout instead of riding Playwright's 30 s default outside every budget. KNOWN_ISSUES records the server-side cohort-pinning evidence (#338) the fail-fast design rests on.
- **Video generation on an agentic cohort now fails fast pre-submit (#299 PR-A).** When Flow serves the agentic editor and classic can't be recovered, `gflow video` commands abort with `UiModeUnavailableError` (exit 28, zero credits, retryable — the cohort flaps per page load) *before* submission, instead of burning 30–40 s of doomed selector timeouts and dying mid-flow with exit 23/25.

- **MCP `gflow://docs/known-issues` resource is now bounded (#501).** The old
  resource returned all of KNOWN_ISSUES.md (~70 KB, growing every release) on
  every read — pure context injection. The default read is now a small index
  (issue titles + status + slugs, a few KB); one templated resource
  (`gflow://docs/known-issues/{slug}`) serves a single issue's full text,
  capped at 16 KB. No unbounded read path remains.


### Fixed

- **MCP response-contract breaches (#498).** Both generate tools now refuse
  rate-limited calls with the same RFC 9457 problem-details envelope (the
  image tool used a plain error string; the video tool's detail claimed a
  nonexistent "1 request per 30 seconds" policy — the real brake is the
  shared token bucket, capacity 8 / refill 1 per 20 s). `gflow_list_projects`
  paginates honestly: a new `offset` parameter, plus `count`/`offset`/
  `has_more`/`next_offset` in the response, replacing the hardcoded first
  page whose `total` field reported the page size as the table total —
  catalogs larger than `limit` were unreachable through MCP.

- **Post-merge `/code-review` fixes for the #495–#501 wave.** The rate-limited
  envelope is now built from the canonical `RateLimitError` (type
  `…/errors/rate-limit`, `retryable`/`message` present) instead of a
  hand-minted variant; `gflow_auth_status` labels a network
  `verification_error` as `…/errors/verification-error` (503, retryable)
  rather than `auth-expired` (401), so type-dispatching agents stop pushing
  users into unnecessary re-logins, and its description no longer overclaims
  "never opens a browser" (the cookie-decryption fallback may boot a headless
  one); `gflow_list_projects` clamps `limit`/`offset` (a `limit<=0` call
  previously produced an infinite `next_offset` loop and negative limits
  reached SQLite as unbounded `LIMIT -1`); `--no-spend` gained a single
  env-var parser (Click's `envvar` dual-parse meant `off` could disable the
  flag yet enable the policy), an idempotent registration policy, a `serve`
  flag, a `.env.template` row, and a no-spend-aware agent guide that no
  longer instructs agents to call unregistered tools; the known-issues index
  recognizes both documented `**Status:**` styles and caps the echoed slug in
  unknown-slug replies (the last unbounded reflection path).

### Removed

- **MCP tool `gflow_list_characters` (#499).** It was a stub that always
  answered `{"status": "ok", "characters": []}` — to an agent that reads as
  "the user has no characters", an active lie that steered clients away from
  real `@Name` references. The tool is gone from `tools/list`, the agent-guide
  resource, and the parity table (`character list` is now an explicit parity
  exemption). It returns only when it can serve real Flow-side data. Use
  `gflow character list --project <id>` in the terminal meanwhile.

### Security

- **CI supply-chain hardening.** Every workflow now runs with a least-privilege token (`ci.yml` gained the top-level `permissions: contents: read` it was missing — the other eight already had one; gitleaks elevates `pull-requests: write` per-job); every `uses:` action across all nine workflows is pinned to a full commit SHA with a version comment (dependabot's `github-actions` group keeps pins fresh); the CI test jobs enforce a test-count floor via `scripts/ci/check_test_count.py` ("a green build that ran nothing is not green"); and `check_repo_hygiene.py` now fails on version disagreement between `pyproject.toml`, `__init__.py`, and `.codex-plugin/plugin.json`.
- **Remaining in-workflow package installs pinned (Scorecard Pinned-Dependencies).** The Pages build now installs MkDocs Material with `pip install --require-hashes` from a compiled `website/requirements.txt`; the PR-triage sandbox image (`Dockerfile.triage`) pins its Node base by digest and installs the Claude Code CLI via `npm ci` from a committed lockfile instead of a floating `npm install -g`; the CI dependency audit pins its `pip-audit` tool version (the non-gating weekly `deps-watch` job deliberately keeps a floating pip-audit — fresh advisory tooling is its purpose). New dependabot entries (uv / npm / docker) keep all three sets of pins fresh. The remaining deliberate won't-fix Scorecard alerts (SAST, Fuzzing, CII Best Practices) are dismissed on the repo with recorded reasons.
- **OpenSSF Scorecard self-run.** A new SHA-pinned `scorecard.yml` workflow (weekly + on push to `develop`) runs the OpenSSF Scorecard supply-chain checks with `publish_results: true`, feeding the public API/badge and the repo Security tab — enabled deliberately after the permissions/pinning hardening so the first published score reflects the hardened state. The score surfaces as a badge in the README and on the website index page, with a docs/SECURITY.md section explaining what it measures; `release.yml`/`pages.yml` write scopes moved from workflow level to the jobs that need them.

## [0.56.0] — 2026-08-13

### Added

- **Once-a-day PyPI update notice (#479).** gflow now prints a one-line stderr notice when a newer version is on PyPI: cache-served (zero added latency — a stale cache refreshes on a background daemon thread for the next run), capped at one poll per day even when the poll fails, and never blocks or fails a command. Skipped in CI (`CI` env var), for editable/local-source installs (PEP 610 detection), and when `GFLOW_CLI_UPDATE_CHECK=0`.

- **Opt-in bounded wait for profile-lease contention (#478).** `GFLOW_CLI_LEASE_WAIT_SECONDS=N` makes a command that hits same-profile contention poll the kernel lock (0.5 s cadence, sync and async call sites alike) and take over as soon as the current holder — a CLI command or a `gflow serve` daemon queue task, both of which release at their natural end — finishes; on timeout it raises the same `ProfileLockedError` (exit 11). Default `0` keeps the historical fail-fast. Triage note: the issue's fuller cooperative-handoff protocol (release-request channel, minimum-hold window) was validated against the actual architecture and dropped — the daemon acquires the lease per task, so every holder's safe release point already coincides with lease release; holders are never asked to release early, which satisfies the no-release-mid-call requirement by construction. Same-process contention always fails fast (waiting on yourself deadlocks).

- **Chromium downgrade guard for persisted profiles (#477).** Opening a profile with an older Chromium major version than last wrote it triggers Chromium's downgrade cleanup, which can shred the newer session store and surface as a mystery post-upgrade logout. Every bundled-Chromium open of a persisted profile (generation client, UI-automation transport, the experimental transports, headless verification probe) now compares the profile's `Last Version` against the active engine's bundled Chromium (`playwright`, or `patchright` when selected) and refuses on a major-version downgrade (`ProfileEngineDowngradeError`, exit 11; the fail-closed verification probe reports it as a verification failure) with an error naming both versions and the remedy. Best-effort: `chrome`-strategy profiles and unknown/unparseable versions skip the check; same-major build rollbacks are allowed; `gflow auth login` stays unguarded as the recovery path.


### Fixed

- **Mode-switch drift errors now name the right evidence (#493).** An external
  report showed a third, unrecognized Flow editor layout (composer frame slots +
  Agent toggle, no classic `crop_*` settings button) falling through to
  `UiSelectorDriftError` (exit 23). The fall-through detail now states that no
  known Flow cohort matched — i.e. the editor may be a new layout this version
  does not recognize — and the class remediation no longer asks for a "debug
  screenshot from this message" that the mode-switch probe never writes: it
  points at the artifacts that actually exist (the PII-safe
  `diag_mode_switch_miss.json` DOM signature and/or the referenced screenshot,
  plus the incident bundle's `report.md`). Recognizing the new variant itself is
  tracked in #493 and needs an affected account's diagnostics JSON. A post-merge
  `/code-review` pass extended the same correction to the neighboring surfaces it
  had missed: `FlowAgentUiError`'s privacy caveat now also covers the standalone
  `debug_forced_agent_ui.png` its raise site writes, and the KNOWN_ISSUES
  fallback points at the incident bundle's `ui.json` (which carries the DOM
  signature) instead of `report.md` (which does not).

## [0.55.0] — 2026-08-13

### Added

- **`gflow mcp setup` is implemented (#475).** The long-stubbed command now writes the gflow MCP server entry into the target client's config: `--target claude-desktop` (default), `cursor`, or `vscode` (VS Code's `servers` + `"type": "stdio"` schema). Non-destructive by construction: existing config content is merged, a pre-existing file is backed up as `<name>.gflow-backup`, a manual `gflow-cli` entry is converged in place instead of duplicated, and a corrupt config fails loud (exit 11) without ever being touched. Also fixed the bogus `%APPDATA%\Castano\Claude` path in docs/MCP.md.
- **Incident bundles now include a pre-filled bug-report template (#476).** On every captured incident, the recorder stages `report.md` alongside the existing artifacts: version/platform, error class + exit code + retryability, phase/route, and pointers to the captured evidence — built exclusively from the allowlisted manifest fields (never raw exception text). The CLI error message now prints the report path next to the bundle path, and retention treats `report.md` as recorder-owned. Downgrade caveat: gflow <= 0.54.x does not recognize `report.md`, so its retention classifies new bundles as unknown and stops pruning them — delete `<GFLOW_CLI_HOME>/incidents` manually if you downgrade. The report is meant to be copied out of the bundle before editing (the template says so), and the e2e privacy scanner now leak-scans `*.md` alongside the JSON artifacts.

### Changed

- **`gflow auth status` now proves the Flow session and exits 0/1 (#471).** The command previously only checked that the profile directory and cookies file exist — it could report OK on a dead session. It now runs the fast `verify_flow_profile` probe (cookie snapshot + Flow session endpoint; no browser, no credits) and exits 0 only on a verified session, printing the verified account email; any other outcome exits 1 with a `gflow auth login` remediation hint. Fail-closed: an unreachable endpoint is a failure, never an OK.


### Fixed

- **Removed the false "requires a Google AI Ultra or Pro subscription" claim across all docs.** Any Google account with Flow access can use gflow-cli — a paid plan only affects credit allowances and tier-gated features (e.g. 4K upscale stays Ultra-only). Swept README, AGENTS.md, DISCLAIMER.md, USER_GUIDE, CONFIGURATION, AUTHENTICATION, DEBUGGING, the medium tutorial, and the gflow-cli skill; factual tier-gating notes are unchanged.

### Security

- **MCP tools no longer leak raw exception text to clients (#473).** Every registered MCP tool now routes through one error funnel: `GFlowError`s keep their structured RFC-9457 problem-details envelope (with the shared `retryable` flag), while unexpected exceptions return a masked envelope carrying only the exception class name — messages can embed filesystem paths, profile names, or token material, so the full text goes exclusively to the server-side structured log (`mcp.tool.unexpected_error`). Previously only 3 of 11 tools had any funnel, and those leaked `str(exc)` as the `detail` field; the rest leaked through the framework's default error path. Guarded by a registry-introspection test that fails if any future tool bypasses the funnel.

- **Windows profile dirs are now really restricted to the current user (#472).** POSIX `chmod 0700`/`0600` is a no-op on Windows, so a profile created under a custom `GFLOW_CLI_HOME` on a shared/world-readable volume inherited that visibility — with the live Google session cookies inside. `gflow auth login` now applies an explicit `icacls` DACL before the browser runs: inheritance stripped, a single owner-only ACE (by SID, locale-safe), children reset to inherit it. Two-step sequence verified empirically (the naive `/t` grant leaves files without effective access). Existing profiles created before this release are swept on their next use: the client's browser-launch path runs a marker-gated hardening pass once per profile. Traversal profile names are rejected before any directory is created or re-ACLed. Best-effort — an ACL failure is logged (with icacls exit code and stderr) and never blocks login; no-op off Windows.
- **Secret settings can no longer leak through a `Settings` dump (#474).** `llm_api_key` (`GFLOW_CLI_LLM_API_KEY`) and `daemon_token` (`GFLOW_CLI_DAEMON_TOKEN`/`GFLOW_DAEMON_TOKEN`) are now stored as Pydantic `SecretStr`, so `repr()`, `str()`, and `model_dump_json()` of the settings object mask them by construction — defense-in-depth on top of the existing logging-boundary redaction. Values are unwrapped only at the single point of use (the prompt-tools LLM client).

## [0.54.0] — 2026-08-12

### Changed

- **Clearer close-the-browser guidance in `gflow auth login` (#470).** Reworded the final passive-capture step in `real_chrome.py` from the abrupt "CLOSE THE BROWSER" command into plain-language guidance: closing the Chrome window is how you signal you're done, after which gflow verifies the Flow session automatically. No behavior change — the manual close stays required on the real-Chrome path, because Chrome holds an exclusive lock on its cookie store while running (verified empirically), so gflow cannot auto-detect completion there without breaking the zero-automation-surface stealth model.
- **Overlay/watermark detection hardened to pure structural selectors.** Council-review cleanup of `ui_automation.py`: enforced 100% language-agnostic structural anchors, removed text-label hacks and dead aliases, and fixed a stale test assertion — strengthens the #403 release-modal dismissal across localized profiles.


### Fixed

- **Dependabot could re-offer the known-bad playwright 1.62.0 every Monday (#465).** The `uv` ecosystem does not respect a version bound standing in an update's way — it **rewrites** it, so the deliberate `playwright>=1.61.0,<1.62.0` bound in `pyproject.toml` never gated Dependabot as `.github/dependabot.yml` claimed. PR #465 widened it to `<1.63.0` and locked 1.62.0, the exact version documented as hanging every `video i2v` right after the frame upload. Dependabot now ignores playwright `semver-minor` alongside `semver-major` (patch bumps stay allowed so a driver CVE fix needs no gflow release), guarded by `tests/test_playwright_pin.py::test_dependabot_ignores_playwright_minor_bumps`.
- **`patchright` was exposed to the same bug, with a bigger blast radius.** Its exact `==` pin is just another constraint the `uv` ecosystem can rewrite, so `docs/SECURITY.md`'s "a Patchright version change is NOT a routine dependabot auto-merge" was prose with nothing enforcing it. Dependabot now ignores **all** patchright update-types (any version change moves the patched Chromium driver — which loads the real Google session — underneath the user), guarded by `test_dependabot_ignores_driver_engine_bumps`. Also corrected the stale pin cited in `docs/SECURITY.md` (`1.60.1` → `1.61.2`) and the stale playwright range in `.github/workflows/deps-watch.yml`.
- **Character-composer focus isolation.** `_submit_body_prompt` now preserves the locator-scoped `press_sequentially`, keeping correct focus during character-composer submission.

### Security

- **Timing-jitter entropy now uses a cryptographically-strong RNG (SonarCloud S2245).** The `_jitter_ms` interaction-delay humanization helper draws from `secrets.SystemRandom` instead of the standard `random` module, so the jitter entropy is not predictable.

## [0.53.1] — 2026-08-06

- Re-release of 0.53.0 (version bump only; recorded headed live-verification evidence). No functional changes.

## [0.53.0] — 2026-08-06

### Added

- **Driver interaction delay humanization (#315).** Added `_jitter_ms` timing entropy helper to `ui_automation.py` to randomize Playwright interaction wait durations around base values, mitigating anti-automation fingerprinting without degrading batch throughput.


### Fixed

- **Flow release overlay detection for visible watermark toggle modal (#403).** Added locale-invariant structural anchors (`a[href*='changelog']`, `[role='dialog']:has(a[href*='changelog']) button`) and a 9-locale cascade (EN, PT, ES, DE, FR, IT, JA, ZH, KO) to `TOP_BANNER_SELECTORS` and `OVERLAY_CLOSE_BUTTON_SELECTORS` in `ui_automation.py` to reliably detect and dismiss release-note modals across localized profiles.

## [0.52.0] — 2026-08-05

### Added

- **Intra-batch reference support for image batches (#317).** `BatchPromptItem` and `gflow image batch` now support `ref` and `reference_entity` fields (e.g. `ref="batch:0"`), with topological dependency sorting and circular dependency validation.
  **Correction (#913):** this never worked. The fields were parsed and silently ignored,
  and the sorting was never called; see the `[Unreleased]` Fixed entry for #913.
- **Character entity provenance recording and video CLI flag parity (#402).** Added `--reference-entity` and `--reference-entity-name` CLI options to `gflow video` commands (`t2v`, `i2v`, `r2v`) and verified character provenance recording in `operations.metadata_json`.


### Fixed

- **Fix video duration selector drift (#451).** Expanded duration control selector cascade to match modern Flow editor UI elements (`button`, `role='button'`, `role='option'`, `role='menuitem'`, `role='tab'`) while preserving fail-closed behavior on missing duration controls.

## [0.51.0] — 2026-08-05

### Security

- **`pip-audit` was blind to every optional extra.** `uv export --frozen` emits
  only the default dependency group, so anything reachable *solely* through an
  extra was never audited — the CI gate reported clean while `uv.lock` carried
  two published high advisories: `aiohttp` 3.13.5 (via `gcsfs`/`s3fs`) and
  `pyasn1` 0.6.3 (via `google-auth`). The default export contains zero lines for
  either package; `--all-extras` contains three. Both the `deps-audit` job in
  `ci.yml` and `deps-watch.yml` now export with `--all-extras`, and both
  packages are bumped (3.14.3 / 0.6.4). Found because GitHub's Dependabot alerts
  flagged `uv.lock` while CI was green — `pip-audit` queries PYSEC, Dependabot
  queries GHSA, and the two are **not** equivalent.

### Changed

- **Cleared the whole Dependabot backlog in one lock update, and fixed the two
  config faults that produced it.** `uv lock --upgrade` moved 38 locked packages
  (aiobotocore, anyio, botocore, certifi, coverage, google-auth,
  google-cloud-storage, grpcio, numpy, protobuf 6→7, structlog 25→26,
  typing-extensions, uvicorn, websockets 16→17, yarl and others) to the newest
  versions `pyproject.toml`'s bounds allow. `pip-audit` over
  `uv export --all-extras` is clean, `ruff`/`pyright` are clean, and the offline
  suite is unchanged against the pre-upgrade lock. The `playwright` upper bound
  held through that sweep, as intended; it was raised separately and only after
  live verification (below).
- **Raised the `playwright` bound `>=1.59.0,<1.60.0` → `>=1.61.0,<1.62.0`,
  live-verified.** The 2026-08-03 regression that motivated the bound — every
  `video i2v` hanging *silently* right after the frame upload, browser alive,
  no error, no timeout — does not reproduce on 1.61.0: a live i2v drove
  `image_uploaded status=200` → `frame_attached` → `generate_captured
  status=200` with `startImage` parsed, and a live i2i local-reference attach
  passed outright. **1.62.0 stays excluded** — its hang has never been
  root-caused. Raising the bound also moves `PINNED_PLAYWRIGHT` and
  `SUPPORTED_PLAYWRIGHT_RANGE`, which are printed in the stall error that tells
  a user how to recover; `tests/test_playwright_pin.py` enforces that pairing
  and caught it. Evidence:
  [`docs/LIVE_VERIFICATION_playwright_1.61.md`](docs/LIVE_VERIFICATION_playwright_1.61.md).
- **Dependabot now groups routine updates instead of drip-feeding them.**
  With the `uv` ecosystem opening a PR per locked package, a normal week
  resolves ~38 updates into a queue five wide, and the queue eats itself:
  #441/#442 were opened and then closed unmerged ("Looks like aiohttp is
  up-to-date now") because the CVE bumps they carried were applied by hand in
  #443 while they waited behind the cap. Minor/patch updates now arrive as one
  grouped PR per ecosystem. Majors stay individual so a breaking transitive
  cannot red-light the batch, and security updates stay ungrouped so an
  advisory fix still opens immediately.


### Fixed

- **Dependabot PRs land labelled again.** `dependabot.yml` asked for
  `dependencies`, `python`, and `github-actions`, none of which existed in the
  repository — so every bump PR opened with a bot error comment and no labels,
  and `label:dependencies` matched nothing across the entire dependency
  history. Dependabot can apply a label but never create one; the new
  `.github/workflows/labels.yml` makes the referenced label set declarative so
  the failure cannot silently return the next time a label is added to the
  config.
- **Two e2e tests could never have passed.** `test_daemon_e2e_lifecycle`
  hand-rolled the *legacy* SSE transport (`GET /mcp/sse` → `event: endpoint` →
  `POST /mcp/message?session_id=`) after the daemon moved to Streamable HTTP at
  `HTTP_PATH`, so its readiness probe waited for a 200 that never comes and it
  died in the "Daemon failed to start" branch **while the daemon was up and
  healthy** — meaning the MCP daemon lifecycle had no live coverage at all. It
  now speaks the real protocol through the SDK's own client and imports
  `HTTP_PATH` rather than hardcoding it. Separately,
  `test_e2e_health_check_returns_true_when_active` asserted a *success* path
  against the obsolete `bearer`/`sapisidhash` transports, which KNOWN_ISSUES.md
  already records as unusable; success-path tests now use `LIVE_STRATEGIES`
  while error-path tests keep the full list on purpose. Fixing that also
  cleared an unrelated failure — the obsolete transports were the ones holding
  the contended profile lease. Zero-credit gate: 15 passed/3 failed → **16
  passed/0 failed**.

## [0.50.0] — 2026-08-04

### Added

- **Adopted MCP 2026-07-28 Tasks extension (SEP-2663) (#409).** Added `TasksExtension` subclass serving `tasks/get` and `tasks/cancel`. Generation tools (`gflow_generate_image`, `gflow_generate_video`) support non-blocking task handle responses (`wait=False`).
- **Hardened CLI and MCP `-o`/`--output` path routing (#414, #415).** Custom output paths land generated assets at target locations with automatic parent directory creation, S3 cloud storage relative path preservation, and multi-count stem suffixes (`_1`, `_2`).


### Fixed

- **PR triage notification resilience (#428).** Fallback alerts via Telegram on missing credentials or auth failure.

### Changed

- **`gflow video i2v` accepts `--model omni-flash` again — start frame only,
  and it unlocks `--duration 10` (#125).** The 2026-05-30 wire capture that
  justified the blanket exclusion (Flow silently dropping frame refs and
  billing the run as text-to-video) no longer reproduces: a 2026-08-03
  route-aborted re-capture shows Flow routing omni + start frame to
  `batchAsyncGenerateVideoStartImage` with the frame bound, and a live x1 10s
  generation confirmed the output starts on the supplied frame. The END frame
  stays gated for omni-flash (`--end-frame` exits 17 pre-spend — Flow lists
  first+last as "coming soon"), and `chain` still rejects omni-flash
  (single-clip proof does not cover N seeded links). New credit-free recon
  spike: `scripts/dev/spike_omni_flash_i2v_ui_recon.py`.


### Fixed

- **An out-of-range Playwright silently wedged every video generation; the
  dependency is now upper-bounded and the stall fails fast.** `uv tool install
  <path>` ignores `uv.lock` and resolves from the `pyproject.toml` ranges, and
  the `playwright>=1.45.0` range had no upper bound — so a local/tool install
  could pick up a Playwright this project has never tested. Observed: an
  install that resolved **1.62.0** against a project locked to **1.59.0** made
  every `gflow video i2v` run hang **silently** right after the frame upload
  (last log line `ui_automation_video.frame_attached`, browser alive, no error,
  no timeout, indefinitely); reinstalling with the locked version fixed it on
  the first try. Playwright ships the browser driver, so an untested minor is
  an untested product — the constraint is now `>=1.59.0,<1.60.0` (patch
  headroom, no untested minors), pinned by `tests/test_playwright_pin.py`.
  Independently, the prompt-submission stage now runs under a named wall-clock
  watchdog: on expiry the run aborts **pre-submit** with
  `TransportTimeoutError`, a `stage_stalled` event and a debug screenshot taken
  under its own short deadline, and the error names the stage, prints the
  installed Playwright version against the supported range, and gives the
  pinned reinstall command. Nothing is submitted, so no credit is spent — a
  silent multi-minute hang is indistinguishable from slowness in an overnight
  batch, which is what made this expensive to diagnose.
- **A missing video output-count control now refuses before submit instead of
  silently proceeding on Flow's default of x2 — which double-billed
  `--count 1` runs (#404).** `_set_output_count` raises `UiSelectorDriftError`
  (exit 23, debug screenshot) on a probe miss, matching the duration probe's
  fail-fast contract (#288), and matches count-tab labels affix-agnostically
  per digit (`xN` current / `Nx` legacy) so the next label rename degrades to
  a fallback selector rather than an outage.

## [0.48.0] — 2026-08-02

### Added

- **Explicit `-o` / `--output` flag on the core generation commands (#411).**
  `gflow image t2i`, `gflow image i2i`, `gflow video t2v` and `gflow video i2v`
  now accept an explicit **local** destination file path, so scripts control
  exactly where the generated asset lands instead of parsing the
  date-partitioned default layout. Parent directories are auto-created, and
  `-o` takes precedence over `--out`/`--out-dir`. Multi-count **image** runs
  (`--count > 1`) append a deterministic `_1`, `_2`, … suffix before the
  extension; video runs write a single file. On `t2i` the flag is
  single-prompt only — multi-prompt runs abort with a usage error pointing at
  `--out`. Known limits, tracked as follow-ups: no `s3://`/`gs://` targets and
  no `GFLOW_CLI_STORAGE_URI` interplay yet, no `-o` on `video r2v`/`chain`, no
  video multi-count suffixes (#415); the MCP generate tools do **not** carry a
  matching `output` parameter — one was cut before release when the pre-release
  audit showed the worker queue never reads it, making it a silent no-op
  (#414). Raised by a Reddit user testing scriptability (thanks u/_suren).

## [0.47.0] — 2026-08-01


### Fixed

- **Entity attachments left no trace in the catalog, making character provenance
  unrecoverable (#402).** `--reference-entity` / `--reference-entity-name` reached
  the transport but were never recorded, so no `image t2i`, `image i2i` or movie
  R2V operation carried the entity it was generated from — while `--ref` media
  refs were recorded in full, with ordering. When character identity drift showed
  up, the catalog could not answer "which entity produced this image?".
  Generation operations now persist `entity_ids` and `entity_names` in
  `operations.metadata_json`, in attach order, on succeeded and failed rows alike
  — a FAILED row carrying `entity_ids` distinguishes a rejected attach from a run
  that never requested an entity. Tool and entity provenance are composed into a
  single `set_operation_metadata` write, since that call replaces the whole
  column. Forward-only: operations recorded before this release cannot be
  Live gate: `tests/e2e/test_entity_provenance_e2e.py` (opt-in via
  `GFLOW_CLI_E2E_RUN_ENTITY_PROV=1`) verifies the recorded entity matches a
  generation Flow actually accepted, including the rejected-attach case.
- **The MCP server was broken on every fresh install.** `pyproject.toml`
  declared an unbounded `mcp>=1.0.0`. `uv.lock` pinned `1.28.1`, so CI and
  contributors stayed green — but `pip install gflow-cli` / `uv tool install
  gflow-cli` resolved the newly published `mcp` 2.0.0, which **deleted the
  `mcp.server.fastmcp` module** that `gflow_cli.mcp.server` imports at module
  load. `gflow mcp run`, `gflow serve`, and `gflow mcp setup` all failed with
  `ModuleNotFoundError: No module named 'mcp.server.fastmcp'`. The dependency is
  now bounded (`mcp>=2.0.0,<3`) and the server is migrated to the 2.x API.
  Pure-CLI paths were never affected.
- **New `resolve-drift` CI job — the actual defect.** Every other job installs
  via `uv sync`, which honours `uv.lock`, so CI never exercised the version
  *ranges* in `pyproject.toml` and could not have caught the above. This job
  installs the way a user does — from the declared ranges, newest compatible
  versions, no lockfile — then smoke-imports the MCP surface and the CLI entry
  points. It generalizes to every unbounded dependency, not just `mcp`.
- **`ui/app.py` advertised an unroutable MCP message endpoint.** mcp 2.0 dropped
  FastMCP's `sse_app(mount_path=...)` shim, which used to let the advertised
  endpoint (`/mcp/messages/`) differ from the sub-app's internal route
  (`/messages/`). Both now derive from one `message_path`, so the advertised
  path was left unrouted at the app root — a silent failure where the SSE stream
  opens and only the follow-up POSTs 404. Fixed with an explicit alias and
  pinned by a regression test.

## [0.46.1] — 2026-07-31


### Fixed

- **`image t2i` failed whenever `-n` differed from the displayed count — including
  the default `-n 1` (#404).** Flow renamed the composer's count-tab labels from
  `1x`/`x2`/… to `x1`/`x2`/…, so the count setter's label filter silently dropped
  the count-1 tab and its positional pick clicked the wrong tab (reporting
  per-click success while the value never changed). The count tab is now selected
  by the digit in its label across both label cohorts (`1x`/`x1`), the read-back recognises a
  selected `x1`, and non-convergence raises `UiSelectorDriftError` (exit 23)
  naming desired vs displayed — instead of a bare `RuntimeError` that
  observability hashed into an opaque `UnexpectedError`. The per-click
  `count_click_result` log now carries `effect_observed`, and the video output
  count setter probes both label cohorts too. Verified live on the classic
  composer (new e2e: `tests/e2e/test_classic_count_setter_e2e.py`; evidence:
  [LIVE_VERIFICATION_v0.46.1](docs/LIVE_VERIFICATION_v0.46.1.md)).

## [0.46.0] — 2026-07-28

### Changed

- **BREAKING — the prompt tools now drive any OpenAI-compatible endpoint (#387).**
  `--tool creative-director` / `reverse-engineer` / `storyboard` were hardwired to
  Google's native Gemini API, so an OpenAI-compatible gateway key could not be
  used at all. The transport now speaks **OpenAI Chat Completions**, which
  OpenAI, gateways/proxies (OpenRouter, LiteLLM, freellmapi), local runtimes
  (Ollama, LM Studio) and Google's own compatibility endpoint all accept.
  - New config: `GFLOW_CLI_LLM_BASE_URL` (the on/off switch; defaults to
    Google's compat endpoint), `GFLOW_CLI_LLM_API_KEY` (**optional** — omitted
    from the request entirely when unset, so keyless local gateways work), and
    `GFLOW_CLI_LLM_MODEL` (also the provider selector, since gateways route on
    the model string).
  - Provider keys stay with your gateway. gflow only ever holds the single
    credential it presents to the endpoint you point it at.
  - The three builtin tools no longer pin `model = "gemini-2.5-flash"`. That pin
    was sent unconditionally, so any gateway not serving that exact name
    answered 400 — silently, because the prompt tools never fail a run.

### Removed

- **BREAKING — `GFLOW_CLI_GEMINI_API_KEY` and `GFLOW_CLI_GEMINI_MODEL` (#387).**
  Set `GFLOW_CLI_LLM_API_KEY` instead; an existing Google `AIza…` key keeps
  working unchanged, because the default endpoint is Google's OpenAI-compatible
  surface. gflow prints a one-time warning if it sees the old variable — the old
  value is never forwarded. The warning exists because the prompt tools never
  fail a run: without it, prompts would quietly stop being rewritten while
  generations still billed in full.
  `GFLOW_CLI_GEMINI_MODEL` had in fact never had a live code path — its only
  reader was an uncalled helper — despite being documented as a global override.


### Fixed

- **`reverse-engineer` no longer expands a file path as if it were a prompt (#387).**
  When multimodal analysis of a URL, video, or image failed, the runtime fell
  through to text expansion of the *path string*, returning a confident but
  useless prompt that still billed a full generation. It now degrades to the
  original input.

### Security

- **The prompt-tools endpoint is treated as a trust boundary (#387).** `base_url`
  is user-supplied now, so: redirects are declined (`urllib` re-sends the
  `Authorization` header to whatever host a 302 names, which would have leaked
  the key to a hostile gateway); `base_url` is validated to `https`, or `http`
  for loopback only, with credentials-in-URL rejected; error-response bodies are
  redacted before logging, since a gateway can echo the bearer token back; and
  the resolved destination host is logged once, giving an audit trail for where
  prompts and base64 image bytes were sent.

## [0.45.0] — 2026-07-28


### Fixed

- **`gflow character create` binds portraits to the character again (#395).**
  Two independent defects made every character generation land as a plain
  project image, leaving the character empty:
  1. **Overlay dismissal Escaped Flow's own UI.** `[role='dialog']` and
     `[role='alert']` had been added to the overlay detector, but Flow's
     character composer (and the media picker) carry those roles — so gflow
     pressed Escape on the app itself, the generation went out without
     `entityContext`, and Flow filed the image against the project with no
     `parentEntityId`. Those two selectors are removed; `[role='banner']` and
     the announcement matcher remain, so the original banner-dismissal intent
     is intact.
  2. **The character route could bounce back to the project page.** Flow
     redirects `/project/{id}/character/{entityId}` when the entity is not yet
     queryable — a race gflow loses by navigating immediately after
     `flow.createEntity`. Because the project page also mounts a prompt box,
     the old readiness check was satisfied on the wrong surface and the prompt
     was typed into the **project** composer. gflow now verifies it actually
     came to rest on the character route, re-navigating a few times and failing
     loudly rather than generating on the wrong surface.

  Verified live 2026-07-28 in both directions on the same account, plus a
  read-back showing the character carrying its name and `thumbnail_media_id`.
  The wire contract is documented in
  [CHARACTER_RECON](docs/CHARACTER_RECON.md#entity-binding-entitycontext-captured-live-2026-07-28).

- **`gflow image i2i --ref <UUID>` no longer fails when the asset is out of the
  picker's reach (#393).** Flow's media picker is scoped to the active project
  and its search does **not** index media UUIDs (confirmed live 2026-07-27:
  both UUID search tiers returned zero tiles), so a `--ref` pointing at an asset
  in another project — or buried deep in a virtualised grid — could not be
  selected, and a bare `--ref <uuid>` carried no local file to fall back on. The
  CLI now resolves each UUID ref against the local catalog and attaches its
  recorded file, so the transport uploads those exact bytes instead of failing
  the run. Verified live as a controlled A/B on identical input: exit 9 before,
  exit 0 with the upload fallback after. Enrichment is best-effort (unknown
  asset, unavailable catalog, or deleted file leaves the ref untouched) and the
  **fail-loud contract is unchanged** — a reference that cannot be bound still
  aborts the generation rather than silently producing an unreferenced image.
- **A Flow web-app crash on the character-editor route is now reported as
  such.** `gflow character create` surfaced Flow's client-side crash as
  `RuntimeError: Character editor not ready: prompt textbox not visible`, which
  blames a selector that was never on the page. The existing crash classifier is
  now consulted at that gate too, yielding the typed, retryable `FlowAppError`
  (exit 31). Observed live 2026-07-27 via the incident bundle's `ui.json`
  (`title.category: flow_app_crash`).
- **Character binding failures say what actually happened.** When Flow returns a
  workflow that is not bound to the character entity, the error read "Unexpected
  response shape from Flow", sending readers after a wire-format bug. It now
  states that Flow filed the image as a plain project image and the character
  has no portrait. The guard remains strict — verified live that unbound runs
  leave the entity as "Untitled Character" with a null thumbnail.
- **Tier-aware credit confirmations:** `gflow video chain` and `gflow movie run`
  no longer present pending work as an exact one-credit-per-link/scene charge.
  Plans, confirmation prompts, `--dry-run` output, Click help, and current docs
  now report the count of *pending video operations* and direct operators to
  Google Flow for current model/duration/tier pricing, which varies by account
  tier and Flow policy. Execution, resume/stale accounting, `--yes`, JSON
  output, flags, and exit codes are unchanged.

### Added

- **Top Banner & Modal Dismissal (#369):** Expanded `_detect_overlay` and
  `_dismiss_blocking_overlays` in `ui_automation.py` to detect top banners,
  alert bars, and announcement dialogs (`[role='banner']`, `[role='alert']`,
  `[role='dialog']`, `div:has-text('What\'s new')`), force-clicking locale-stable
  close/clear/Got-it buttons and falling back to Escape before automation tasks.
- **`gflow character create --format-prompt` (#383):** Opt-in flag that clicks
  Flow's in-editor **Format** button before submitting, letting Flow rewrite the
  prompt into its character prompt-engineering shape. Applies to both the face and
  body slots. Best-effort by design — if the button is not found the prompt is
  submitted as typed rather than failing the generation. The selector cascade is
  anchored on the locale-stable `personal_recommendations` Material Symbols
  ligature (confirmed against live DOM 2026-07-27), not the "Format" label, which
  Flow localises to the Chrome profile language. Flow ships the button `disabled`
  on an empty prompt, so the driver checks enabled-ness — a disabled button is
  still *visible*, and clicking one would stall on Playwright's actionability wait.
- **Self-documenting error remediation & provider message pass-through (#380):** Added default `remediation_hint` strings across domain exception classes (`WireFormatError`, `ContentPolicyError`, `RateLimitError`, `DataStoreError`, `SceneConcatError`, `FrameExtractionError`), extracted and sanitized provider error messages from Google Flow tRPC/REST responses, and enriched MCP tool error envelopes and Rich CLI error displays with actionable recovery guidance at failure time.

## [0.44.0] — 2026-07-26

### Added

- **Dual-Side Project Naming & Management (`gflow project`)** (#381). Added
  `gflow project` subcommand group (`list`, `show`, `rename`, `create`),
  `--project-name` / `--project-title` options across `gflow image` and `gflow video`
  generation commands, prompt slugging for scratch projects, and dual-side title sync
  updating Google Flow's tRPC server/UI and local SQLite catalog in lockstep.
- **Namespaced Codex project skills.** The canonical workflows under `skills/`
  now ship as a repo-local, skills-only Codex plugin. Register and install it
  with `codex plugin marketplace add .` followed by
  `codex plugin add gflow@gflow-cli`, then invoke workflows such as
  `$gflow:status`, `$gflow:check`, and `$gflow:pr-council-review` in a new
  Codex CLI or desktop-app session. Claude Code's `/gflow:*` commands and the
  agent-agnostic skill files remain unchanged.
- **`gflow data errors` — bounded retention + export for failed-operation
  history** (#345). `gflow data errors export [--older-than AGE] [-o FILE]`
  dumps failed operations as JSONL (unbounded, newest-first) for offline
  archival — also closing the export path deferred from #341. `gflow data
  errors prune --older-than AGE [--dry-run]` deletes failures older than AGE
  (`90d` / `24h` / `30m`); `--older-than` is **required** and there is no
  automatic/background pruning — deletion is always an explicit operator
  action. Both honor `--profile` and the exit-16 `DataStoreError` convention.


### Fixed

- **`gflow character create` safely activates the current Create-Body
  composer.** Flow can autosave the body triptych over the stored portrait
  prompt when the mode switch has not settled (observed live 2026-07-25 on
  0.43.0). Current Flow reuses one Slate editor and exposes Create Body through
  the locale-independent `accessibility_new` icon beside the portrait image;
  gflow now clicks that scoped mode control, requires a new generated-face
  reference chip to mount, and verifies the shared editor owns focus **before
  any clearing or typing**. Readback failures abort before submit. The older
  `add_2`/second-box cohort remains supported through its count-rise gate.
  Post-type isolation still aborts before the credited submit. Live DOM
  evidence and the one-box failure were captured on 2026-07-26. Face-only
  creates are unchanged.

- **Profile-lock remediation message** now names the real cause and recovery.
  `ProfileLockedError` (exit 11) previously told operators to "wait for it to
  finish" — implying an unbounded wait — and to hunt for a `gflow`/Chrome
  process. In practice a blocking lock is a kernel *advisory* lock held by a
  **live** process (often a `python.exe` a `chrome.exe` scan misses); the OS
  releases it the instant the holder dies, so a leftover lock *file* never
  blocks acquisition. The message now points to the recorded owner PID
  (surfaced locally since v0.43.0) and says to just retry when nothing is
  running. The lock itself is unchanged — auto-reclaim was considered and
  rejected as unsafe (an unlink→new-inode race could put two browsers on one
  profile, the exact corruption the lease prevents). Refs #370.

## [0.43.0] — 2026-07-23

### Added

- **Private incident diagnostics** (`GFLOW_CLI_INCIDENT_CAPTURE`, default
  **on**). Relevant operational failures — Flow app crashes, agentic-cohort /
  UI-mode errors, selector drift, transport timeouts, WAF/network/wire-format
  errors, profile-lock contention, unexpected exceptions — now automatically
  write a bounded, **private** incident bundle under
  `<GFLOW_CLI_HOME>/incidents/`: an allowlisted `manifest.json`, structural
  `ui.json` (ligatures/signals/overlay geometry — never raw text),
  `network.json` + `browser.json` ring journals (host categories, canonical
  routes, status codes, text lengths — never prompts/tokens/cookies/bodies/
  signed URLs), and a `sensitive/screenshot.png` for UI-state failures that
  every surface marks review-before-sharing. Nothing is ever uploaded; remote
  MCP/HTTP/worker error envelopes carry only an opaque `{id, capture_status}`
  while the local CLI prints the bundle path. Retention is bounded
  (50 bundles / 250 MiB) and validates ownership before pruning. Raw HAR
  stays separate and opt-in; the manifest's `har_state` now reports honestly
  whether the session's HAR demonstrably finalized. See
  [DEBUGGING § Automatic incident bundles](docs/DEBUGGING.md#automatic-incident-bundles).
  Refs #369, #370, #174, #183.
- **Profile-lock owner evidence.** `ProfileLockedError` contention now
  surfaces the recorded lease owner's PID and observed start time locally
  (never in remote envelopes or logs; identities are per-command HMACs, never
  the raw owner token). The lock-file layout is v1-versioned: byte 0 is the
  kernel-locked sentinel and metadata starts at offset 1, so Windows
  contenders can read it while the lock is held (legacy byte-0 files degrade
  to "evidence unavailable"). The kernel lock remains authoritative — no
  reclaim, unlink, or PID kill is ever performed from metadata. Refs #370.
- **UI-drift debug engine** (`capture_ui_diagnostics`). On a `mode_switch_trigger`
  failure, gflow dumps the composer's **structural** DOM signature — the
  Material-Symbols ligature inventory, `crop_*` presence, textbox count, and
  bounded overlay geometry — to a JSON alongside a **full-page** screenshot,
  so a Flow frontend change is diagnosable from one artifact instead of a
  bare (often black) viewport shot. Consolidated onto the incident-bundle
  engine: the earlier in-development raw URL/title/body-text fields were
  removed before release. (#183)
- **`website/docs/` PII-leak CI guard** (`scripts/ci/check_website_docs_pii.py`).
  The published mkdocs mirror under `website/docs/` is an anonymized copy of
  canonical `docs/`; this new gate fails CI (and runs in `/gflow:check`) if a
  known private identifier — `denon82`, the OS username `ffrol`, a real
  name/email — appears in a published file, catching an anonymization miss
  before it ships (the failure mode of #362). Public references such as
  `github.com/ffroliva/gflow-cli` and the APP_AUTHOR path are trap-free by
  construction, so the guard needs no allow-list.


### Fixed

- **Incident-capture hardening from the max-effort review** (14 confirmed
  findings fixed pre-release): journals now stage first and page artifacts
  share the 8s budget via a deadline, so a fully wedged renderer can no longer
  cost the whole bundle or bypass suppression; the legacy mode-switch debug
  dump writes structural JSON only (the unmarked full-page screenshot that
  previously landed in the plain output dir on every ordinary run is gone —
  the bundle's `sensitive/` screenshot is the one imagery artifact); capture
  now also covers `generate_character_image` (which additionally gains the
  exit-15 closed-browser mapping) and `upsample_image`, plus the common
  stale-Chrome launch-crash contention path (#293); manifests report
  `har_state: complete` only when the context demonstrably closed gracefully;
  bundles staged for unexpected non-typed exceptions are now surfaced (path in
  human output and `--json`); retention runs even when capture is disabled
  (an opt-out no longer freezes previously captured bundles on disk), runs off
  the event loop, and an undeletable pending bundle can no longer condemn
  healthy ones; a Windows sharing violation during manifest finalization gets
  a bounded retry; `browser.json` records the real JS error class
  (`TypeError`/`ReferenceError`) instead of the constant `Error`; worker
  daemon tasks rebind a per-task correlation id so incident ids are unique
  and joinable to queue rows.
- **`FlowAppError` and `FlowAgentUiError` now report `retryable: true` on
  every machine-readable surface.** Both are documented (and presented to
  humans) as transient/retryable, but the CLI `--json` payload said
  `retryable: false` and the MCP / worker-queue error envelopes carried no
  retry signal at all. The classification now lives in one shared
  `errors.is_retryable()` consumed by CLI JSON, MCP tool envelopes, and
  persisted worker-queue error payloads — the three surfaces can no longer
  drift.
- **Documentation drift corrected against the code:** `gflow image batch` docs
  claimed generations run in parallel inside Flow (the transport is strictly
  serial — each prompt's generation is awaited before the next submission)
  and listed `--fail-fast` as the default (the CLI default is
  `--continue-on-error`); the root plan still labeled the MCP server as
  unshipped (shipped v0.21.0/v0.23.0).
- **Flow's new media-library / agentic A/B cohort now fails cleanly.** When a
  project opens into Flow's full-page media-library (or agentic chat) composer —
  which has no classic `crop_*` aspect/mode control — `gflow image` and
  `gflow video` now raise a clear, retryable `FlowAgentUiError` ("this cohort
  flaps; retry shortly") instead of the misleading `UiSelectorDriftError`
  "file a bug". Detection is a runtime DOM scan at a new shared
  `_mode_switch_error` raise site covering **both** the image and video paths.
  Refs #174, #183.
- **Flow web-app crashes now fail cleanly instead of "file a bug".** When Flow's
  web app renders its client-side-exception error boundary (a transient Flow
  crash) instead of the editor, the mode-switch raise site now raises a retryable
  `FlowAppError` (exit code 31) — "transient Flow error, retry shortly" — rather
  than the misleading `UiSelectorDriftError`. Detected via the Flow error-page
  title; surfaced by the #183 UI-drift debug engine.
- **Experimental transport self-lockout.** The `bearer` and `sapisidhash`
  transports discard a caller-supplied Playwright page and re-acquire the profile
  `ProfileLease` in their own `setup()`. Driving one via `GFLOW_CLI_TRANSPORT`
  inside a `FlowApiClient` (which already holds the lease) self-locked with an
  opaque `ProfileLockedError`. `FlowApiClient` now refuses these standalone-only
  transports up front with a clear `ConfigurationError` naming the transport and
  pointing to `ui_automation`/`evaluate_fetch` or standalone use. `evaluate_fetch`
  is unaffected (it shares the client's page). New `STANDALONE_ONLY_TRANSPORTS`
  set + `resolve_transport_name()` helper in `api/transports`.

## [0.42.0] — 2026-07-21


### Fixed

- Content-safety `400` responses from Flow are now classified as
  `ContentPolicyError` (exit code 5) instead of the misleading `WireFormatError`,
  so callers can branch on a policy rejection deterministically. (#359)
- Corrected a false `flow_operation_id` invariant. Live verification found
  `veo-lite` can produce a `remote_started` checkpoint with `operation_id` unset,
  contradicting the prior claim that only `omni-flash` omits the operation name.
  `flow_operation_id` is best-effort/optional; `media_id` is the canonical handle
  used by polling, download, and every CLI lookup. No behaviour change; a
  regression test now locks the operation-name parser against the real veo
  capture fixture. (#361)

### Changed

- **Replaced Gemini CLI with Antigravity (`agy`) as the supported Google coding
  agent** across skills and docs (Google retired Gemini CLI in favor of the
  Antigravity harness). Antigravity auto-discovers `AGENTS.md` natively, so the
  dedicated `GEMINI.md` hub is **removed** and Antigravity is listed among the
  auto-discovering tools in `AGENTS.md`. (#360)
- **`llm-council` skill:** the `high` tier's second external reviewer is now
  Antigravity (`agy`) instead of Gemini CLI; `agy` is promoted from an opt-in
  tool to the pinned `high`-tier slot and the `--include-agy` flag is dropped.
  When `agy` is unavailable or fails non-interactively, the skill suggests
  installing Antigravity or substituting another external CLI coding agent rather
  than failing. (#360)
- Forward-looking agent references updated for consistency across `AGENTS.md`,
  `CLAUDE.md`, `README.md`, `llms.txt`, `docs/INDEX.md`, `docs/AGENT_GUIDE.md`,
  `skills/*`, and CI helper strings. Historical release notes and past
  verification records are left unchanged. (#360)

### Removed

- Removed the dead `fail_processing_tasks` daemon-recovery method, superseded by
  the checkpoint-classifying `recover_processing` (internal cleanup; no
  user-facing behaviour change). (#361)

### Documentation

- Added an onboarding page and quickstart flow to the published docs site, and
  anonymized personal account data across it. Security vulnerabilities now report
  through GitHub's private vulnerability reporting rather than a personal email. (#362)
- Corrected the same-profile concurrency framing (MCP page and docs) to the
  cross-process `ProfileLease` fail-fast contract (`ProfileLockedError`, exit 11),
  and recorded that the POSIX `fcntl.flock` lease was verified green on the
  Windows/macOS/Linux CI matrix. (#361)

### Tests

- Added live-gated end-to-end tests for crash-recovery (a crashed post-submit task
  recovers as `indeterminate` and is never resubmitted) and cancellation-safe
  teardown (the profile lease releases on mid-launch cancel). Both were confirmed
  against real Flow on 2026-07-21. (#361)

## [0.41.0] — 2026-07-20

### Added

- **Cross-process profile lease** ([#357]): new `ProfileLease` with
  process-local guard + kernel advisory lock (`msvcrt` on Windows, `fcntl`
  on POSIX), keyed by canonical profile dir. `ProfileLockedError` (exit 11)
  on contention. Integrated at all 10 persistent-context-owning boundaries.
  Daemon's overwriteable `profile.lock` removed.
- **Versioned worker queue payloads** ([#357]): `schema_version: 1` codec
  validates before Playwright starts; unknown versions raise typed
  `QueueSchemaError` (exit 30). Legacy V0 (missing field) still accepted.
- **Atomic queue task claims** ([#357]): single SQLite `BEGIN IMMEDIATE`
  transaction (select → decode → fail-invalid-without-browser → conditional
  `pending→processing`) shared by daemon and MCP; duplicate per-profile lock
  maps removed. Checkpointed execution phases (`claimed → submit_attempted →
  remote_started → terminal`) with conservative `may_have_spent`.
- **`/gflow:live-verify` skill**: pre-flight state check + per-feature
  live-verification gate before claiming feature completion.
- **Driver honesty improvements** ([#357]): removed classic driver's
  `await_images()` that only raised; replaced late `driver._transport = self`
  mutation with typed `SupportsSendPrompt` injection; agentic submit takes
  request + expected count directly. Frozen `TransportSetup` applied through
  public `apply_setup()` seam replacing client writes to transport-private
  fields.

### Changed

- **Cancellation-safe browser teardown** ([#357]): per-step
  `shield(wait_for(...))` bounded cleanup in required order (stop work →
  cancel worker → persist state → close browser/driver → close stores →
  release lease), re-raising original cancellation last.
- **Mention-index outages fail closed** ([#357]): `MentionIndexUnavailableError`
  (exit 29) with unavailable source name; mention-free prompts stay
  pass-through. Empty source ≠ unavailable source.
- **`OperationRecorder`/chain-repo datastore ownership** ([#357]): stores
  only close the `DataStore` they create; injected stores never closed by a
  non-owner.
- External-CDP browser lifecycle removed by evidence (no production
  consumer, unauthenticated debug port, ambiguous ownership, recorded
  WAF-rejection); Chrome discovery/channel helpers preserved.

### Removed

- **`gflow video batch`** — the manifest-driven video batch command was
  removed. It never worked end-to-end; every invocation exited immediately
  with a stub error before reaching Flow. `gflow image batch` (manifest-driven
  image generation) is unaffected and remains supported.
- External-CDP browser lifecycle (no production consumer).

### Security

- Cancellation-safe teardown prevents resource leaks on interrupt.
- Profile lease kernel advisory lock prevents concurrent profile access
  across processes.

[#357]: https://github.com/ffroliva/gflow-cli/pull/357
[`docs/LIVE_VERIFICATION_v0.40.0-production-readiness.md`]: https://github.com/ffroliva/gflow-cli/blob/main/docs/LIVE_VERIFICATION_v0.40.0-production-readiness.md

## [0.40.0] — 2026-07-19

### Added

- **Prompt `@`-mention resolution for asset tagging** ([#344]): `@Name` in a
  t2i/i2i/video prompt resolves to a staged, taggable character entity
  (`services/mentions.py`), across the `image`/`video` CLI paths, the async
  worker, and MCP tools. Media-asset (non-character) `@`-mentions also work,
  but on the **image path only** — video-path media mentions are Phase 3. A
  bare character with no reference images is rejected early with a clear
  error instead of failing deep in the UI attach. De-tagged prompts are
  persisted to the catalog. See
  [`docs/REFERENCE_STRATEGIES.md`](docs/REFERENCE_STRATEGIES.md) for
  `@`-mention vs `--reference-entity` vs `--ref`, and
  [`docs/LIVE_VERIFICATION_v0.40.0.md`](docs/LIVE_VERIFICATION_v0.40.0.md)
  for the live e2e evidence.

[#344]: https://github.com/ffroliva/gflow-cli/issues/344

## [0.39.0] — 2026-07-19

### Added

- **Failed generations are now persisted to the local catalog** ([#341]):
  every paid-generation path (`video t2v/i2v/r2v`, `video chain`,
  `image t2i/i2i`, multi-prompt t2i, `gflow run`, `image batch`, `movie run`,
  and the async worker) records a terminal `status="failed"` operation row —
  with a stable `error_type` derived from the exception's RFC 9457
  `problem_type` (`waf-rejection`, `content-policy`, `auth-expired`, ...) and
  a redacted `error_detail` — before the error propagates. WAF-403 block
  onset, duration, and recovery windows are now measurable instead of
  reconstructed from memory.
- New `gflow data list errors [--profile] [--limit] [--offset] [--json]`
  subcommand: browse failed operations newest-first (Rich table on a TTY,
  JSONL otherwise).
- Videos whose poll completes with a Flow-reported failure
  (`succeeded=false`, e.g. `PUBLIC_ERROR_UNSAFE_GENERATION`) are now recorded
  as `failed` with `error_type=generation-failed` — previously they were
  recorded as `succeeded` (all paths: CLI, chain, movie, worker).

### Security

- `error_detail` values are scrubbed before persistence
  (`Bearer`/`SAPISIDHASH` tokens, auth-cookie pairs, signed URLs; 500-char
  cap) and non-`GFlowError` messages are stored only as SHA-256 hashes.
  Prompts on failed rows honor `GFLOW_CLI_HISTORY_PROMPTS`; note `store` mode
  therefore also stores prompts of content-policy-rejected generations.
- The experimental REST transports (`bearer`, `sapisidhash`,
  `evaluate_fetch`) now redact response bodies BEFORE truncating them into
  exception messages, closing a partial-secret leak into logs and (new) the
  catalog DB.
- The worker queue's `generation_queue.error_json` now applies the same
  redaction: `GFlowError` details are scrubbed and non-`GFlowError` messages
  are stored as SHA-256 hashes instead of raw text.

[#341]: https://github.com/ffroliva/gflow-cli/issues/341

## [0.38.1] — 2026-07-17


### Fixed

- **Agentic-pin recovery: opt-in reload after a real toggle-off** (#338): when a REAL
  (actionability-checked, unforced) Agent-toggle click lands but the classic media panel
  never mounts in place (the 2026-07-17 both-accounts pin), `ensure_media_mode` can now
  reload the page once and re-run its loop — a fresh load both re-rolls the server's
  per-load cohort arm and mounts the server-persisted `isAgentModeToggled=false`
  preference (`docs/superpowers/spikes/2026-07-12-ui-cohort-backend-config.md`). The
  reload is **opt-in** (`allow_reload`, threaded via `_exit_agent_mode`) and sanctioned
  only from `get_ui_driver`'s pre-bind CLASSIC path, which re-verifies the cohort after
  any navigation — mid-flow image/video mode switches keep strict no-navigation
  semantics (their bound driver's cohort must not be re-rolled underneath them).
  Robustness details from the review pass: a slow in-place panel mount gets a 4s grace
  poll before any reload (parity with the callers' old trigger-probe tolerance); after
  the reload a composer-readiness poll (up to 8s) replaces the fixed settle so the SPA
  re-mount is never probed as a blank shell; the toggle click is unforced-first (a
  forced click can flip the DOM without firing the React handler that persists the
  setting), and the force fallback re-reads `aria-pressed` before clicking — Playwright
  can raise AFTER the events dispatched, and a blind second click would re-enable agent
  mode. A force-fallback click never arms the reload (nothing was persisted).
- **Composer-render race in mode control (found by the v0.38.1 live-verification gate)**:
  `ensure_media_mode` probed the freshly-navigated page before the SPA composer rendered —
  every selector counted 0, the loop broke as "nothing actionable" in ~100 ms, and the Agent
  toggle was likely never clicked at all in the prior production failures. An initial
  composer-readiness poll (up to 8s) now absorbs the render race; live-verified breaking a
  real ~2h agentic pin on the affected account (`docs/LIVE_VERIFICATION_v0.38.1.md`).
- **Crop-selector drift between the mode controller and the cohort detector**: `mode_control`
  probed only 2 of the 6 `crop_*` ratio icons while `drivers/factory` probed all 6 — the
  canonical 6-icon tuple now lives in `mode_control` (the leaf module) and `factory` imports
  it; `test_selector_symmetry.py` locks the identity.

## [0.38.0] — 2026-07-17

### Added

- **Robust agentic↔classic UI mode control** (#332): `--ui-mode` is now driven by a state-aware mode controller that reads Flow's Agent toggle (`aria-pressed`, locale-invariant) instead of icon heuristics — the "Tools" icon present in both modes could previously be misread as a forced-agentic cohort, causing spurious "not recoverable" aborts. `--ui-mode classic` now reliably reaches the classic editor: the controller closes the chat sidebar, toggles off only when actually in agent mode, and verifies the result. Live-verified with a full classic→agent→classic round-trip on real Flow.
- **i2i reference dedup via picker filename search** (#314): repeated local `--ref` images in `gflow image i2i` are attached by selecting the already-uploaded library tile (exact-filename picker search, project-scoped) instead of re-uploading — ending duplicate library pile-ups (the reported 8× `son.jpg`). Falls back to upload when the filename isn't found, and scrolls the virtualised picker grid so off-screen matches are still selected rather than silently re-uploaded (#335). R2V video refs keep upload-only behavior.
- **PR-Triage Autopilot (#238, #333)**: deterministic Stage 0 pre-filter and ephemeral Docker container sandbox executing the `/gflow:pr-council-review` skill against qualified external PRs hourly on the host VPS. Includes Telegram notifications and a persistent audit ledger. Implementation + fixture evals ship in this release; host-side deployment is staged separately.

### Changed

- **Cognitive-complexity refactor of 5 pure-logic functions** (#331): extracted cohesive private helpers to bring them under the Sonar S3776 threshold with zero behavior change (verified by types, scoped tests, and an adversarial behavior-diff review). The remaining S3776/S107 findings in essential-complexity live-automation code were accepted in SonarCloud with justification.

## [0.37.0] — 2026-07-17


### Fixed

- **Agentic image count enforcement** (#313): in the agentic (conversational) Flow UI cohort, the requested image count (`-n`) is now reliably enforced via the Agent settings panel, reworked to reuse classic mode's robust count-tab primitives (a stale sticky default there could previously override the natural-language directive). Covered by a live regression test.

### Changed

- **UI-automation viewport enlarged to 1920×1080** (from 1280×800) to reduce the static browser-fingerprint signal with the most common real desktop resolution. Only the `UiAutomationTransport` context is affected; the `FlowApiClient` REST context (1280×720, selector-irrelevant) is unchanged. Enlarging stays within Flow's desktop layout, so selectors are unaffected. Timing/click humanization from #315 remains out of scope — parked under ADR-13 (the current stealth stack already measures a 0.0% WAF-403 rate). (#315)
- **Auth-login viewports harmonized to 1920×1080** so a profile logs in at the same size it later generates with — `internal_chromium` (Playwright viewport) and `real_chrome` (`--window-size`). Login-window only, not selector-bound. (#315)

### Security

- **FIPS-safe SAPISIDHASH:** the protocol-mandated SHA-1 in Google's SAPISIDHASH computation is now marked `usedforsecurity=False` — it is a protocol hash, not a security primitive, and this lets the call succeed under FIPS-mode Python (which otherwise rejects SHA-1). The digest is byte-identical, so authentication is unchanged. (#329)

## [0.36.0] — 2026-07-16

### Added

- **`GFLOW_CLI_HAR_PATH`:** captures full Playwright network traffic (requests, responses, headers, cookies) to a HAR file for the session — useful for diagnosing wire-format surprises or WAF rejections. Opt-in, env-var only; the file is hardened to `0600` on POSIX after Playwright writes it (#316).
- **`GFLOW_CLI_DEBUG_TRACEBACK`:** prints the real exception message + traceback for unhandled errors — to the console and, under `--json`, into the payload's `error.detail`/`error.traceback` fields — instead of the generic placeholder. The structured telemetry event stays SHA-256-hashed unconditionally either way; this only changes what the operator/caller sees (#316).
- **`llm-council` skill:** `/gflow:llm-council` composes with `pr-council-review`, adding `codex`/`gemini` (opt-in `agy`) as independent external reviewers alongside the internal Claude-subagent council for high-stakes reviews (#320).


### Fixed

- **Reference entity smuggling:** a poisoned character entity (from a `gflow character create` that failed mid-workflow, e.g. the body-triptych step) could leak its `referenceEntities` into unrelated `gflow image i2i` calls in the same project workspace, even when the caller never passed `--reference-entity`. The UI-automation interceptor now strips unrequested `referenceEntities` before submit (#312).

## [0.35.0] — 2026-07-14

### Added

- **Multimodal Reverse-Engineering:** Integrated `gflow reverse-engineer` with `claude-video`'s `watch.py` script. When a video file or URL is passed, gflow now automatically extracts frames and uses the multimodal capabilities of Gemini to reconstruct a detailed, structured prompt.
- **Storyboard Creator:** Added a new built-in tool `storyboard` designed to scaffold a cohesive multi-panel storyboard from a narrative concept or scene description, ensuring visual and stylistic continuity across all panels.
- **GitHub Pages Site:** Created a static site structure for GitHub Pages, including a landing page and material-based documentation layout, with a polished theme aligned with project aesthetics (#308, #309).

### Changed

- **Dynamic Token Budget:** The `maxOutputTokens` parameter for Gemini prompt expansion now dynamically scales as a fraction of `max_output_chars` (approx. 1 token per 4 characters), clamped to a minimum floor of 512 tokens.
- **Agent-Agnostic Skills:** Refactored six command protocols and relocated them to the `skills/` directory to ensure they are accessible by any developer or AI coding agent regardless of the tool being used (#305).
- **Security Updates:** Bumped the `pillow` dependency to `>=12.3.0` to address 5 CVEs (PYSEC-2026-2253..2257) (#306).
- **Ruff Dependency:** Updated the dev-dependency `ruff` from `0.15.20` to `0.15.21` (#304).


### Fixed

- **Type Safety:** Added explicit `dict[str, object]` type annotations to the payload building in `PromptExpander` to satisfy strict Pyright invariance checks on dictionary values.

## [0.34.0] — 2026-07-12

### Added

- **`--ui-mode` / `GFLOW_CLI_UI_MODE` — the CLI can drive the Flow UI arm the command needs, both directions (#299).** Flow serves a **classic** composer or an **agentic** chat cohort, server-assigned and flapping per page load. Before generating, gflow now determines the **required** arm, switches to it as a prerequisite (classic↔agentic DOM toggle), **verifies** via a DOM re-probe, and — if the arm is unreachable — aborts *before* submitting with the new `UiModeUnavailableError` (**exit 28**, retryable), no credits spent. Values: `auto` (default; bind whatever renders), `classic` (require the hard aspect controls), `agentic` (require the chat surface). The required arm is also **inferred**: agent instructions (`-i`) are agentic-only, so they force agentic — closing the #267 gap where `-i` on a classic roll was *silently dropped* (now it either binds agentic or fails fast). Exposed as the **`--ui-mode` flag** on `gflow image t2i` / `i2i` (single-prompt; batch uses the env var) and the **`ui_mode` param** on the `gflow_generate_image` MCP tool; `--ui-mode classic` + `-i` is a fail-fast usage error. Grounded in the #299 spike (`docs/superpowers/spikes/2026-07-12-ui-cohort-backend-config.md`). Applies to every image generation via the shared driver seam. Honest ceiling: a server-side experiment can pin the arm, in which case the switch can't win — the abort still saves the credits.

### Changed

- **`GFLOW_CLI_PREFER_CLASSIC` and `GFLOW_CLI_FORCE_AGENT_UI` are deprecated (#299)** in favor of `GFLOW_CLI_UI_MODE=classic` / `=agentic` (both still work, mapping to the new modes with a `DeprecationWarning`). **Behavior change:** the old `prefer_classic` silent fallback to agentic when the classic toggle was unavailable is gone — a classic-required run now aborts with exit 28 instead. Pipelines that relied on "always yields a file" from `PREFER_CLASSIC=1` must handle exit 28 (retry / switch profile / `GFLOW_CLI_UI_MODE=agentic`).

## [0.33.0] — 2026-07-12

### Added

- **Configurable anti-bot jitter (#241).** The pause between multi-prompt image submissions is now tunable via `--jitter MIN-MAX` on `gflow image t2i` / `gflow image batch` or the `GFLOW_CLI_JITTER_RANGE` setting (env var or `.env`; flag beats env; a single number `N` means uniform 0–N like `video chain --jitter`; `0` disables; bounds must be finite and ≤ 3600 s). The previously **unpaced** paths — `t2i --prompts-file` / `--stdin` / multi-positional and `gflow run` image batches — now pace by default too; field data showed unpaced bursts tripping Flow's WAF (403 `PUBLIC_ERROR_UNUSUAL_ACTIVITY`). WAF cadence behavior and cooldown guidance documented in [DEBUGGING § WAF cadence](docs/DEBUGGING.md#waf-cadence).
- **`--project-name TEXT` on `gflow video i2v` (env: `GFLOW_CLI_PROJECT_NAME`).** The media picker's project menu lists projects by display NAME only — no ids anywhere in its markup, and unnamed projects show nothing but creation timestamps (live round-4 dump: 80 recency-ordered `menuitem`s). When gflow attaches an in-project asset by media UUID it must first select the right project in that menu, so it needs the project's display name. Automatic derivation is best-effort but live-validated (round 5 confirmed the editor tab title carries the name: `Google Flow - <project name>`); `--project-name` is the explicit, highest-precedence override for when derivation fails on other cohorts/locales — a permanent escape hatch, not a workaround. Threads `GenerateVideoRequest.project_name` through to the picker project-menu match; documented in `.env.template`. CLI-only for now: the MCP `gflow_generate_video` tool has no media-UUID frame inputs yet, so the override has no consumer there (command-level parity unaffected; the field rides along when ref-id support lands) (#287).

### Changed

- **Default image-batch jitter lowered from 3–7 s to 0.5–1.5 s (#241).** The default is deliberately minimal — enough to break a perfectly uniform burst signature without wasting wall-clock. Widen (`--jitter 10-30` / `GFLOW_CLI_JITTER_RANGE=10-30`) when runs start hitting WAF 403s, then dial back once the score decays.


### Fixed

- **`gflow video i2v <media-uuid>` now reaches assets deep in a crowded project's virtualised media grid (#287 — primary fix, part 1: scroll on the RIGHT node, progress-bounded).** The live repro: `TransportTimeoutError` ("Start frame asset ... could not be located in the media picker") on a ~100+-asset project for an asset that WAS in the project and in the local catalog, while the same command worked from a small scratch project. `_select_existing_asset`'s scroll fallback had a fixed budget (12 scrolls x 500 px), capping the reachable depth of the react-virtuoso grid regardless of grid size — and the round-6 audit exposed a second layer: the scroll was a blind hover+wheel over the dialog, but react-virtuoso scrolls its OWN container, so a wheel over the wrong node is a silent no-op that looks exactly like "end of grid". The scroll (shared with `_find_picker_entity_tile` via `_scroll_picker_grid_until_rendered`) now drives the dialog's ACTUAL scrollable element via JS (`[data-virtuoso-scroller]` preferred, then the first overflow container; hover+wheel kept as fallback when the probe fails), and is bounded by evidence of progress: it keeps scrolling while the set of rendered tile identifiers still changes between scrolls — depth proportional to grid size — stops after 3 consecutive no-progress scrolls, retains the legacy 12-scroll budget when the DOM probe yields no evidence, and caps at a 200-scroll hard ceiling. Every scroll probe event reports WHICH node moved (tag + class) and its scrollTop before/after, so a wrong-node no-op (frozen scrollTop) is visible in telemetry. The not-found contract is unchanged: same `TransportTimeoutError` naming the slot and UUID (#287).
- **CLI-resolved PROMPT search hints surface UUID frame refs via Flow's media search (#287 — primary fix, part 2).** Live rounds proved Flow's picker search does NOT index media UUIDs (both the full-UUID and UUID-stem tiers found nothing), but each picker tile's `alt` text carries the asset's generation PROMPT — which the search does index. New `get_asset_prompt(db_path, media_id)` catalog query (latest output-operation prompt by `flow_media_id`); `gflow video i2v` resolves each UUID frame ref's recorded prompt and passes its first 6 words as `GenerateVideoRequest.search_hints` (best-effort — no catalog, no hints; layering respected: the CLI resolves because it owns catalog access, the transport only consumes). `_select_existing_asset` types each hint into the picker search box after the UUID tiers and still matches tiles by UUID-in-`src` among the results, so an imprecise hint can only surface extra tiles, never select a wrong one; a hint hit skips the scroll fallback entirely. The pre-existing tiers (display name, media UUID, UUID stem) are kept as cheap first attempts (#287).
- **Hardening: the media picker's library view is verified/aligned to the target project before any UUID asset lookup (#287 — demoted from root cause after round 5).** Round-2's DOM dump appeared to show the picker's library open on a DIFFERENT project ("gflow-cli t2i", 16 tiles, target id nowhere in the dialog), and rounds 2-5 built project-alignment machinery on that reading. The round-5 title telemetry then inverted it: the raw tab title on `/project/f6caf027` was "Google Flow - gflow-cli t2i" — the trigger's "gflow-cli t2i" WAS the target project's actual display name, so the picker had been on the correct project all along and the round-2 evidence was a mirage. The machinery stays as hardening (the picker's library IS per-project with its own selector, so it CAN open on the wrong project — now that state is detected and corrected, and the round-5/6 name derivation gives the match a working source): `_sync_picker_project` runs each time the frame-slot / Add-Media dialog opens: it derives the target project id from the editor URL, resolves the project's display NAME (the menu renders names, not ids; live round-3 run confirmed the previous href/class-only page probes find nothing) — precedence: the `--project-name` / `GFLOW_CLI_PROJECT_NAME` override, then the editor tab title (`document.title` — the editor was navigated to `/project/<id>` before the picker opened; "Flow" AND "Google Flow" branding is stripped tolerantly across separator variants — the live-observed pattern is `Google Flow - <project name>` — branding-only titles are rejected so 'flow' can never contains-match a project like 'gflow-cli i2i', and the raw title is logged on every resolution so the real live pattern stays learnable), then an element whose `href` references the project id, then a project-title-classed element (the local catalog's `projects.title` was considered but the transport layer has no catalog access, and the live page also covers renames and non-gflow projects) — probes the trigger cascade with the live-observed Radix `ProjectDropdownSubTrigger` class first (the generic `aria-haspopup='menu'` fallback tier explicitly excludes the sibling `SortDropdownSubTrigger` — "Recentes" on the observed pt-BR profile — and no tier matches on locale-dependent labels), no-ops when the trigger already shows the target project (by id, or by resolved name — exact OR contains, since the trigger text carries icon-ligature noise; round 5 wasted ~30 menu probes hunting for a project it was already in because the probe demanded exact equality) or when no selector exists (older cohort), and otherwise opens the Radix submenu (click, then hover, then focus+ArrowRight — SubTriggers may ignore plain click — each step verified against the portal-rendered `[role='menu'][data-state='open']`), polls up to ~3s for the portal to POPULATE (live round 3: the open-state flips before the project list renders — matching an empty portal was a guaranteed miss), and clicks the innermost candidate matching the target — anchors whose `href` carries the project id first (round 3 also showed the portal holds ZERO classic menu-item ARIA roles, so the sweep covers generic clickables: `a`, `button`, `li`, `div[role]`, plus the ARIA roles), then the id anywhere in markup, then the normalized name (exact match before contains, so timestamp-labeled scratch entries like "Jul 11, 11:00 PM" can't collide). When the in-view match misses, the open portal itself is scrolled with the same progress-bounded pattern (scroll one step, re-match, stall-terminate when the rendered item set stops changing, hard ceiling) — the recency-ordered menu holds EVERY project and the target's entry can sit below the visible fold. A miss closes the menu (Escape) and proceeds, leaving the asset lookup as the authority.
- **Every picker-lookup decision point now emits structured telemetry, and each failure mode leaves a bounded DOM dump (#287 diagnosis).** The first live verification failed with zero events from the new code paths, making the failing layer indistinguishable (search tiers vs progress probe vs tile matcher vs wrong library project) — this telemetry is what confirmed the root cause in round 2. New `ui_automation_video.*` events: `picker_project_selector_absent` / `picker_project_already_active` / `picker_project_menu_opened` (opened + method: click/hover/keyboard) / `picker_project_menu_populated` (element count after the population poll) / `picker_project_switched` (matched_by: href/id/name) / `picker_project_switch_miss` (menu_opened, menu_elements, candidate count, dump path) / `picker_project_sync_skipped` / `picker_project_name_override` / `picker_project_name_resolved` / `picker_project_name_unresolved` (both name events carry the raw tab title) / `picker_project_menu_scroll_probe` (per menu scroll: rendered item count + new-item delta) / `picker_project_menu_scroll_done` (reason: found / stall / no_menu / ceiling) (project alignment), `picker_search_tier` (term, found, rendered-tile count) and `picker_search_unavailable`, `picker_scroll_probe` (per scroll: rendered-tile count + new-tile delta, plus WHICH node was scrolled — tag + class — and its scrollTop before/after, so a wrong-node no-op scroll with a frozen scrollTop is visible) and `picker_scroll_done` (termination reason: found / stall / legacy_budget / ceiling, total attempts), and `existing_asset_not_found` (media id, project id, screenshot + dump paths). On a final not-found, `_capture_picker_dom_dump` writes `debug_picker_dom_<uuid8>.json` to the out-dir — tile count, the first 3 tiles' outerHTML truncated to 500 chars (enough to see which attribute carries the media identity in a given cohort), the dialog's aria/role/data attributes, the project-selector candidates' outerHTML, and whether the target project id appears in the dialog at all — plus a `debug_picker_miss_<uuid8>.png` screenshot. On a project-switch miss, the OPEN portal's raw innerHTML (bounded to 4000 chars) plus its child-element count and tag histogram are written to `debug_picker_project_menu_<uuid8>.json` and summarized on the event — round 2's closed-trigger dump and round 3's role-filtered item list both left the menu structure invisible; raw markup can't be blinded by role assumptions. All dumps follow the 0.32.1 None-on-capture-failure contract (never report a file that was not written) (#287).

## [0.32.1] — 2026-07-11


### Fixed

- **Browser teardown can no longer hang forever or leak a Chrome tree that locks the profile dir (#293).** A wedged `context.close()` used to be awaited unbounded and its failure swallowed to a warning; stopping the Playwright driver afterwards kills only the Node process, so the detached system-Chrome survived holding the profile — the next run then died at launch with an opaque `TargetClosedError` → "Unexpected error." (exit 1) (observed 3× live, 2026-07-11). Teardown now uses a shared bounded-close helper (generous 30s graceful bound — Playwright hard-kills Chrome mid-profile-flush if a second close arrives during a graceful close, so a slow-but-healthy close must not be escalated; 5s force-close fallback via `context.browser`; 10s driver-stop bound; field resets survive Ctrl-C) across **all three** owned-context teardown paths: `FlowApiClient`, the UI-automation transport's standalone path (its partial-setup guard now also closes a launched context before the driver exits), and the experimental evaluate-fetch transport. A launch-time `TargetClosedError` is now surfaced as `ProfileLockedError` (exit 11) carrying the original error and a kill-the-stale-Chrome remediation, hedged for non-lock startup crashes (#293).

- **Picker grid scroll no longer misses a tile rendered by the final scroll (#283 off-by-one).** `_select_existing_asset` checked the tile count only *before* each scroll, so an asset the last scroll brought into the virtualised grid was never re-checked and the picker gave up with the tile on screen. A post-loop re-check closes it (`_find_picker_entity_tile` shares the loop shape but returns the locator unconditionally, so it was unaffected — now documented).
- **Agentic `await_images` no longer trusts a single exact-count scrape (#283 hardening of the #281 race).** The poll loop breaks only when the new-UUID set is identical across two consecutive scrapes at the expected count (~one extra 0.5s poll); a set that transiently hits the exact count and then grows surfaces as the #281 `MediaAttributionError` instead of being returned as "the" generated media.
- **Debug screenshots that fail to capture are no longer reported as if they existed.** `_capture_debug_screenshot` returned the target path even when `page.screenshot` raised (observed live 2026-07-11: an error message pointed at a file that was never written). It now returns `None` on capture failure and every error message appends its `Screenshot:` clause conditionally (new `screenshot_clause` helper) (#283).

### Changed

- **UUID-shape validation consolidated onto `gflow_cli.api.video.is_media_uuid`.** The four per-module private `_UUID_RE` copies (cli_image, cli_instructions, image_upscale, mcp/tools) now delegate to the public helper introduced in #290; no behavior change. `MediaAttributionError` raises in the recorder now carry `route=` provenance, the agentic ambiguity raise no longer duplicates the class remediation text, `image i2i --ref` help uses the same "media UUID" vocabulary as `video i2v`, and a bad value passed via the deprecated `--end-image` alias names `--end-image` (not `--end-frame`) in its usage error (#283).

## [0.32.0] — 2026-07-11

### Added

- **`gflow video i2v` accepts an in-project asset media UUID for `--initial-frame` / `--end-frame` (and the positional IMAGE).** A UUID-shaped value selects the already-existing Flow asset in place via the same `_select_existing_asset` picker the image `--ref` flow uses (#282 scroll/search fixes included) instead of forcing a duplicate local-file upload — the duplicate-asset pileup and per-run re-upload from the 2026-07-11 chalkboard pilot. Pair with `--project` so the asset's project is the one generated in; a UUID that can't be located in the picker fails with `TransportTimeoutError` (exit 9) naming the slot and UUID (#287).


### Fixed

- **A Flow upload-endpoint rejection is now a typed error instead of "Unexpected error." (exit 1).** An `uploadImage` 4xx during frame/reference attach (observed live: one JPEG rejected with HTTP 400 while byte-identical-format siblings uploaded fine) raised a bare `RuntimeError` that fell through to the generic handler with no hint the *input image* was refused. It now raises the new `MediaUploadRejectedError` (**exit code 27**, RFC 9457 type `media-upload-rejected`) with a re-encode remediation hint (`ffmpeg -q:v 2 -map_metadata -1`) (#287).
- **An explicit `--duration` that cannot be applied now fails fast instead of silently producing a clip of Flow's default length.** When the video settings panel's duration tab probe missed (observed 3/3 on a live 2026-07-11 Frames-submode run: `--duration 4` returned an 8-second clip and the JSON result reported success), `_select_video_duration` demoted the failure to a warning and generation continued on Flow's default. Duration is a contract parameter — downstream timeline math sizes cuts from the requested value — so a probe miss with an explicit `--duration` now raises `UiSelectorDriftError` (**exit code 23**, the #183 selector-drift semantics) with a `debug_no_duration_tab.png` viewport screenshot and an omit-`--duration` remediation hint. Omitting `--duration` is unaffected. Root cause confirmed live 2026-07-11: the duration control is absent from the affected cohort's settings popover (#288, #289).

## [0.31.0] — 2026-07-10


### Fixed

- **Agentic image generation no longer risks attributing a pre-existing project asset to the current request.** `await_images` settled its new-media baseline with a single DOM scrape, which could miss a lazily-rendered pre-existing tile and let `_build_generated_images` slice an arbitrary UUID out of an unordered set as "the" generated image — the 2026-07-10 production incident: an old project logo was silently downloaded and reported as a fresh generation. The baseline is now the **union of two `_scrape_img_srcs` passes** one poll interval apart, absorbing lazy-render stragglers before they're mistaken for new media, and if more new UUIDs still appear than were requested, `await_images` now fails fast with the new `MediaAttributionError` (**exit code 26**, RFC 9457 type `media-attribution`) naming every candidate UUID and the expected count instead of guessing (#281).
- **A pre-download attribution guard now runs ahead of every image download, with `DataIntegrityError` escalated instead of warned.** Even a driver that never hits the agentic ambiguity check above can still hand back a `flow_media_id` already recorded for the profile. `OperationRecorder.verify_media_attribution()` (called from `cli_image.py`, `image_batch.py`'s manifest batch path, and `FlowWorker.process_task`) checks `is_media_recorded()` before `_download_images` and raises `MediaAttributionError` rather than downloading — it also now rejects an intra-batch duplicate `flow_media_id` (the classic transport can return the same media twice in one submission) with no DB lookup needed. Separately, a `DataIntegrityError` from the recorder's `UNIQUE(profile_name, flow_media_id)` constraint — previously caught by the generic `DataStoreError` path and reported as a warn-only "Generated media was saved, but local history was not updated." — now escalates to the same `MediaAttributionError` when (and only when) the failing write is that exact constraint (`route == "data.upsert_asset"`); any other `DataIntegrityError` (e.g. an unrelated `insert_operation`/`link_operation_asset` failure) falls through to the ordinary warn-and-continue path instead of being mislabeled as a media collision. The escalation message now names the full candidate set of `flow_media_id`s / saved paths ("one of ...") rather than always fingering the first image, since the colliding index can't be recovered from sqlite's bare constraint violation (#281).
- **The pre-download attribution guard and the collision-escalation logic are each now a single shared implementation instead of three near-identical copies.** Both originally shipped duplicated across `cli_image.py`, `image_batch.py`, and `worker/daemon.py` (each call site already held a recorder instance), which tripped SonarCloud's duplicated-lines gate. The guard is consolidated onto `OperationRecorder.verify_media_attribution()`; the escalation is consolidated onto the new `gflow_cli.data.recorder.escalate_asset_collision()` — both with no behavior change beyond the route-scoping and intra-batch-duplicate fixes above (#281, #282, #283).
- **`gflow image batch` (the manifest path) now honors `--continue-on-error` for a media-attribution collision.** A collision on one row — from either the pre-download guard or the post-download collision escalation — used to propagate out of the whole batch run regardless of `--continue-on-error`, discarding every other row's already-completed outcome. With `--continue-on-error` the colliding row is now marked as a normal "fail" outcome (nothing was downloaded/recorded for that row) and the batch continues; without it, the collision still aborts the run as before (#281, #282).
- **`--ref <uuid>` picker selection now resolves every ref, not just the first.** `_select_existing_asset` gave up as soon as a tile wasn't in the initial viewport or surfaced by the display-name search, so any `--ref` after the first raised `TransportTimeoutError` once the virtualised (react-virtuoso) media grid hadn't rendered it yet. It now falls back to scrolling and re-checking between scrolls, mirroring the entity picker's `_find_picker_entity_tile` strategy, and `_attach_image_uuid_refs` clears the picker search input at the start of every ref iteration so a search typed while resolving one ref can't shadow the next ref's tile lookup. `_select_existing_asset` itself now also clears a failed display-name search before falling back to scrolling, so it doesn't scroll a grid still filtered by the failed term (#282).

## [0.30.0] — 2026-07-09

### Added

- **MCP `gflow_generate_video` model/duration/count parameters (CLI↔MCP parity):** agents can now select the Veo model (`veo_lite`/`veo_fast`/`veo_quality`/`omni_flash`, aliases accepted), clip duration, and batch count through MCP, matching the CLI `gflow video` flags. An unknown model is rejected up front with a 400 instead of failing deep in the worker; an omitted model still lets the transport apply its i2v veo-lite default (issue #125). Co-authored-by C1ph3r404 (from the closed PR #258). Note: the pre-existing transport-level i2v veo-lite default already protected the MCP path, so this is parity + agent control, not a new credit guard.


### Fixed

- **Character-create recorder no longer crashes on a duplicated `flow_media_id`.** Under the agentic cohort the classic character-editor slot-add control is absent, so the body prompt lands in the still-active face slot and both slots report the same `flow_media_id`; `_record_character_local_files` minted a fresh asset `id` per slot and the second slot violated `UNIQUE(profile_name, flow_media_id)` → `DataIntegrityError`. The recorder now reuses the existing asset id (mirroring `record_completed_video`), making character local-file recording idempotent on the business key. Regression test in `tests/data/test_recorder_character.py`.
- **`prefer_classic` no longer logs a misleading `WARNING` on the agentic cohort.** The server-gated agentic (`tune`) cohort cannot be exited client-side, and `prefer_classic` is best-effort by contract, so `get_ui_driver` now logs that expected fall-through at `INFO` (`ui_driver.prefer_classic.cohort_natively_agentic`) and reserves `WARNING` for genuinely unexpected exit failures.

## [0.29.0] — 2026-07-09

### Added

- **Persistent `gflow instructions` command group:** CRUD over project brief cards (add, list, enable, disable, rm, apply, toggle-mode) with title/ID selection, master toggle, and REST upload support for card reference images. Live-verified credit-free end-to-end (see `docs/LIVE_VERIFICATION_v0.29.0.md`).
- **Declarative full-sync:** `gflow instructions apply FILE` for idempotent sync of instructions from TOML or JSON brief files.
- **Movie manifest instructions integration:** Global `[instructions]` and per-scene `[scenes.instructions]` blocks in `movie.toml` to dynamically sync project brief cards before generating clips (per-scene re-sync memoized via `_BriefSyncCache`; documented as a destructive full-sync).
- **`gflow_instructions_*` MCP tools:** six new tools (`list`, `add`, `set_enabled`, `rm`, `toggle_mode`, `apply`) giving MCP agents the full instructions CRUD surface — thin adapters over the same live-verified brief primitives, credits-free, RFC 9457 error envelopes. `gflow_list_tools` and the new tools are now documented in `docs/MCP.md`. Note: `gflow_generate_video` deliberately has no `instructions` param (the video pipeline has no instructions support — documented asymmetry).
- **MCP↔CLI parity contract enforced in CI:** `tests/mcp/test_cli_parity.py` walks every CLI leaf command and fails when one has neither a mapped MCP tool nor an explicit, reasoned exemption.

### Changed

- **Agentic-indicator selectors consolidated:** the 4 agentic cohort ligature probes are now canonical in `drivers/factory.py` (`AGENTIC_INDICATOR_SELECTORS`, `AGENT_TUNE_INDICATOR_SELECTOR`); both UI transports import them instead of carrying drift-prone copies, locked by a new symmetry test.

### Internal

- **`/gflow:check` and the PR council are now CI-faithful:** the check gate runs the exact CI verify commands (`ruff format --check`), the council pre-flight gained a D0 mechanical CI gate that hard-blocks on a red run, and `check_doc_links.py` joined CI — closing the gap that let a format failure ship past an 8-agent council review.

## [0.28.0] — 2026-07-08

### Added

- **Agent instructions (`-i` / `--instruction`) now actually steer generation.** On an
  agentic-cohort Flow session, `gflow image t2i "…" -i "Every image is a flat 2D crayon
  drawing"` makes the agent adopt that style (live-verified end-to-end). Instruction cards are
  synced to the project's Agent brief via `PATCH /v1/projects/{id}/agentInfo`, and the agent
  folds every **enabled** card into the generation. Cards carry distinct titles and may
  reference image assets. Persistent CRUD (`gflow instructions`) and movie-manifest wiring are
  planned follow-ups.


### Fixed

- **Instructions were silently inert (agentic transport).** Two root causes, both found via a
  live spike: (1) the composer used an imperative `"Generate N images: …"` directive that the
  agent passes to the image tool verbatim, bypassing the brief — now phrased conversationally
  so the agent's reasoning step applies the cards; (2) the brief-level master switch
  `project_brief.enabled` was never set (defaults off on a fresh project → all cards ignored) —
  now enabled whenever cards are synced. Also fixes a wrong PATCH content-type
  (`application/json+protobuf` → HTTP 400, silently) and a hardcoded per-card title that
  collapsed every card to one name.
- **`-i` no longer no-ops without warning on a classic-cohort session:** a clear warning is now
  emitted (instructions only apply on agentic sessions).

## [0.27.1] — 2026-07-07


### Fixed

- **Version Wiring in Movie Handoff:** Properly imported and passed `__version__` to `build_handoff()` generator version instead of using a hardcoded stale default (`0.14.0`).
- **Rich Markup Escaping in CLI Output:** Escaped brackets in `_format_scene_line` plan output (`[t2v]`, `[r2v]`, and `refs=[...]`) so they are not swallowed by Rich console formatting.
- **MCP Server Stale Version:** Wired FastMCP version to `__version__` dynamically on startup, fixing the stale `0.21.0` version trap.
- **MCP Agent Guide:** Added `gflow_list_tools` to the list of available tools in the static MCP agent guide resource.

### Added

- **Document Anchors:** Added HTML anchor (`style-configuration-errors`) to `docs/MOVIE.md` for reserved name `"none"` and unknown style variant `ConfigurationError` paths.
- **Movie Usages Documentation:** Added complete documentation for `gflow movie run` and `gflow movie template` commands to `docs/USAGE.md`.

## [0.27.0] — 2026-07-07

### Added

- **Global `[style]` block with named variants in `movie.toml` (Issue #239):** channel-format
  videos can now express a visual style system (e.g. monochrome → warm color arc) once in the
  `[style]` block and select it per-scene via `style_variant`, without repeating style text in
  every scene's action. Adds `prefix`/`suffix` fields to `[style]`, `[style.variants.*]`
  sub-tables, per-scene `style_variant` and `style_suffix` fields, deterministic composition
  rule, and `style_applied` (variant/prefix/suffix/scene_suffix) per clip in the handoff
  manifest. `none` is a reserved variant name (opt-out keyword) and may not be defined.
- **Prompt-aware resume for `movie run`:** completed scenes now persist a SHA-256 hash of
  their composed prompt (`style_hash`); on resume, a scene whose prompt changed (style edit,
  variant switch, action tweak) is regenerated instead of silently skipped. Unchanged scenes
  still cost nothing. Old state files fall back to comparing the stored prompt text and are
  never re-run on a guess. Dry-run shows the resolved style per scene and marks stale scenes
  as `re-run (style changed)`.

## [0.26.0] — 2026-07-06

### Added

- **Reference a generated image in `image i2i` by its Flow UUID (`gflow_generate_image`,
  `reference_images`)**: pass a generated image's media UUID as a reference and gflow
  attaches it by **selecting the already-existing asset in Flow's reference picker** —
  it does **not** upload a duplicate copy (avoiding duplication is the preferred path).
  The asset's tile is located by its media id in the thumbnail URL (robust to
  display-name collisions), surfaced by a display-name search when it isn't already
  visible, and attached in place. When the asset can't be located (e.g. it's in a
  different project's picker), gflow falls back to uploading its on-disk local file. A
  UUID that isn't in your catalog still attaches by media id (no error). Live-verified:
  a generated image's UUID → i2i output that references it, with no duplicate upload.
- **Generated images now record their Flow display name**: the display name is extracted
  from the `batchGenerateImages` response's `workflows[]` array (previously ignored) and
  persisted in the asset catalog — the searchable label the media picker shows, and what
  the UUID-reference path searches by. (Original find and approach by **@C1ph3r404**,
  #253/#255.)

## [0.25.0] — 2026-07-06


### Fixed

- **Follow-up review fixes for remote image UUIDs (#237/#245)**: a post-merge
  multi-angle review surfaced regressions and defects now corrected:
  - Image `i2i` with a Flow media-id ref that isn't in the local catalog is no
    longer rejected — UUID→display-name resolution is applied only to the video
    paths (image refs attach by media id). Restores the `i2i` pass-through.
  - The generation result envelope's `flow_media_id` again carries the real
    media id (it was returning the asset's `flow_workflow_id`); the workflow id
    is exposed under its own `flow_workflow_id` key.
  - An in-catalog asset with no display name no longer returns its raw UUID as
    the picker search term (which timed out); it fails fast with a clear error.
  - Remote picker tiles match the display name exactly (`get_by_role(exact=True)`),
    so a name that is a substring of another can't silently attach the wrong image.
  - The R2V picker-close timeout matches the I2V budget (was a too-tight 8s that
    aborted slow-but-successful attaches).
  - `_attach_reference_audio` selects its tile by ARIA role+name instead of an
    apostrophe-unsafe `:has-text()` selector.

- **Remote-UUID video attach reworked to use local upload (#237)**: live
  verification found the original mechanism — resolve the UUID to a display name
  and select its tile in Flow's resource picker — could never work for generated
  media: Flow's asset search does not index generation prompts, and generated
  assets carry no display name, so the picker returned "No results found" and the
  attach timed out. The UUID is now resolved to the image's on-disk local file and
  attached through the existing, already-verified file-upload path. The failing
  picker path is no longer used for video UUID refs. (Automatic download-by-media-id
  for the rare case where the local file was pruned is a planned follow-up; for now
  that case fails fast with a clear "Reference Not On Disk" error.)

- **`gflow_generate_image` no longer silently saves a video as an image**: the
  agentic image path has no explicit image-mode toggle — Flow's conversational
  agent infers image-vs-video from the prompt and can produce a *video*, whose
  tile is then scraped as if it were an image. The MP4 bytes were saved with a
  `.png` suffix and catalogued as an image, a silent corruption that only
  surfaced far downstream (Flow 400-rejects the file as an i2v frame → text-only
  #125 fallback). `download_image` now detects video magic bytes (ISO-BMFF / WebM)
  and fails loud with a `WireFormatError` naming the cause, instead of writing the
  corrupt file. (Root cause — the agentic agent producing a video for an image
  request — is tracked separately; this stops the silent corruption.)

- **Rejected i2v/r2v frame uploads now fail loud instead of falling back to T2V**:
  `_upload_via_open_dialog` matched the `uploadImage` response by URL only and
  ignored its status, so a Flow 4xx rejection (e.g. an invalid image file) was
  treated as success — the code committed an empty slot and the generation
  silently produced a text-only video (#125). The upload status is now checked and
  a rejection aborts with a clear error.

### Added

- **Remote image UUIDs in `gflow_generate_video` (#237)**: I2V (`initial_frame` /
  `end_frame`) and R2V (`reference_images`) now accept a generated image's Flow UUID,
  not just a local file path — pipe the output of an image generation straight into a
  video generation. At enqueue time the UUID is resolved to the image's local file
  (already on disk from the image generation) and attached through the same proven
  file-upload path used for a local `--initial-frame`, so no picker name-search is
  involved. A UUID that isn't in your asset catalog fails fast with a clear "Reference
  Not Found" error, and a catalogued asset whose local file is missing fails fast with
  "Reference Not On Disk" (re-generate it or pass a local path) — both instead of a
  long browser timeout. (Contributed by @C1ph3r404; the attach mechanism was
  reworked during maintainer live-verification — see Fixed below.)


### Fixed

- **Removed a shadowed duplicate `Settings.daemon_token` field definition (#243)**: the
  class body defined `daemon_token` twice; Python silently kept only the second
  (aliased) one, leaving the first as dead code that a future edit could touch without
  effect. The surviving definition's contract (both `GFLOW_CLI_DAEMON_TOKEN` and
  `GFLOW_DAEMON_TOKEN` accepted) is now pinned by tests, along with a guard that the
  field is defined exactly once.

- **`$GFLOW_CLI_HOME/.env` now loads as a dotenv fallback (#240)**: `config.py`'s own
  module docstring promised a `.env` fallback "from CWD or `$GFLOW_CLI_HOME/.env`", but
  the implementation only ever read the CWD file — a key placed in the home `.env` was
  silently ignored (easy to miss under the prompt tools' never-fatal contract, and it
  bites any process whose CWD is not a project root: the MCP server launched by a
  desktop client, a worker service, a scheduled task). `Settings` now defaults the
  standard pydantic-settings `_env_file` init kwarg to `($GFLOW_CLI_HOME/.env, ./.env)`
  per construction, so explicit `Settings(_env_file=...)` — including the disable idiom
  `_env_file=None` — keeps working. Precedence: process env vars beat both files, and a
  CWD `.env` beats `$GFLOW_CLI_HOME/.env`.
  - **Home resolution is coherent across every channel**: the home used to locate the
    home `.env` now matches what `Settings.home` reports when `GFLOW_CLI_HOME` comes
    from the process env (case-insensitively, as the env source matches it), from a
    `GFLOW_CLI_HOME` entry in the CWD `.env`, or is set-but-empty (treated as unset
    rather than `Path('.')`). The home `.env` itself cannot relocate home (circular).
  - **Docs reconciled**: `docs/CONFIGURATION.md` § ".env loading", `docs/SECURITY.md`
    (Gemini-key locations) and `.env.template` previously documented CWD-only loading
    and now describe the two-file behavior; the `gflow serve` token hint no longer
    points at `.env.local`, which was never a loaded file.
  - **Worker daemon**: `FlowApiClient` constructions in `process_task` now receive the
    daemon's cached settings instead of re-reading `.env` files live per task, so a
    mid-run edit to the home `.env` can no longer produce a task whose client config
    disagrees with the parameters the task derived from `get_settings()`.

## [0.24.0] — 2026-07-01

### Added

- **`--project` on `video t2v`/`i2v`/`r2v` (#233)**: generate into an existing Flow
  project instead of always creating a scratch project, matching `image t2i`/`i2i`.
  Lets programmatic callers (e.g. a multi-clip storyboard worker) share one project
  across several video generations instead of leaving one throwaway project per clip.
- **`project` parameter on the MCP `gflow_generate_image` / `gflow_generate_video`
  tools**: mirrors the CLI `--project` flag so MCP callers can also target an existing
  Flow project (validated against the same id format). Completes `--project` parity
  across the CLI and MCP surfaces.

## [0.23.0] — 2026-07-01

### Added

- **MCP generation is now functional (#228)**: the `gflow_generate_image` and
  `gflow_generate_video` MCP tools — previously non-functional stubs — now enqueue onto
  the FlowWorker queue and run end-to-end, with the background worker owning download and
  history recording. The `tools` parameter (e.g. `creative-director`) is now applied to
  expand the prompt before generation (it was previously accepted but never applied), and
  reference images are supported across the image (`i2i`) and video (`i2v` / `r2v`) tools.


### Fixed

- **macOS generation 401 — resolved (#222, #230)**: Flow cookies are now read from the
  full cookie jar filtered by domain instead of a path-`/` URL filter that silently
  dropped the `/fx`-scoped `__Secure-next-auth.session-token`; and on macOS — where the
  headed generation context can intermittently fail to decrypt the on-disk cookie store —
  the session is seeded into the context from a snapshot captured pre-launch via the
  working `--password-store=basic` reader. Verified end-to-end on macOS (Apple Silicon) by
  the reporter. Thanks @gunalak.
- **MCP video task safety (#228)**: `i2v` now requires `initial_frame` and `r2v` requires
  `reference_images`, validated at the tool boundary with a clear error; a post-success
  recording failure no longer flips a credit-spent video to `failed`; and any
  non-`completed` task status is reported as a failure rather than a false success.
- **Chrome channel on Chromium-only hosts**: `channel_for_profile()` now gates
  Playwright's `channel="chrome"` on a new `_is_playwright_chrome_channel_available()`
  check that probes only the exact Google-Chrome paths Playwright hardcodes, instead
  of `is_chrome_available()` (which also accepts Chromium). On a host with only
  Chromium installed, the CLI no longer requests `channel="chrome"` and fails with
  `Chromium distribution 'chrome' is not found at /opt/google/chrome/chrome`; it falls
  back to bundled Chromium and logs an actionable warning (#219).
- **Text-to-image extra-image billing**: the generation-settings trigger selector now
  requires `button[aria-haspopup='menu']` (aliased to `MODE_SWITCH_TRIGGER_SELECTORS`),
  preventing a mis-click on an icon-only aspect thumbnail that skipped the count panel
  and left Flow's own default count (typically 2) in effect — billing extra generations
  while the CLI saved only one (#219).
- **Extra-image observability**: `generate_image()` now logs a
  `client.generate_image_extra_returned` warning when the transport returns more images
  than the requested `count=1`, so silent over-generation is surfaced to the user (#219).
- **macOS generation 401 — fail loud (#222)**: a `chrome`-strategy profile that is
  silently downgraded to bundled Chromium at generation launch now raises instead of
  running logged-out, so the macOS auth failure surfaces at its cause rather than as an
  opaque later `401`.

### Diagnostics

- **Persistent-context cookie state (#222)**: generation launch now logs the resolved
  `cookies_db_path` (`client.persistent_context_launch`) and the launched context's own
  cookie state (`client.context_cookie_state`: `flow_session_cookie_present` / count /
  expiry — **never values**, safe to paste publicly). This splits a cookie-**load**
  failure (the macOS persistent context cannot decrypt the profile's cookies) from a
  server-side rejection — the observability that localized the macOS `401` root cause,
  now resolved (see the #222/#230 entry above).

## [0.22.0] — 2026-06-28

### Added

- **Tools framework ("Creative Director")**: a TOML-defined prompt-tool system with
  `creative-director` as the first built-in tool, exposed via two surfaces:
  - **`gflow tools list/show/run`** — discover tools, inspect their styles, and run them
    standalone (e.g. `gflow tools run creative-director "a cat" --style cinema --json`).
  - **`-t` / `--tool` option** on every generation command — `image t2i` / `i2i` / `batch`,
    `video t2v` / `i2v` / `r2v` / `chain` — apply one or more tools before generating
    (e.g. `--tool creative-director:style=cinema`). Repeatable. On multi-prompt batches and
    chains the tool is applied per prompt/link. Replaces the never-released `-e/--expand` flag.
  - The `creative-director` tool rewrites a terse prompt into a vivid one using Google's
    five-component formula (Subject + Action + Context/Location + Composition/Camera + Style)
    via the public Gemini API. Requires `GFLOW_CLI_GEMINI_API_KEY`
    ([get one](https://aistudio.google.com/apikey)); optional `GFLOW_CLI_GEMINI_MODEL`
    (default `gemini-2.5-flash`). Domain-vocabulary modes (`--style cinema`, `portrait`,
    `product`, etc.) inject specialized lens/lighting/colour vocabulary; styles are
    **category-gated**, so image styles apply to image commands and video styles to video.
  - Tool application is **never fatal** — missing key, rate limit, or any API/network fault
    degrades gracefully to the original prompt.
  - **History**: a generation rewritten by a tool records the user's original prompt in the
    `prompt` column, the submitted expansion in `expanded_prompt`, and the applied tool
    (`{name, version, model, params, config_hash}`) in `operations.metadata_json.tool` — all
    honoring `GFLOW_CLI_HISTORY_PROMPTS=redacted` (the redacted form stores only
    `{name, version, params_hash, config_hash}`).
  - MCP parity: `gflow_list_tools` tool and a `tools` array parameter (`[{name, options}]`) on
    `gflow_generate_image` / `gflow_generate_video`, validated and adapted to the CLI
    `--tool` form.
  - **"My Tools"**: drop your own tool TOMLs into `<GFLOW_CLI_HOME>/tools/*.toml` and they are
    registered automatically — listed by `gflow tools list`, usable via `--tool`, and exposed over
    MCP, just like built-ins. A user tool may override a built-in of the same name (logged via
    `tool_user_override`); a malformed user TOML fails loud. See [docs/TOOLS.md](docs/TOOLS.md).
  - The Gemini prompt expander gained an overall **wall-clock budget** (default ~60s per call)
    on top of the lowered 20s per-attempt timeout, so sustained rate limiting can no longer
    block a generation for the full retry schedule before falling back to the original prompt.

### Deprecated

- **`expand_prompt` MCP prompt**: superseded by the `creative-director` tool, which performs the
  rewrite server-side (calls Gemini, strips banned keywords, supports domain styles, records
  provenance). The prompt still works and now carries a `[DEPRECATED]` marker in its
  client-visible description; it is slated for removal in a future major release. Use
  `gflow tools run creative-director` / `--tool` (CLI) or `gflow_list_tools` + the `tools` array
  param (MCP) instead.

## [0.21.0] — 2026-06-26

### Added

- **MCP server** (`gflow mcp run`): a [Model Context Protocol](https://modelcontextprotocol.io) server over **stdio** that exposes gflow's image / video / data operations to MCP-aware agents (Claude Desktop, Cursor, VS Code) as JSON-RPC **tools, resources, and prompts**. Point the client at `gflow mcp run` (example config in `gflow mcp run --help` and [docs/MCP.md](docs/MCP.md)). `gflow mcp setup --target <claude-desktop|cursor|vscode>` is scaffolded for future auto-configuration.
- **MCP over HTTP/SSE** (`gflow serve`): serves the same MCP server over Server-Sent Events — stream at `/sse`, POST messages to `/messages/`. Binds `127.0.0.1:8000` by default; non-loopback binds require `GFLOW_DAEMON_TOKEN`. Foundation for the forthcoming Gflow Studio Web UI and REST `/api/v1` surface.
- **Daemon & generation-queue scaffolding** (internal foundation): a FastAPI lifespan daemon, a `FlowWorker` background processor, and a SQLite-backed generation queue (`QueueRepository` + migration `0007_queue`, swept to `failed` on restart). Lays the groundwork for queued asynchronous generation; not yet wired into a user command (`gflow serve` currently runs the MCP/SSE server only).


### Fixed

- **Security — `cryptography` advisory** ([GHSA-537c-gmf6-5ccf](https://github.com/advisories/GHSA-537c-gmf6-5ccf)): bumped the locked `cryptography` from 48.0.0 to 49.0.0 (transitive dependency).

### Changed

- **CI — dependency CVE gate**: added a `pip-audit` job that audits the locked dependency set on every PR and fails on known advisories.
- **Code health**: SonarCloud cleanup sweep across the CLI, API, transport drivers, and movie/manifest layers (cognitive-complexity, duplicate-literal, and unused-argument refactors) with no behavioral change.

## [0.20.1] — 2026-06-16


### Fixed

- **Aspect ratio overrides in Agentic & Classic cohorts** ([#193](https://github.com/ffroliva/gflow-cli/issues/193)): Fixed a bug where aspect ratio settings were ignored under the pluggable `FlowUiDriver` strategies (both single and batch image generation paths).
- **`GFLOW_CLI_PREFER_CLASSIC`** (or `prefer_classic` setting): Added a configuration setting to force the classic UI driver, allowing users to bypass the Agentic UI cohort if preferred.

## [0.20.0] — 2026-06-15

### Added

- **Forced Agentic UI detection** (exit code 25): dynamically detects if the account's Flow editor page has been placed in Google Flow's new Agentic UI A/B cohort. Raises `FlowAgentUiError` and captures a diagnostic viewport screenshot (`debug_forced_agent_ui.png`) to exit cleanly and prevent CLI hangs.
- **Pluggable Flow UI driver strategy** (`FlowUiDriver`): the UI-automation transport now probes the editor DOM **per generation** (the cohort flaps per page load) and binds a `ClassicFlowUiDriver` or `AgenticFlowUiDriver`, so the two cohorts' selectors never share code. Classic generation is unchanged.
- **Agentic-cohort image generation** (validated live): when the editor is served the Agentic UI, `gflow image` drives it by encoding settings (count / aspect) into the conversational prompt directive and scraping generated assets directly from the DOM — **deduplicated by media UUID** — because the Agentic UI routes generation through a background Web Worker that defeats page-level network capture. Content-policy blocks (detected in alert/dialog regions) fail fast with `ContentPolicyError` (exit 5). Agentic **video** still raises `FlowAgentUiError` (exit 25) pending a validated scraping path.
- **`GFLOW_CLI_FORCE_AGENT_UI`** (testing/diagnostic opt-in): forces the agentic composer by clicking the in-input "Agent" toggle after entering the editor, so the agentic path can be exercised deterministically regardless of the server-assigned A/B cohort (which has no client-readable flag). Unset by default — the cohort is auto-detected per generation. See `docs/AGENT_UI_E2E.md`.

## [0.19.0] — 2026-06-12

### Added

- **Opt-in Patchright browser engine** via `GFLOW_CLI_BROWSER_ENGINE=patchright`
  (default `playwright`, unchanged). Patchright is a drop-in patched Playwright
  (Chromium) that runs page evaluations in an isolated execution context to
  avoid the `Runtime.enable` CDP leak, for stronger reCAPTCHA-Enterprise evasion
  on the **headed** path. It is **not** a headless unlock and must be installed
  separately: `pip install 'gflow-cli[patchright]'`. The default engine is
  byte-identical to before. `gflow auth status` now reports the active engine.
- `BrowserEngineUnavailableError` (exit code 24): selecting `patchright` without
  the package installed now fails with a clear `pip install patchright`
  remediation hint instead of a raw `ImportError` hashed to a generic exit 1.


### Fixed

- An invalid `GFLOW_CLI_*` enum value (e.g. a typo'd `GFLOW_CLI_BROWSER_ENGINE`,
  `GFLOW_CLI_PROVIDER`, or `GFLOW_CLI_LOG_LEVEL`) now fails with a clean
  configuration error and **exit code 11** naming the offending variable, instead
  of leaking a raw pydantic `ValidationError` traceback and exiting 1.

## [0.18.0] — 2026-06-12

### Added

- `UiSelectorDriftError` (exit code 23): UI-automation selector-probe failures — e.g. the
  mode-switch `crop_*` trigger missing from the Flow editor (issue #183) — now raise a typed
  error carrying the probe name, the debug-screenshot path, and a remediation hint, instead
  of an opaque "Unexpected error" (exit 1) whose message was hashed away in logs. Converted
  probes: mode-switch trigger, Image/Video mode tabs, and video sub-mode tabs, in both the
  image and video transports.


### Fixed

- `gflow image` commands (`t2i` / `i2i` / `upscale` / `upload`) now plumb their output
  directory into the API client, so debug screenshots are actually captured on
  UI-automation failures. Previously the transport's screenshot directory was never set on
  the image path and drift errors reported `Screenshot: None` even with `--verbose`.

## [0.17.0] — 2026-06-12

### Added

- Added `verify_flow_profile` in `gflow_cli.auth.verification` using `browser_cookie3` and `httpx` to verify sessions directly from the Chrome cookie store (fast path), with a marker-gated Playwright fallback for encrypted/locked stores. `RealChromeStrategy` now writes the Chrome marker before verification (the fallback reads it) and, on failure, rolls back only a speculative write — a marker that legitimately pre-existed (a previously-verified chrome profile) survives a transient probe failure, and an interrupted verification never leaves an unverified profile claiming the chrome strategy. Cookie extraction is centralised in the new `gflow_cli.auth.cookies` module.


### Fixed

- `gflow_cli.auth.cookies._get_chrome_cookies3` now catches `RuntimeError` (Windows DPAPI failure — `RuntimeError('Failed to decrypt the cipher text with DPAPI')`) in addition to `browser_cookie3.BrowserCookieError`, and re-raises both as `PermissionError` so the Playwright fallback is triggered instead of propagating an unhandled exception.
- `verify_flow_profile` now retries transient HTTP failures (429/503/504) and network errors up to `_MAX_ATTEMPTS` times with exponential backoff, matching the retry behaviour of the existing Playwright-based `verify_flow_session`.

### Changed

- Entity-attach `WireFormatError` failures (exit 7) now carry a remediation hint pointing at Flow's new full-page media-library UI rollout ([#174](https://github.com/ffroliva/gflow-cli/issues/174)) — affected accounts can stage entities via the include action but the submit never carries `referenceEntities`; the error now explains how to tell which UI an account has and where to follow the fix, instead of the generic file-a-bug hint. Both backstops also emit an `entity_attach_context` discovery field (`video`/`image`) for drift telemetry. New KNOWN_ISSUES entry documents the rollout

## [0.16.0] — 2026-06-12


### Fixed

- **`--reference-entity` no longer fails on non-Portuguese Flow accounts** ([#170](https://github.com/ffroliva/gflow-cli/issues/170)) — the resource-picker include selectors hardcoded the pt-BR caption "Incluir no comando"; they are now locale-free tier cascades (context-menu `add`-ligature anchor + pt/ru/en text fallback), fixing `gflow image t2i --reference-entity`, movie R2V entity attach, and Vozes voice attach for every account language. Failures are now typed (`TransportTimeoutError`, exit 9) with a locale-neutral remediation hint, the matched selector tier is logged (`include_selector_tier`) for drift telemetry, and a new image-side submit backstop raises `WireFormatError` (exit 7) if a staged character never reaches the wire instead of silently returning a text-only generation. Thanks @papushin7987 for the live-verified report

### Added

- **`gflow image upscale <mediaId> --scale 2k|4k`** — upscale a platform-generated image to 2K or 4K (Flow's download-menu 1K/2K/4K options) and save it locally; credit-free. The owning project is resolved from the local catalog (or pass `--project` for images gflow didn't record). 4K requires a Flow Ultra subscription — a non-Ultra 4K request fails fast with exit code 22 (`UpscaleUnavailableError`) rather than a generic 403. Reverse-engineered wire documented in [docs/IMAGE_UPSCALE_RECON.md](docs/IMAGE_UPSCALE_RECON.md); live-verified end-to-end (issue #171)

## [0.15.1] — 2026-06-10

### Changed

- Added `--disable-dev-shm-usage` to Chrome launch args in both `FlowApiClient._persistent_context_kwargs()` and `UiAutomationTransport.setup()` — prevents OOM in Docker containers with the default 64 MB `/dev/shm` allocation; no effect on developer machines with adequate shared memory
- README Stats badges hardened against shields.io outages — GitHub-stat badges now pass `cacheSeconds=3600` (mitigates shields.io's shared GitHub token-pool exhaustion, the "Unable to select next GitHub token from pool" error) and the PyPI downloads badge moved from `img.shields.io/pypi/dm` to pepy.tech (pypistats rate-limits shields.io upstream)

### Added

- `scripts/diag/` directory — documented home for investigation scripts that require a live authenticated profile; includes `memory_profile.py` (Chrome process-tree RSS profiler for issue #155), `capture_flow_traffic.py`, and `recaptcha_mint.py` (both moved from `scripts/` root via git mv, history preserved)


### Fixed

- Video status poll now raises `AuthExpiredError` (exit 3) immediately on HTTP 401 from `batchCheckAsyncVideoGenerationStatus` instead of silently timing out after 600 s with a bare `TimeoutError` (exit 1) — session expiry is now detected mid-workflow, not only at login time (issue #156)

## [0.15.0] — 2026-06-09

### Added

- **`gflow image` can reference locked CHARACTER entities** for character-consistent
  stills. New `--reference-entity <id>` (repeatable) + `--reference-entity-name` on
  `image t2i` / `i2i`, plus `--project <id>` to generate in an EXISTING project (where
  the entities live) instead of a throwaway scratch project. Entities attach through
  the editor's **Personagens picker** and ride the submit as `referenceEntities`
  (confirmed against the live API); `_build_batch_generate_images_body` serializes them
  so non-UI/headless transports get parity too. Entities count toward the per-model
  reference cap. `--project` / `--reference-entity` are single-prompt only; for a pure
  character reference use `t2i` (`i2i` still needs a `--ref`). See `docs/USAGE.md` →
  "Character-consistent images (entity references)".


### Fixed

- `--project` no longer overwrites an existing project's stored title/source in the
  local history DB (the recorder preserves the curated title for non-created projects).

### Security

- `--project` / `--reference-entity` ids are validated at the CLI boundary
  (`[A-Za-z0-9-]{1,128}`), closing an unvalidated `page.goto` navigation path
  (`project_editor_url` lacked the allowlist its sibling routes enforce) and a
  CSS-selector injection vector (`data-tile-id='fe_id_<id>'`). The request-body debug
  logger elides large reference-field values so Flow-built image bytes can't leak into
  logs.

### Internal

- Bump dev/CI `ruff` to `0.15.16` (both the `dev` extra and the `dependency-groups`
  pin; supersedes Dependabot PR #165, which updated only the soft `>=` extra and not
  the hard `==` group pin CI actually uses). `ruff check` / `format --check` clean.

## [0.14.0] — 2026-06-07

### Added

- **`gflow movie` — multi-scene, character-consistent video generation.** A TOML
  manifest (`gflow movie template` / `gflow movie run`) drives a sequence of clips
  that reuse a single Flow CHARACTER entity (reference-to-video) so the same face
  and voice carry across every scene. Generate-only by default; `--stitch`
  produces an ffmpeg preview concat; runs are crash-resumable via the sibling
  `<manifest>-state.json`; a versioned handoff manifest is written for downstream
  composition (e.g. Remotion). Deterministic prompt assembly (`composition.py`),
  scene = clip.
- **`docs/MOVIE.md`** — manifest format, the run lifecycle (the headed browser is
  required through generate → poll → download), the character-entity attach
  mechanism, and the best-effort consistency model.
- Dev utilities: `scripts/dev/make_project.py` (create a Flow project) and
  `scripts/dev/patch_character.py` (rename / set voice + personality on an entity).


### Fixed

- **R2V character reuse now actually rides the wire.** The entity is attached via
  the resource picker's **Personagens tab → right-click → "Incluir no comando"**
  (which stages `referenceEntities`; a left-click on the Tudo tile only stages the
  thumbnail as a `referenceImage`). The submit backstop now reads the response's
  real `media[].mediaMetadata.requestData.videoGenerationRequestData.videoGenerationEntityInputs`
  path instead of the request-shape `requests[].referenceEntities` — which had
  false-rejected every successful entity generation. `omni-flash` R2V verified to
  carry the entity.
- Cleared pre-existing type/test debt: `pyright src` is clean again (the missing
  `project_id` parameter was added to the `VideoCapableTransport` protocol and the
  `_enter_editor` type stub); regenerated `uv.lock` (jsonschema dev dependency).

## [0.13.0] — 2026-06-04

### Added

- **`gflow character rm` — delete a Character entity (#150).**
  `gflow character rm --project <id> (--id <entityId> | --name <name>) [-y/--yes] [--json]`
  deletes a Character via `POST flow:batchDeleteAssets` (Bearer; **FREE** — no
  reCAPTCHA, no credit). Resolves by id or exact name (ambiguous name exits
  **11**); prompts for confirmation unless `--yes`/`--json`.

- **In-project governance enforcement (advisory-first).** Made the AI-driven
  development flow followable and partly machine-enforced in-repo, modeled on the
  reference AI-DLC governance orchestrator's advisory-by-default behavior:
  ruff `T20` now bans raw `print()` in `src/`; an advisory branch-naming check and a
  non-blocking materiality + traceability classifier (`scripts/ci/check_materiality.py`
  + `governance-advisory.yml`) recommend `/gflow:predict` + council review when
  sensitive paths (`auth/`, `api/transports/`, `api/client.py`, `_sapisidhash.py`,
  `data/`, `recaptcha`) are touched, without ever blocking a merge. A
  history-replay backtest (`scripts/dev/materiality_backtest.py`) calibrates the
  gate — it measured a 1.1% false-positive rate (vs. a 20-30% estimate) and
  raised fix-coverage from 61% to 74% by surfacing auth-token plumbing that lived
  outside `auth/`. The backtest is a first-class, repeatable artifact (`--json`
  mode, a monthly `governance-benchmark.yml` dashboard job) fully documented in
  [`docs/GOVERNANCE_BENCHMARK.md`](docs/GOVERNANCE_BENCHMARK.md); the gate itself is
  described in
  [`docs/AGENT_GUIDE.md` § Governance & Enforcement](docs/AGENT_GUIDE.md#governance--enforcement).

### Changed

- **`gflow video i2v` frame flags aligned with Flow UI terminology (#122).**
  `--initial-frame FILE` is the new canonical flag for the start image (matches
  Flow's "initial frame" label). `--end-frame FILE` replaces `--end-image` as the
  canonical end-frame flag. `--end-image` is kept as a **deprecated alias** (emits
  `DeprecationWarning`; will be removed in a future minor release). The positional
  `IMAGE` argument remains supported for back-compatibility.


### Fixed

- **Character editor 404 on non-English locales (#153).** `gflow character`'s
  editor URL interpolated the locale verbatim, so the genuine default BCP-47
  `en-US` produced `/fx/en-US/…`, which 404s the Flow character editor (only the
  short primary subtag is a valid `/fx/<seg>/` segment). `character_editor_url`
  now normalizes a BCP-47 tag to its lower-cased short segment (`en-US → en`,
  `pt-BR → pt`), so the tool stays language-agnostic with the real default
  locale.

## [0.12.0] — 2026-06-03


### Fixed

- **Create-project generation failing when Flow opens the Agent _chat panel_.**
  A follow-up to the earlier Agent-pill fix: Flow now also surfaces Agent mode as
  a docked chat side-panel ("Untitled session") on some project opens, and while
  it is up the in-composer Agent pill is absent from the DOM — so the pill-only
  recovery could not find anything to click and generation still failed with
  "mode-switch dropdown trigger not found". `_exit_agent_mode` now handles both
  Agent shapes in one pass: it dismisses the chat panel (locale-stable, aria-free
  structural close anchor) which reveals the pill, then turns the pill off,
  looping until the media panel re-mounts. Keyed on the outcome (`crop_*` is
  back), so it covers pill-only, panel-only, and panel-then-pill without assuming
  which control is present.

### Added

- **`gflow character` command group — reusable Flow Character entities (#145).**
  Mint a project-scoped **Character** (a named subject with reference images, an
  optional voice, and an optional personality) so the same subject appears
  consistently across generations:
  - `gflow character create --project <pid> --name <name> --face-prompt "…"
    [--body-prompt "…"] [--voice <Name>] [--personality "…"]
    [--model nano2|nanopro]` — two-step generation: a **face** reference (slot 0),
    then a self-contained **front/side/back triptych body** (slot 1) seeded by the
    generated face. gflow injects its own triptych instruction, so one body
    generation yields all three angles. Characters have **no aspect-ratio
    control** and exactly two models — `nano2` (Nano Banana 2, default) and
    `nanopro` (Nano Banana Pro). Generated images are **downloaded** to local (or
    cloud) storage; the signed `fifeUrl` is used only at download and never
    persisted.
  - `gflow character list --project <pid>` — list every Character in a project.
  - `gflow character show --project <pid> (--id <entityId> | --name <name>)` —
    show one Character; an ambiguous `--name` exits 11.
  - `gflow character voices` — list the 29-name Gemini voice catalog
    (name / description / sample-url); `--voice` is validated case-insensitively.

  The credited generation rides Flow's own page JS in the character editor
  (Option B, UI passive-capture — a self-assembled direct POST is reCAPTCHA-403
  walled); the structural calls (createEntity, workflow/entity PATCH,
  projectInitialData) are credit-free REST. Creation runs as a
  **persist-before-spend, crash-recoverable saga**: the `entityId` and each
  completed slot are recorded before/as credits are spent, so a crashed run
  resumes without orphaning a paid generation or double-charging. Live-verified
  end-to-end on 2026-06-02 (face + triptych body, both bound, downloaded, read
  back). See [docs/CHARACTER.md](docs/CHARACTER.md).

- **`gflow video chain` — last-frame I2V chaining.** Render a JSONL manifest of
  *links* into one continuous sequence: link 0 is a text-to-video generation,
  and every later link is an image-to-video generation **seeded by the extracted
  last frame of the previous clip**, giving visual continuity with no
  server-side stitching. Each link is a sequential paid Veo generation (**one
  credit per link**); a cost-confirmation gate (`-y`/`--yes` to skip),
  `--dry-run` plan preview, `--max-links` cap (exit 11), and
  `--resume-from <chain-id>` (skips already-paid links, no re-billing) make the
  spend explicit and recoverable. Per-link wire-route checking aborts loudly if
  Flow drops the seed frame and routes an i2v link to the text-only endpoint
  (issue #125), so a misroute can never be reported as a successful chain.
  Only the Veo 3.1 models (`veo-lite`/`veo-fast`/`veo-quality`/`veo-lite-lp`)
  are accepted; `omni-flash` is rejected. Chain links are recorded locally
  (SQLite migration `0005`) to drive `--resume-from`. The frame extractor uses
  PyAV via a new optional **`[chain]`** extra (`pip install 'gflow-cli[chain]'`)
  — no system ffmpeg required. Each link is saved as its own mp4; concatenating
  the clips into one file is a separate step — use `gflow scene` (auto-concat is
  deferred, see [KNOWN_ISSUES.md](KNOWN_ISSUES.md)).

- **`gflow scene` command group (Add Clip / Scenes).** Compose ordered,
  trimmable video clips into a Flow **Scene** over the credit-free aisandbox
  REST surface (no reCAPTCHA, no credits):
  - `gflow scene create --project <pid> <workflowId>[:<start>-<end>] [...]` —
    compose a scene from one or more existing clips (repeat an id to duplicate;
    optional per-clip trim in seconds).
  - `gflow scene show --scene <sid> --project <pid>` — read back a scene's clip
    order and trims.
  - `gflow scene create … --output extended.mp4` — render the composed scene
    into a single **extended video** via Flow's server-side concatenation
    (`runVideoFxConcatenation`) — credit-free, no reCAPTCHA, **no ffmpeg**. The
    combined MP4 is fetched inline and written locally (or to the configured
    cloud `storage_uri`). `--force` overwrites an existing output.

  Scene compositions are recorded locally (SQLite migration `0003`) — including
  each clip's media id + trims, and the rendered extended-video path (migration
  `0004`) — so a compose survives a later render failure and the output is
  discoverable for recovery. The append-to-existing-scene verb (`add-clip`) is
  deferred — see the project backlog.

## [0.11.0] — 2026-05-31

### Changed

- **`gflow video i2v` default model is now `veo-lite`** (was: inherit Flow's
  last-used model, which was typically `omni-flash`). The Veo 3.1 family is
  the only model line that supports i2v interpolation; `omni-flash` is now
  rejected for any i2v invocation (start-only or start+end) and has been
  removed from the i2v `--model` choices. Because `--duration 10` is
  omni-flash-only, the i2v `--duration` choices are now `[4|6|8]`. `omni-flash`
  (and `--duration 10`) remain valid for `gflow video t2v` and `gflow video r2v`.
  See issue #125.


### Fixed

- **`gflow video i2v` silently produced text-to-video output, ignoring the
  start/end frames (issue #125).** When the model was `omni-flash` (Flow's
  last-used default in most sessions), Flow's frontend dropped the bound
  start/end frame references at submit time and routed every call to
  `batchAsyncGenerateVideoText` with `image_inputs: null` — charging a credit
  for a pure text-to-video generation that had no visual relationship to the
  supplied frames. **Every i2v paid run on v0.10.0 before this fix produced
  T2V output regardless of the start/end frames.** Fix: `omni-flash` is
  dropped from the i2v `--model` choices and the i2v default is now `veo-lite`;
  a defense-in-depth transport guard raises `ModelModeIncompatibilityError`
  (exit code 17) for direct `FlowApiClient` callers that bypass the CLI.

- **`gflow video i2v` could still route to T2V even with a valid Veo model,
  because the model-picker option `Veo 3.1 - Lite` was never selected (issue
  #125, second path).** The picker selector was an exact-match
  (`:text-is('volume_upVeo 3.1 - Lite')`) that hardcoded a Material Symbols
  icon-ligature prefix; when it missed, `_select_video_model` warned and
  continued, leaving Flow on `omni-flash` → the frames were dropped to T2V.
  Fixes: (1) the selector is now a robust substring match
  (`:has-text('Veo 3.1 - Lite'):not(:has-text('[Lower Priority]'))`); (2) for
  i2v, a model-select miss is now FATAL — `_select_video_model(required=True)`
  retries the picker then raises `VideoModelSelectionError` (exit code 18)
  *before* any frame attach or submit, spending no credit; (3) a post-submit
  backstop raises `WireFormatError` if an i2v request is still observed routing
  to the T2V endpoint, so a "successful" T2V is never reported as i2v.

- **Create-project generation failing when Flow's "Agent" composer mode is active.**
  Flow's newer editor adds an Agent toggle next to the prompt box; when it is on,
  the media-generation panel (the `crop_*` settings trigger, Image/Video mode
  tablist, and count/model controls) is removed from the DOM, so the UI-automation
  transport raised "mode-switch dropdown trigger not found". `_switch_to_image_mode`
  and `_switch_to_video_mode` now call `_exit_agent_mode()` first, which re-mounts
  the panel by clicking the toggle off. Detection is locale-invariant and uses no
  UI text and no `aria-` attribute (`button:has(span.content)` plus the absence of
  the locale-stable `crop_*` trigger), so it works in every Flow UI language.

- **`gflow image t2i` / `i2i` model selection hardened for non-English Flow UIs
  (issue #94).** `IMAGE_MODEL_OPTION_SELECTORS` is now a selector *cascade*
  (consistent with every other selector group) instead of a single exact-match
  string, so `_select_image_model` no longer silently fails to select the
  requested model when Flow's menu markup shifts. The redundant `--lang=en-US`
  Chromium launch arg was removed — Flow's branded model names ("Nano Banana 2",
  "Nano Banana Pro", "Imagen 4") are not localised and `FLOW_URL`'s `?hl=en`
  already locks the SPA to English, so the override was a no-op.

## [0.10.0] — 2026-05-29


### Fixed

- **Image and video counts leaking across profiles in `gflow data list projects` (issue #113).**
  Fixed an issue where project media counts were combined if two different profiles
  happened to share the same `flow_project_id`. The counts in `_LIST_PROJECTS_SQL`
  are now strictly scoped to the active `profile_name`.

- **List queries fan-out when multiple operations claim an asset (issue #111).**
  Fixed a bug in `gflow data list images` and `gflow data list videos` where 
  assets would be duplicated or have non-deterministic prompts if multiple 
  operations (e.g., retries) claimed the same output asset. The SQL queries 
  now use a deterministic subquery grouping by `asset_id` to ensure exactly 
  one-to-one cardinality.

### Added

- **Google account identity persisted to every profile (`issue #92`).** Both
  auth strategies (`real_chrome`, `internal_chromium`) now write a
  `.gflow_account` file to the profile directory immediately after the session
  is verified, durably associating the signed-in email with the profile on disk.
  `ProfileMeta` gains a `google_account: str | None` field populated by
  `profile_store.list_profiles()` from that file. `gflow auth list` (table and
  `--json`) now includes a **Google account** column so every profile is
  immediately identifiable — no more opaque `default` entries.  The `--json`
  output gains the `google_account` key for programmatic callers.  Closes #92.

- **Auto-rename of the first-run `default` profile to email local-part.** When
  `gflow auth login` creates the first profile and no `--profile` flag was given,
  the profile is named `default` as a placeholder. After the session is verified
  and the email is known, `auth login` automatically renames `profile_default` to
  `profile_<email-local-part>` (e.g. `profile_ffroliva`) and updates
  `config.toml`'s `default_profile` pointer atomically. The local-part is
  sanitized to a filesystem-safe name (characters outside letters, digits, `-`,
  and `_` become `-`), so `flavio.oliva@gmail.com` → `profile_flavio-oliva` and
  `user+flow@gmail.com` → `profile_user-flow`. Existing `default`
  profiles that were created before this change continue to work; they gain the
  email column the next time `gflow auth login` is run against them.  Closes #92.

- **`profile_store.rename_profile(old_name, new_name)`** — reusable primitive that
  renames a profile directory and updates `config.toml` when the renamed profile
  was the default. Raises `FileNotFoundError` / `FileExistsError` on invalid input.

- **Zero-credit smoke test for profile account persistence
  (`tests/smoke/test_profile_account_smoke.py`).** Three smoke tests that verify
  the full observable chain — account file present + readable, `list_profiles()`
  surfaces `google_account`, `gflow auth list --json` includes the field — against
  a real authenticated profile. No image or video generation; zero Flow credits.
  Backfills the `.gflow_account` file for profiles created before the fix so the
  tests work on existing sessions. Opt-in via
  `GFLOW_CLI_E2E_PROFILE=<name> pytest -m smoke tests/smoke/test_profile_account_smoke.py`.

- **Aggregated asset view in `gflow data list images/videos`.** By default,
  listing images or videos now returns one row per asset (Flow media ID),
  collapsing multiple local copies into a single entry with a `COPIES` count
  and the path of the latest copy. This prevents duplicate rows when
  re-downloading the same media to different directories. The `copy_count`
  is also exposed in JSONL output.
- **`--all-copies` flag on `gflow data list images/videos`.** Restores the
  previous behavior of showing every local file as a separate row.
- **`gflow data prune` command.** New maintenance utility to remove stale
  `local_files` database entries for local paths that no longer exist on
  disk. Only targets local files (ignores cloud-stored assets). Supports
  `--dry-run` to preview deletions and `--profile` to limit the scan.
- **External storage documentation for S3, MinIO, and Google Cloud Storage.**
  Adds `docs/EXTERNAL_STORAGE.md`, cross-links it from the README, docs index,
  configuration, data-layer, usage, security, and user-guide docs, and clarifies
  that `GFLOW_CLI_STORAGE_URI` is a cloud-only output mode rather than
  local-plus-cloud dual-write.
- **`--json` flag on `gflow video t2v`, `gflow video i2v`, and `gflow video r2v`.**
  Emits the `VideoResult` (status / command / media_id / generation_status /
  succeeded / local_path / failure_reasons / error_message) plus the request
  echo (model / mode / aspect / duration / count / seed) as a single JSON
  object on stdout. A failed generation still emits its JSON payload and
  then exits 1. The data-layer recorder
  (`record_started_video` / `record_completed_video`) fires regardless of
  `--json` so audit history is independent of the output channel. E2e
  coverage for `--json` shape across image / video / auth / models lives at
  `tests/e2e/test_json_output_e2e.py`.
- **`--json` flag on `gflow image t2i` and `gflow image i2i`.** Emits the
  complete `GeneratedImage` result (every field — `media_name`,
  `workflow_id`, `seed`, `prompt`, `model_name_type`, `aspect_ratio`,
  `dimensions`, `fife_url`, `is_signed_url`) plus the on-disk `local_path`
  as a single JSON object on stdout. A worker keys `images[0].seed` for
  refine-regen seed continuity. Single-prompt only (`--json` rejects
  multi-prompt batch with a Click usage error); progress chatter is
  suppressed so stdout is pure JSON. `ref_count` surfaces only on i2i.
- **`gflow models` catalog command.** New top-level command that enumerates
  the image and video model catalog as a Rich table (default) or as a single
  JSON object (`--json`). Per-model: `name`, CLI aliases (filtered to what
  the generation command's `--model` Choice actually accepts), `ref_cap`,
  `default` (image), `max_duration` (video). Built from the
  `Model` / `VideoModel` enums + their alias maps so the catalog can never
  drift from what the generation commands accept. A UI populating its model
  picker from `gflow models --json` is guaranteed to pass any selected alias
  back to `--model`.
- **`gflow_cli.json_output` module + `--json` error path on
  `run_with_handlers`.** Pure builders for image/video result payloads and
  RFC 9457 problem-details errors (plus a `retryable` flag worker schedulers
  key their retry-vs-absorb decision off — WAF / rate-limit / network /
  timeout). When `as_json=True`, errors emit a parseable JSON payload on
  stdout with the same exit code as the Rich path; the observability event
  still fires.
- **`--json` flag on `gflow auth list`.** Emits the profile inventory as a JSON
  array (`name` / `is_default` / `cookies_present` / `profile_dir` /
  `last_used_at`) on stdout so a programmatic caller (e.g. a worker discovering
  authenticated profiles) can `json.loads(stdout)` instead of scraping the
  Rich table.
- **Per-model r2v reference-image cap rebuilt as a data table.** Replaces the
  prior pair of constants (`OMNI_REFERENCE_CAP=7`, `VEO_REFERENCE_CAP=3`) with
  a `VideoModel -> int` mapping consulted by
  `gflow_cli.api.video.reference_cap_for(model)`. New entries:
  `veo_3_1_lite_lower_priority=3` (was implicitly covered by the veo branch),
  and `veo_3_1_quality=0` — Veo 3.1 Quality does NOT support
  Ingredients/References to Video at all per Google Flow's official support
  page; passing it to r2v raises a clear `does not support R2V
  (reference-to-video)` error rather than letting the request fail at the
  wire. CLI guard added on `gflow video r2v` (`click.UsageError`, exit 2)
  mirroring the i2i pattern so over-cap and quality+r2v fail before any
  profile/network work. E2e tripwire at
  `tests/e2e/test_video_r2v_ref_cap_e2e.py` asserts Flow actually consumes
  all `cap` refs at the at-cap boundary.
- **Per-model i2i reference-image cap.** Flow silently keeps only the first N
  reference images when an i2i request attaches more than the model accepts,
  so a caller could believe every ref was used. `gflow_cli.api.image.reference_cap_for(model)`
  exposes the live-observed per-model cap: NARWHAL (Nano Banana 2) and GEM_PIX_2
  (Nano Pro) accept 10, IMAGEN_3_5 (Imagen 4) accepts 3. Enforced as a domain
  invariant in `GenerateImageRequest.__post_init__` and at the CLI boundary in
  `gflow image i2i` (clean `click.UsageError` / exit 2 before any
  profile/network work). Mirrors the existing video r2v cap pattern. E2e
  tripwire at `tests/e2e/test_image_i2i_ref_cap_e2e.py` asserts Flow actually
  consumes all `cap` refs (one `reference_attached` event per ref) so a future
  silent truncation on the Flow side fails the test.
- **Layered e2e test strategy with cost sub-markers.** The single `e2e` marker is
  now augmented by cost sub-markers (`e2e_auth`, `e2e_image`, `e2e_video`,
  `e2e_batch`, `e2e_data`, `smoke`) so callers can run only the tier they can
  afford (zero-credit auth checks, single-credit image smoke, etc.). See
  `docs/E2E_TESTING.md` for the full reference.
- `tests/e2e/conftest.py` — shared `e2e_profile_dir`, `e2e_nosession_profile`,
  and `e2e_env` fixtures replace duplicated inline helpers in individual test files.
- `tests/api/transports/test_transport_timeout.py` — extracted from e2e as a
  pure-mock integration test; also fixes `Path("/dev/null")` → `Path(os.devnull)`
  for Windows portability.
- `tests/test_marker_registry.py` — invariant checks that every e2e test carries a
  cost sub-marker, and self-tests for the auto-marker conftest hook.
- `docs/E2E_TESTING.md` — comprehensive e2e strategy and layer reference document.


### Fixed

- Structlog logs are now routed to stderr (via
  `PrintLoggerFactory(file=sys.stderr)`) instead of stdout. Previously every
  CLI event leaked onto stdout, which broke the `--json` contract for
  programmatic callers — `json.loads(stdout)` failed because the JSON
  payload was preceded by event-log lines. Logs are diagnostics; stdout is
  data. No-op for human users (terminals still show logs the same way).

### Changed

- `gflow data media` now labels cloud-backed asset records as `cloud_uri_N`
  while keeping local assets under the existing `local_path_N` labels.
- `gflow_cli.api.video` no longer exposes the standalone `OMNI_REFERENCE_CAP` /
  `VEO_REFERENCE_CAP` constants. Callers that need a per-model R2V cap should
  use `reference_cap_for(model)` (which returns `0` for `VEO_3_1_QUALITY` —
  R2V is unsupported there). `MAX_REFERENCE_IMAGES` (= 7) is unchanged and
  still the absolute ceiling used when the model is unknown.
- `GFLOW_CLI_E2E_RUN_VIDEO` default flipped from `"1"` to `"0"`. The Veo step in
  `test_data_layer_e2e.py` is now **opt-in**: set `GFLOW_CLI_E2E_RUN_VIDEO=1` to
  include it. This prevents accidental Veo credit burns on unattended CI runs.
- `pytest` `addopts` now excludes `smoke` in addition to `e2e` and `live`:
  `not e2e and not live and not smoke`. Bare `pytest` never launches a live
  browser session.
- Auto-marker conftest hook uses `item.path.parts` instead of a slash-delimited
  string substring, fixing Windows backslash path compatibility.

## [0.9.1] — 2026-05-27

> **Locale and catalog patch release.** Hardens the headed-browser UI
> automation path for localized Flow profiles, fixes I2V start/end-frame
> attachment on non-English Chrome/Flow sessions, and repairs first-run catalog
> edge cases found after v0.9.0.

### Changed

- `NEW_PROJECT_SELECTORS` now covers all 14 supported locales (EN / PT / ES /
  FR / DE / IT / NL / JA / ZH / KO / PL / RU / TR / ID) and leads with
  locale-stable icon selectors (`add_2` Material Symbols ligature on
  `<button>` and on `[role='button']` ARIA-role variants, plus an anchored
  `^\+\s+\S+$` regex for `+ <word>` host elements). English-only
  `[aria-label*='New project']` and `[aria-label*='Project']` ARIA fallbacks
  removed.
  `SUBMIT_BUTTON_SELECTORS` drops its English-only
  `button[aria-label*="Create"]` fallback — the preceding `arrow_forward` icon
  entries already cover this button in every locale. Both selector tuples are
  now fully locale-invariant for non-English Chrome profiles. The `--lang=en-US`
  Chromium launch arg is retained only to stabilise `IMAGE_MODEL_OPTION_SELECTORS`
  (English product names); its removal is tracked as issue #24 Phase 5 (#94).


### Fixed

- Bare `pytest` no longer collects live/e2e tests by default. The project-wide
  pytest `addopts` now excludes `e2e` and `live` unless callers explicitly pass
  a different `-m` expression, and `tests/smoke/test_real_flow.py` is marked
  with both markers so marker-filtered local and CI runs cannot accidentally
  launch a real Flow browser session.
- Browser-manager PID tests no longer call the real `os.kill` while pretending
  to be on POSIX from a Windows runner. The POSIX liveness branches are now
  tested with mocked `os.kill`, avoiding hard interpreter/session exits during
  local test runs.

- Running the pytest suite no longer writes fixture rows into the developer's
  production `gflow.db` catalog. A new autouse `_isolate_settings` fixture in
  `tests/conftest.py` redirects `GFLOW_CLI_HOME` and `GFLOW_CLI_DB_PATH` to
  per-test `tmp_path` dirs and clears the `get_settings()` `lru_cache` before
  and after every test, preventing the cached singleton from ever resolving to
  a `platformdirs` production path. Closes
  [#86](https://github.com/ffroliva/gflow-cli/issues/86).

- `gflow video i2v` no longer silently breaks on non-English Chrome profiles.
  PR #70's structural-first `_attach_frame` cascade matched **zero** real
  slots — its anchor selector assumed the `swap_horiz` icon used class
  `google-symbols` (it uses `material-icons`) and the slots were `<button>`
  (they're `<div type="button">`). Production I2V therefore relied on the
  English-text fallback, which silently misses on any non-EN profile (pt-BR
  shows `Inicial`/`Final`, DE shows `Anfang`/`Ende`, etc.). Replaced
  `FRAME_SLOTS_STRUCT` with the locale-free pattern
  `div[type='button'][aria-haspopup='dialog']` and added a `.first`-of-remaining
  fallback for the End-frame case (after Start is attached, only one slot
  matches and the prior `.nth(slot_index)` went out-of-bounds). Live-verified
  with `tests/e2e/test_transports_e2e.py::test_e2e_i2v_start_end_frame_attach`
  on `ffroliva` + `GFLOW_CLI_LOCALE=de-DE` (Chrome rendered pt-BR; both
  non-EN). Closes [#63](https://github.com/ffroliva/gflow-cli/issues/63).

### Changed

- `gflow data media <id>` now searches across **all** profiles by default,
  matching the cross-profile default of `gflow data list`. Pass
  `--profile NAME` to disambiguate the rare case where the same Flow
  media ID exists under multiple profiles (the command refuses to
  guess and prints the list of candidate profiles, each annotated with
  its `kind`). Closes
  [#87](https://github.com/ffroliva/gflow-cli/issues/87).


### Fixed

- `gflow data list` no longer crashes with `no such table: assets` on a
  missing or freshly-created catalog DB. The query path now routes through
  `DataStore.open`, which applies schema migrations on first connect —
  first-time users and anyone recovering from a wiped DB get an empty
  table and exit 0 instead of a `DataStoreError`. Closes
  [#88](https://github.com/ffroliva/gflow-cli/issues/88).
- `gflow auth list` no longer crashes with `UnicodeEncodeError` on Windows
  consoles whose code page cannot encode the default-profile marker `●`
  (cp1252 in PowerShell / cmd by default). The renderer now picks a glyph
  safe for the active `sys.stdout.encoding` — `●` on UTF-8, ASCII `*` on
  cp1252 / ascii / latin-1 / unknown. Closes [#82](https://github.com/ffroliva/gflow-cli/issues/82).

### Documentation

- `PLAN.md` refreshed to reflect develop state through v0.9.0 — marks Phase 6
  (data layer) shipped via PR #58 + #78 + #81, Phase 7 Issue #24 Phase 2
  shipped via PR #70, Phase B I2V/R2V shipped via PR #48, and resolves the
  duplicate Phase 7 numbering (pluggable storage renumbered to Phase 8).

## [0.9.0] — 2026-05-25

> **Maturity & Visibility release.** Surfaces the SQLite catalog (PR #52/#58)
> via a read-only `gflow data list {projects,images,videos,profiles}` CLI,
> publishes `ROADMAP.md`, and ships the locale-agnostic media-dialog
> selectors that unblock non-English Chrome profiles. Plus the previously-
> unreleased video model picker, i2v/r2v, and the I2I ref-attach + model-
> select fixes. Sponsorship wiring will land in a follow-up patch release
> once GitHub Sponsors / Buy Me a Coffee accounts are fully provisioned.

### Added

- `gflow data list {projects,images,videos,profiles}` — read-only catalog
  query CLI over the local SQLite data layer. Flags: `--limit` (1..1000,
  default 20), `--offset` (≥0, default 0), `--profile NAME`, `--json`.
  Rich table on TTY, JSONL on pipe or `--json`. Default sort: newest first.
  `DataStoreError` family maps to exit code 16. See
  [`docs/DATA_LAYER.md § Querying the data layer`](docs/DATA_LAYER.md#querying-the-data-layer).
- `ROADMAP.md` at repo root — themed milestones from v0.9 through v1.0 (no
  dates).
- `gflow video t2v` model picker: `--model` (`omni-flash` | `veo-lite` |
  `veo-fast` | `veo-quality` | `veo-lite-lp`), `--duration` (`4`/`6`/`8`, plus
  `10` for `omni-flash` only), and `--count` (1–4). Driven via the editor's
  generation-settings panel; live-verified against a Pro/Ultra profile.
- `gflow video i2v <image> "<prompt>"` — image-to-video with a start frame and
  an optional `--end-image` (interpolation). Fires
  `batchAsyncGenerateVideoStartImage` / `…StartAndEndImage`.
- `gflow video r2v "<prompt>" --ref <img> [--ref …]` — reference-to-video
  (Flow "ingredients"). Model-aware reference cap (omni_flash ≤7, veo_3_1_* ≤3)
  enforced in the request DTO; the transport stops gracefully if Flow hides the
  add-media button at the cap. Fires `batchAsyncGenerateVideoReferenceImages`.
- `GFLOW_CLI_LOCALE` env var — overrides Playwright's launch `locale=` parameter
  (default: `en-US`). Controls `Accept-Language` only; Chrome's UI language is
  still forced to en-US via `--lang=en-US`. Prep for issue #24 (locale-agnostic
  selectors); live-verified end-to-end with `GFLOW_CLI_LOCALE=pt-BR` against a
  Pro/Ultra account. See `docs/CONFIGURATION.md § GFLOW_CLI_LOCALE`.
- **Local data layer** — `gflow-cli` now keeps a SQLite catalog of every new
  image, batch, and video operation under `$GFLOW_CLI_DB_PATH` (default:
  `~/.local/share/gflow-cli/data.db`). Records profile, project, asset
  (model / aspect / dimensions / Flow media ID), operation provenance
  (mode / prompt / model / timing / error), input↔output links, and
  downloaded local files. New `gflow data media <id>` command resolves a
  Flow media ID to its origin. `DataRepository` exposes seed-image resolvers
  (`resolve_seed_image_by_path` / `resolve_seed_image` /
  `resolve_latest_image`) — foundation for the upcoming I2V seed-reuse
  path. Pre-Flow store failures exit `16` (`DataStoreError` /
  `DataMigrationError` / `DataIntegrityError`); post-success store
  failures warn and exit `0` (Flow already charged the credits). See
  [`docs/DATA_LAYER.md`](docs/DATA_LAYER.md). (PR #58, stacked on #52.)

### Changed

- `MAX_REFERENCE_IMAGES` (in `api/video.py`) now tracks the `omni_flash`
  ceiling of **7** (was **3**). The tighter per-model cap (`veo_3_1_* ≤ 3`) is
  still enforced in `GenerateVideoRequest.__post_init__` when the model is
  known; the constant is only the absolute upper bound. Anyone pinning to the
  old value of 3 should re-check against the per-model caps.


### Fixed

- `FlowApiClient.__aenter__` now tears down a partially-launched browser if any
  step after the Playwright driver starts raises (e.g. the persistent-context
  launch, the bootstrap navigation, or `transport.setup`). Python does not call
  `__aexit__` when `__aenter__` raises, so an unguarded failure orphaned the
  chrome process, which then held the profile's user-data-dir lock — the next
  run could not acquire it and spiralled into rapid `about:blank` tabs +
  `TargetClosedError`. Context close + driver stop are now shared by
  `__aenter__`'s guard and `__aexit__` via `_close_browser_resources`.
- `gflow image i2i --ref <local-file>` now binds the reference through the
  editor's media dialog instead of the REST `uploadImage` endpoint (which 401s —
  same root as #15/#39). Local-path refs ride a new `GenerateImageRequest.ref_paths`
  field and are attached via the inherited R2V `_attach_references` (the image-mode
  add-media dialog is the same `add_2` surface). Bare-UUID `--ref` still flows
  through `refs` unchanged. Re-introduces #50 (reverted in #57 for the account/
  locale variant tracked in #56); the media-dialog selectors are now
  locale-agnostic (see the next entry).
- The media-dialog upload selectors are now **locale-agnostic** (issue #56/#24).
  `UPLOAD_MEDIA_BUTTON` matched localized text (`has-text('Upload media')`), so on
  a non-English Chrome profile (Flow follows the *Chrome profile* language, which
  the `--lang=en-US` arg cannot override) the click missed and the file chooser
  never opened — a silent ~34s hang. It now anchors on the locale-free `upload`
  icon ligature (`:text-is('upload')`, exact, so it doesn't grab the `Uploads`
  tab), with the original English-text selector kept as a graceful **fallback
  tier** (matches if Google ever changes the icon but keeps the English label);
  'Add to Prompt' (which has no icon) is selected structurally as the only
  iconless button in the open dialog. If neither tier opens a chooser,
  `_upload_via_open_dialog` raises a clear error + writes a screenshot (no silent
  hang) and points the operator at the Chrome-profile-language workaround. Fixes
  I2I/I2V/R2V upload alike.
- `gflow image t2i/i2i --model` now actually selects the requested model. It was
  a no-op under `ui_automation` (the wire field was set but the model picker was
  never clicked, so Flow used its UI default). Adds `_select_image_model`.
- Video selector mismatches: the output-count selector `[id*=-trigger-1]`
  collided with the `-trigger-10` duration tab; the aspect selector matched a
  non-existent `aria-controls*=9_16`; the video-mode tab match was ambiguous.
  All now use exact `[id$=-trigger-X]` suffixes + aria-label text.

### Build

- **Wheel build no longer emits duplicate ZIP entries.** An earlier attempt at
  tagging v0.9.0 was rejected by PyPI with HTTP 400 ("Duplicate filename in
  local headers") because `pyproject.toml` had
  `[tool.hatch.build.targets.wheel.force-include]` and
  `[tool.hatch.build.targets.sdist.force-include]` blocks pointing at
  `src/gflow_cli/data/migrations`, on top of the already-comprehensive
  `packages = ["src/gflow_cli"]` directive — hatchling included the
  migrations directory twice (both `__init__.py` and `0001_initial.sql`). The
  force-include blocks have been removed; hatchling's default package
  inclusion already covers `.sql` files inside the package tree. (PR #74.)

### Notes

- I2V/R2V image inputs bind through the editor's media dialog (frame slot /
  add-media → "Upload media" → file chooser → "Add to Prompt"). `set_input_files`
  on the generic hidden input only adds to the library and Flow then ignores the
  image (plain Text route). The editor is forced to English via the
  `--lang=en-US` Chromium launch arg because the slot/dialog labels are localized
  with no locale-free anchor.

## [0.8.1] — 2026-05-23

### Documentation

- README rewritten as a hybrid router (~150 lines, was 398). New: prominent unofficial-tool + headed-browser callouts above the fold, polished 60-second quick start, in-depth-quick-start link, "For AI agents & LLMs" routing table, ripgrep-style documentation TOC.
- New [AGENTS.md](AGENTS.md) at repo root — universal agent spec consumed by 60k+ repos' tooling (Cursor, Codex, Aider, Gemini CLI, Claude Code, Copilot, opencode, etc.). Closes the gap left by having Claude-Code-only memory.
- New [llms.txt](llms.txt) at repo root — llmstxt.org-format summary for end-users feeding the project into an LLM. Forward-staged for a future docs site.
- New [docs/PROJECT_STATUS.md](docs/PROJECT_STATUS.md) — moved the full milestone table out of README; added lifecycle policy section.
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) absorbed the ASCII system diagram + Auth strategy paragraphs from README; gained a new "Headed-browser dependency — current limitation" subsection that documents the three retired HTTP transports and invites contributor work on a pure-REST path.
- [CLAUDE.md](CLAUDE.md) trimmed from ~80 to ~25 lines; universal coding-agent rules now live in AGENTS.md, with CLAUDE.md carrying Claude-Code-specific session protocol only.
- All `v0.7.0` references that meant "current" updated to `v0.8.1`. Historical mentions preserved in CHANGELOG and `docs/LIVE_VERIFICATION_v0.7.0.md`.
- New per-release evidence file [docs/LIVE_VERIFICATION_v0.8.1.md](docs/LIVE_VERIFICATION_v0.8.1.md).

### Released

- PyPI: https://pypi.org/project/gflow-cli/0.8.1/ — refreshes the stale README rendering left over from v0.8.0.

## [0.8.0] — 2026-05-23

> **Multi-image-prompt release + transport hardening.** Introduces the
> `gflow image batch` subcommand backed by a stay-mounted editor session,
> restores `gflow video t2v` with first-class auto-download, and ships the
> image/video mode-switch symmetry invariant that closes the historical
> "first-attempt listener-miss flake." Also clears all SonarCloud findings
> on the multi-image-prompt PR (cognitive-complexity refactors of
> `_set_count`, `parse_tsv_manifest`, and `_generate_images_batch_locked`).

### Added

- `gflow image batch <manifest>` subcommand for batch image generation from
  JSON or TSV manifests, with `--continue-on-error`. `MAX_BATCH_PROMPTS = 5`.
  All prompts share one Flow project; jitter (3–7 s default) spaces the
  submission clicks for anti-bot cadence, not completion wait. Closes
  [#14](https://github.com/ffroliva/gflow-cli/issues/14) part 2.
- Application-layer structlog events for image-batch submission:
  `image_batch.submission_attempt`, `image_batch.submission_result`,
  `image_batch.row_completed`, `image_batch.inter_submission_latency_ms`.
  Use these to debug Flow throttling regressions without re-instrumenting.
- `BatchPartialError` (in `errors`) — raised by fail-fast batch when
  earlier prompts produced downloadable images before the failing one;
  carries `partial_results` so the orchestrator can salvage them.
- `BatchIntegrityError` (in `errors`) — raised by the orchestrator when
  post-download file count does not match the expected count.
- `BatchSubmissionResult` (in `api.dto`) — new transport-layer per-prompt
  outcome with `project_id`, `prompt_idx`, `prompt_hash` fields. Public
  `list[BatchOutcome]` orchestrator return is unchanged.
- `ui_automation.image_mode_entered` structlog event — emitted when the
  editor is switched into Image mode. Companion to the existing
  `ui_automation_video.video_mode_entered`.
- `ui_automation.orphaned_project_warning` structlog event — emitted when
  `_enter_editor` succeeded but a later setup step
  (`_dismiss_blocking_overlays` / `_switch_to_image_mode`) raises, so the
  user can find their server-side project record.
- `ui_automation.batch_403_body` structlog event — emitted (warning level)
  with a 200-char body prefix when a `batchGenerateImages` response is HTTP
  403 (WAF / reCAPTCHA), immediately before the `WafRejectionError` raise.
- `VideoResult` dataclass — return type of `generate_video`, carries
  `status` and `local_path` ([#29](https://github.com/ffroliva/gflow-cli/issues/29)).
- `UiAutomationTransport._download_video` — downloads a generated mp4 via
  `media.getMediaUrlRedirect` using the authenticated page; falls back to
  `self._out_dir` then `tmp/` when no `out_dir` is supplied
  ([#29](https://github.com/ffroliva/gflow-cli/issues/29)).
- `FlowApiClient.download_video(media_id, out_path)` — public API, mirrors
  `download_image` ([#29](https://github.com/ffroliva/gflow-cli/issues/29)).
- `gflow video t2v PROMPT` restored — generates and downloads a video
  end-to-end on `UiAutomationTransport`; supports `--aspect`
  (`9:16` / `16:9`), `--profile`, and `--out-dir`
  ([#29](https://github.com/ffroliva/gflow-cli/issues/29)).
- `UiAutomationTransport._switch_to_image_mode` static method + module-level
  `IMAGE_TAB_IN_MENU_SELECTORS` cascade — mirror of the video side's
  `_switch_to_video_mode`. Called from both `generate_images` and
  `_generate_images_batch_locked` after `_dismiss_blocking_overlays`,
  before `_configure_generation_settings`.

### Changed

- `gflow image batch` editor session is now persistent across all prompts
  in a batch. The transport's stay-mounted-session pattern is the
  canonical shape; same-project semantics are the only supported mode.
- `_attach_batch_response_listener` now returns `(captured, detach_fn)`;
  callers that used the single-list return need to unpack accordingly.
- `UiAutomationTransport.generate_video` now accepts `download: bool = True`
  and returns `VideoResult` instead of `VideoStatus` — **breaking change
  for direct transport callers** (the `FlowApiClient` boundary is
  unaffected). Pass `download=False` to skip the auto-download step.
- `_set_count` (count-tab selector) is locale-invariant: regex
  `^(1x|x[2-4])$` (Flow renders digit+x identically in every locale) +
  positional `.nth(count - 1)` fallback when read-back text is
  unrecognised. Partial fix for
  [#24](https://github.com/ffroliva/gflow-cli/issues/24); `ONBOARDING_SELECTORS`
  still localized text — see KNOWN_ISSUES.


### Fixed

- `gflow image t2i` and `gflow image batch` now explicitly select Image
  mode in the Flow editor before submitting. Previously, if the account
  was last in Video mode, prompts were silently routed to the video
  endpoint — no `batchGenerateImages` response was observed and the
  listener timed out after 3 minutes. Also resolves the historical
  "first-attempt listener-miss flake" recorded in `phase-b-followups`
  memory item #1. Live-verified on profile `ffroliva` (1 t2i shot + full
  batch e2e); evidence in
  [`docs/LIVE_VERIFICATION_image_batch.md`](docs/LIVE_VERIFICATION_image_batch.md)
  § Post-mode-switch-fix verification.
- `gflow image batch` now actually shares one Flow project across all
  prompts in a batch. Previously the `--same-project=1` flag was a no-op
  at the `ui_automation` transport layer; each prompt landed in its own
  Flow project.
- `gflow image t2i -n N` now makes one transport call using Flow's native
  xN count selector instead of fanning out N parallel single-image
  submissions. Closes [#14](https://github.com/ffroliva/gflow-cli/issues/14) part 1.
- Structlog now uses `cache_logger_on_first_use=False` so per-test
  `LogCapture` fixtures see events fired from production modules
  (previously the cached logger froze the processor chain at import).
- All SonarCloud findings on the multi-image-prompt PR (S5655 / S5890 /
  S1192 / S1172 / S3776 ×3) — see PR #40 commit `a0cb010` for the
  cognitive-complexity refactors and the cast+pragma pattern for
  `dataclasses.replace`.

### Removed

- **BREAKING:** `--same-project` flag on `gflow image batch`. The flag
  collapsed to a single behaviour (always-same-project) — no toggle
  remains. For different-project results, loop `gflow image t2i`
  externally.
- **BREAKING:** `--seed` flag from `gflow image t2i` and `gflow image i2i`.
  The flag was a no-op under the active UI transport since v0.7.0
  (silently discarded inside the client before reaching the transport).
  If reproducibility via user-controlled seed becomes possible again —
  either through Flow UI exposing a seed control or via HTTP transport
  revival — the surface will be re-introduced at that layer. The
  wire-format body builder retains its `seed` / `batch_id` parameters for
  the experimental HTTP transports' internal use.
- **BREAKING (library):** `FlowApiClient.generate_image` no longer accepts
  `seed=` or `batch_id=` kwargs. `FlowApiClient.generate_images_batch` no
  longer accepts `seeds=`. Callers passing these will get a `TypeError`.
  Same justification as the CLI removal.
- **BREAKING (library):** `project_title` parameter removed from
  `run_manifest_image_batch` — the transport now owns project creation
  via `_enter_editor`, making this orchestrator-side knob dead weight.

## [0.7.0] — 2026-05-20

> **Downstream-worker ergonomics release.** Hardens `FlowApiClient` for
> long-lived integrations: standard exception module name, optional
> `project_id`, `health_check()` for liveness probes, `out_dir` for
> debug-screenshot plumbing, and a stable library-owned error when the
> underlying browser session dies. Plus auth-flow fixes from issues #15 and
> #17 and overlay-dismiss for first-run profiles (#26).

### Added

- `gflow_cli.exceptions` module as a standard alias for `gflow_cli.errors` — both module names resolve identically. Closes [#16](https://github.com/ffroliva/gflow-cli/issues/16).
- `FlowApiClient.health_check()` async method — returns `True` if browser context is alive and on a Google domain; safe to call from long-lived workers without try/except. Closes [#16](https://github.com/ffroliva/gflow-cli/issues/16).
- `FlowApiClient(out_dir=...)` constructor argument — when set, the resolved transport stores it as `_out_dir` so internal `_capture_debug_screenshot` calls inside `UiAutomationTransport._generate_images_locked` (entering the editor, dismissing overlays, sending prompts) save artifacts to that directory. Long-lived workers can now diagnose selector failures without restructuring their call sites. Closes [#18](https://github.com/ffroliva/gflow-cli/issues/18).
- `BrowserSessionClosedError` (`gflow_cli.errors`, exit code 15) — raised from `FlowApiClient.generate_image()` / `generate_images_batch()` when the underlying Playwright page/context is closed mid-call (Playwright `TargetClosedError`). Callers can now catch a stable library-owned class and recreate the client via `async with FlowApiClient(...)` instead of importing from `playwright._impl._errors`. Closes [#18](https://github.com/ffroliva/gflow-cli/issues/18).
- `UiAutomationTransport._dismiss_blocking_overlays(page)` — generic overlay-dismiss helper that detects Flow changelog ("What's new") iframes and dismisses them via a close-button selector cascade with an Escape-key fallback. Invoked after editor entry on both image and video flows so first-run profiles no longer fail on the next click. Closes [#26](https://github.com/ffroliva/gflow-cli/issues/26).
- Release tags must now be **signed annotated tags** (`git tag -s vX.Y.Z`). CI's release job rejects unsigned tags so the GitHub release surfaces as Verified ([#30](https://github.com/ffroliva/gflow-cli/issues/30)).
- New documentation: [`docs/DEBUGGING.md`](docs/DEBUGGING.md) — evergreen reference for debugging, testing, and troubleshooting (listener log keys, selector-cascade discipline, lifecycle errors, Windows console encoding, test-suite memory). [`docs/LIVE_VERIFICATION_v0.7.0.md`](docs/LIVE_VERIFICATION_v0.7.0.md) — per-release end-to-end evidence (every CLI aspect ratio live-tested).

### Changed

- `FlowApiClient.generate_image()` and `generate_images_batch()`: `project_id` is now optional (`str | None = None`). When omitted, a new Flow project is created automatically. Existing callers passing an explicit `project_id` are unaffected. Closes [#16](https://github.com/ffroliva/gflow-cli/issues/16).
- `gflow video t2v/i2v/batch` now report "temporarily unavailable" — video generation is being rebuilt on the UI-automation transport (Phase A ships the T2V transport; CLI commands return in Phase B).

### Removed

- The 401-dead HTTP video API path (`FlowApiClient.generate_video`, `get_video_status`) — retired in favour of the new UI-automation transport (`VideoGenerationMixin` in `api/transports/ui_automation_video.py`).


### Fixed

- `gflow auth login` now verifies a real Flow app session before reporting
  success — fixes issue [#15](https://github.com/ffroliva/gflow-cli/issues/15), where a Google-only sign-in was wrongly accepted
  and later failed with HTTP 401.
- **`gflow auth login --browser internal` now fails fast when Google rejects
  Playwright's bundled Chromium**, returning `AuthBrowserRejectedError` exit
  code 14 with guidance to rerun using real Chrome
  (`gflow auth login --browser chrome`) or set
  `GFLOW_CLI_AUTH_BROWSER=chrome` ([#17](https://github.com/ffroliva/gflow-cli/issues/17)).
- **`gflow image t2i --aspect 1:1` aspect-ratio tab regression** — Flow's
  `1:1` tab is now selected via an exact-match (`:text-is`) cascade against
  the labels `1:1`, `Square`, `1×1`, `1x1` instead of the prior
  `:has-text("1:1")` substring match. The substring selector was matching an
  invisible parent on some Flow UI variants, causing a 3 s timeout and a
  silent fallback to Flow's default aspect. All five CLI aspect ratios
  (`16:9`, `9:16`, `1:1`, `4:3`, `3:4`) are now live-verified.
- `UiAutomationTransport._attach_batch_response_listener` now emits a
  `ui_automation.batch_response_seen` log for every `batchGenerateImages`
  URL observed (BEFORE the per-project filter) and a
  `ui_automation.batch_response_dropped_project_id_mismatch` log when the
  filter rejects a response. Eliminates the silent black-hole that hid
  listener-miss bugs during live verification.

## [0.6.0a6] — 2026-05-17

> **Stability & code-quality release.** Fixes a concurrency bug in image
> generation, restores a green CI pipeline (the test job had been hanging
> indefinitely), and clears every open SonarCloud issue so the project's
> Quality Gate passes.


### Fixed

- **Concurrent `generate_images` calls are now serialized**, and every batch
  creates a fresh Flow project — prevents project-reuse races when multiple
  image generations overlap.
- **CI test job no longer hangs.** `RealChromeStrategy` launches Chrome with
  `asyncio.create_subprocess_exec`, but its tests patched `subprocess.Popen`;
  asyncio's POSIX subprocess transport uses `Popen` internally, so the mock
  left the event loop's child watcher unresolved forever — the test job ran
  until cancelled and never wrote a coverage report. Tests now patch
  `asyncio.create_subprocess_exec` directly.
- **structlog log-capture test isolation** — a `browser_manager` test asserted
  on a log event that an earlier test had already cached onto the production
  logger chain (`cache_logger_on_first_use=True`). It now patches in a fresh
  logger proxy and passes regardless of suite order.

### Changed

- **All open SonarCloud issues resolved** and the Quality Gate now passes:
  the S6418 BLOCKER and 10× S5443 CRITICAL test findings, 16 mechanical
  issues, async-hygiene rules (S7503 / S7487 / S7493), and 5
  cognitive-complexity (S3776) extractions. The two remaining Security
  Hotspots — `random`-based retry jitter and protocol-mandated SHA-1 in
  `sapisidhash` — were reviewed and marked Safe.

### Security / Compliance

- **Removed accidentally tracked artefacts** — 7 files were untracked from git:
  `denon82/.gflow-cdp.lock`, `test_assets/debug_editor/buttons.json`,
  `test_assets/debug_settings/settings_panel.json`, and 4 AI-generated JPGs
  in `test_assets/smoke_e2e_*/`. None contained credentials or API tokens, but
  the CDP lock file exposed a profile name and browser PID and the debug JSON
  files contained Flow UI text. Files were removed from HEAD forward (no history
  rewrite — see decision rationale in `PLAN.md` ADR #3).

- **`.gitignore` hardened** — added `*.jpg`, `*.jpeg`, `**/.gflow-cdp.lock`,
  `test_assets/smoke_*/`, `test_assets/debug_*/`, and `gflow-output/` to
  prevent recurrence. Fixture allowlist added (`!test_assets/fixtures/**/*.jpg`).

- **Hygiene gate added to CI** — `scripts/ci/check_repo_hygiene.py` runs on
  every push and PR before lint. Fails if tracked files match the denylist or
  if any `scripts/**/*.py` contains a hardcoded Windows absolute path or writes
  output to `test_assets/`.

- **`.pre-commit-config.yaml` added** — ships ruff (lint + format) and the
  hygiene gate as pre-commit hooks. Install with:
  `pip install pre-commit && pre-commit install`.

- **Debug scripts de-hardcoded** — `scripts/debug_editor.py`,
  `scripts/debug_gen_settings.py`, `scripts/debug_settings.py` previously
  contained `PROFILE = r"C:\Users\ffrol\..."` (Windows username + Google
  profile name) and wrote output to `test_assets/`. Replaced with argparse
  `--profile` flag + `auth.profile_dir(args.profile)` and output redirected to
  `tmp/debug/<name>/`.

- **CI workflow scrubbed** — removed a hardcoded profile name (`denon82`) from
  a comment in `.github/workflows/ci.yml`.

### CI / Tooling

- **GitHub Actions migrated to Node.js 24** ahead of the June 2026 forced
  migration (`FORCE_JAVASCRIPT_ACTIONS_TO_NODE24`).
- **SonarCloud Quality Gate badge** added to the README.

## [0.6.0a5] — 2026-05-16

> **CLI transport proven end-to-end.** The `ui_automation` transport now
> generates images correctly from the `gflow image t2i` command — count,
> aspect ratio, and file download all work. Root cause of the persistent 403
> was `headless=True`; reCAPTCHA Enterprise immediately rejects headless
> Chromium.


### Fixed

- **`headless` default changed `True` → `False`** in `config.py` and
  `FlowApiClient.__init__` — the `ui_automation` transport requires a headed
  (visible) Chrome window; reCAPTCHA Enterprise scores headless browsers as
  bots and returns an immediate 403 on `batchGenerateImages`.
- **13 unit test mock regressions** fixed after the v0.6.0a4 transport rewrite:
  - `add_init_script = AsyncMock()` added to `_patch_playwright` and
    `fake_context` fixtures (`test_client.py`, `test_concurrency.py`).
  - `keyboard.insert_text = AsyncMock()` added to `_make_prompt_page`
    (transport now uses `insert_text` instead of `type`).
  - `_FakeHttpxResponse.headers` added (download auto-detects `.jpg`/`.png`
    from `Content-Type`).
  - `_capture_batch_response` / `_await_captured` return `list[dict]` —
    test assertions updated throughout `test_ui_automation.py`.

## [0.6.0a4] — 2026-05-17

> **Unified output resolution + batch orchestration refactor.** This release
> aligns the CLI output structure across all commands and refactors the batch
> runner to be more generic, preparing the codebase for Phase 6.

### Added

- **`resolve_batch_output_dir` helper** in `paths.py` — centralizes the
  date-partitioned output directory logic used by all generation commands.
- **`parse_batch_item_dict` helper** in `image_batch.py` — deduplicates JSON
  prompt validation between `gflow run` and other batch sources.

### Changed

- **`gflow run` output directory** — now defaults to date-partitioned
  `$GFLOW_CLI_OUTPUT_DIR/images/<YYYY-MM-DD>/` instead of the legacy
  `out/<UTC-timestamp>/`, matching the `gflow image` convention.
- **Refactored `run_image_batch`** into a generic `run_sequential_batch`
  orchestrator — now accepts a swappable worker callback, allowing for uniform
  video and image batch handling in the future.


### Fixed

- Removed ~80 lines of duplicate validation logic from `cli_run.py`.
- Corrected test imports and expectations for unified output resolution.

## [0.6.0a3] — 2026-05-17

> **Deterministic timeouts + agent-friendly exit codes.** This release hardens
> the auth login flow for unattended / agentic use: timeouts now raise distinct
> errors with dedicated exit codes instead of silently swallowing failures.

### Added

- **`AuthLoginTimeoutError`** (exit code **12**) — raised by both strategies
  when the user/agent does not complete sign-in within `timeout_seconds`.
  Distinct from `ConfigurationError` (11) and `SecurityError` (13) so agents
  can branch on failure type without parsing stderr.
- **`SecurityError`** exit code **13** — now registered in `EXIT_CODE_MAP`.
- **`timeout_seconds=600` parameter** on both `RealChromeStrategy` and
  `InternalChromiumStrategy` — configurable upper bound for the login window.
- **Broad `GFlowError` catch** in `auth_login` CLI command — previously only
  caught `ConfigurationError`; now looks up any `GFlowError` subclass in
  `EXIT_CODE_MAP` and exits with the correct code plus a `remediation_hint`.


### Fixed

- `InternalChromiumStrategy` had an infinite `while True:` polling loop that
  never timed out; replaced with a bounded loop that raises
  `AuthLoginTimeoutError` on expiry.
- `auth login --browser chrome` when Chrome is missing now exits with code
  **11** (ConfigurationError) instead of 1.

## [0.6.0a2] — 2026-05-16

> **Real Chrome auth strategy — G12 block resolved.** This release restores
> `gflow auth login` reliability by implementing a new **Passive Capture**
> strategy. This method providing a 100% clean browser environment by launching
> your system's real Google Chrome as a standard process, completely bypassing
> Google's bot-detection.

### Added

- **`--browser [auto|chrome|internal]` flag** on `gflow auth login` — selects
  the browser strategy. `chrome` uses real system Chrome (**Passive Capture**).
  `internal` falls back to bundled Chromium. `auto` (default) probes for real
  Chrome and falls back gracefully.
- **`GFLOW_CLI_AUTH_BROWSER` env var** — overrides the browser strategy without
  a CLI flag.
- **`RealChromeStrategy`** (`src/gflow_cli/auth/real_chrome.py`) — zero-automation
  login flow: launches clean Chrome, waits for user to close window, then extracts
  the session.
- **`InternalChromiumStrategy`** — extracted from the previous `auth.py` monolith
  as an explicit fallback strategy.
- **`AuthStrategyFactory`** — routes `auto`/`chrome`/`internal` to the
  appropriate strategy based on system state.


### Fixed

- **G12 bot-detection block** — Google's "browser not secure" rejection (`/v3/signin/rejected`)
  is bypassed by the Passive Capture workflow. By removing all automation signals
  (CDP, WebDriver flags) during login, the browser is indistinguishable from a
  regular user session.
- **Privacy Guard** — `RealChromeStrategy` validates that `profile_dir` is inside
  `GFLOW_CLI_HOME` and raises `SecurityError` if it is not, preventing accidental
  interference with your primary personal Chrome profile.
  use of the user's primary system Chrome profile.
- **`ConfigurationError` on missing Chrome** — clear "Chrome binary not found"
  message with install guidance when `--browser chrome` is requested but Chrome
  is not on the system.
- **Two pyright `TypedDict` errors** in cookie access (`c["name"]` → `c.get("name")`).

### Changed

- `src/gflow_cli/auth.py` promoted to `src/gflow_cli/auth/` package with
  `__init__.py`, `base.py`, `factory.py`, `internal_chromium.py`,
  `real_chrome.py`, `strategies.py`.
- `gflow auth login` now prints the launch strategy announcement before opening
  any browser window.

> **Shell-friendly multi-prompt `t2i` + performance hardening.** This release 
> promotes `gflow image t2i` to a variadic command that can consume multiple 
> prompts from positional arguments, a line-delimited text file, or standard 
> input. Core generation logic has been consolidated into a shared 
> `image_batch` module, ensuring architectural consistency between shell runs 
> and JSON-described batches. This version also ships critical resource 
> cleanup fixes for SQLite connections and OOM protection for stdin streams.

### Added

- **Variadic `gflow image t2i`** — now accepts multiple positional prompts. 
  Example: `gflow image t2i "prompt 1" "prompt 2"`.
- **`--prompts-file <PATH>` and `--stdin`** — read batches of prompts from 
  text files or pipes. All prompts in a batch share a single Flow session 
  and project, significantly reducing reCAPTCHA and project-init overhead.
- **Shared `image_batch` logic** (`src/gflow_cli/image_batch.py`) — unified 
  orchestration, validation, and rendering for all multi-prompt generation 
  surfaces.
- **Memory safety for stdin** — bounded read on standard input prevents 
  memory exhaustion when piping large or infinite streams.
- **`examples/multi_prompt_t2i.py` + `examples/sample_prompts.txt`** — 
  runnable template for the new shell-multi-prompt surface.


### Fixed

- **Resource leaks in SQLite** — ensured all `sqlite3` connections are 
  properly closed via `try...finally` blocks, resolving resource exhaust 
  warnings and potential hangs in long-running processes.
- **Output directory partitioning** — `t2i` batches now correctly land in 
  date-partitioned folders (`images/YYYY-MM-DD/`) by default, aligning 
  with the core design spec.

### Changed

- **CLI validation alignment** — `t2i` and `i2i` subcommands now use 
  authoritative domain constants for model, aspect, and count validation, 
  ensuring UI help text and defaults stay in perfect sync with the engine.

## [0.5.0a1] — 2026-05-12

> **Pluggable image transport + JSON-described batch runs.** The image
> generation surface now ships a new default `ui_automation` transport —
> a Playwright-driven UI mimicry strategy validated end-to-end against
> real Flow on a Google AI Pro/Ultra profile. Three earlier HTTP
> transport strategies (`evaluate_fetch`, `bearer`, `sapisidhash`) move
> into a new `experimental/` subpackage; they remain importable for
> research but are hidden from the CLI by default. New top-level
> `gflow run --config <file>` command drives JSON-described sequential
> batches through one shared session.

### Added

- **`UiAutomationTransport`** (`gflow_cli.api.transports.ui_automation`)
  — new default transport. Drives the Flow editor on a logged-in
  profile through a Playwright-managed persistent context (internal CDP
  port; no externally-exposed debug port). Mirrors the validated
  reference flow in `scripts/smoke_worker_style.py`.
- **`gflow run --config <file>`** — sequential JSON-described batch
  command. Schema covers `profile`, `transport`, `output_dir`, and a
  `prompts` list (1–50 entries) with per-prompt `text`,
  `aspect_ratio`, `model`, `count`, and `output_filename`. Supports
  `--continue-on-error` (default) and `--fail-fast` semantics; final
  exit code is the max per-prompt exit code. ONE `FlowApiClient`
  session wraps the whole loop so the browser/project persist across
  prompts.
- **`examples/` directory** — three runnable scripts (`single_image_t2i.py`,
  `batch_from_config.py`) + a copy-and-edit `sample_config.json` + an
  index `examples/README.md`. All sanitised: no hardcoded profile
  names, generic placeholder prompts, parameterised via `--profile` /
  `$GFLOW_EXAMPLE_PROFILE`.
- **Opt-in real-Flow smoke test** at `tests/smoke/test_real_flow.py`,
  gated by `GFLOW_E2E=1` + `GFLOW_E2E_PROFILE`. Runs the full
  `UiAutomationTransport` flow against real Flow and asserts a
  non-trivial PNG was written.
- **`EXPERIMENTAL_TRANSPORTS` constant** + **`transport_choices()`
  helper** in `gflow_cli.api.transports`. The factory continues to
  accept every registered key; the CLI `--transport` Choice list is
  the gated surface (default = `ui_automation` only;
  `GFLOW_CLI_EXPERIMENTAL_TRANSPORTS=1` expands to all four).
- **Download host allow-list** in `UiAutomationTransport._download`
  (`googleusercontent.com`, `googleapis.com`, `google.com` suffix
  match). `follow_redirects=False`. Prevents session cookies from
  reaching a non-Google host through a malformed or compromised
  `fifeUrl`.

### Changed

- **Default `--transport` flag** flipped from `evaluate_fetch` to
  `ui_automation` across `gflow image t2i`, `gflow image i2i`, and
  `gflow image upload`. The change is transparent to existing scripts
  unless they pinned `--transport evaluate_fetch` explicitly.
- **`evaluate_fetch` / `bearer` / `sapisidhash` strategies moved** to
  `gflow_cli.api.transports.experimental.*`. Public registry keys
  (the strings used by `make_transport()` and the
  `GFLOW_CLI_TRANSPORT` env var) are unchanged. Import paths within
  the package are the only user-visible delta.
- **Debug screenshots** captured by the strategy on `_enter_editor` /
  `_send_prompt` failures are now **viewport-only**
  (`full_page=False`) and emit a `WARNING` log line noting the file
  may contain identifying information from the authenticated session.


### Fixed

- Listener-attach race in `generate_images`. The earlier
  `asyncio.create_task(_capture_batch_response(page))` scheduled the
  listener registration AFTER the next event-loop tick; on a busy
  loop the prompt click could fire before the listener attached,
  causing the capture to time out. Refactored into a synchronous
  `_attach_batch_response_listener(page)` + an `async
  _await_captured(captured, ...)`. No more orphaned task on partial
  failure.

### Removed

- Dead `_extract_image_urls(response)` helper on
  `UiAutomationTransport` and its five tests.
  `generate_images` parses `body.media[]` directly through
  `GeneratedImage.from_response_item`; the parallel helper was
  unreachable.

### Documentation

- `BrowserManager` module docstring updated to make explicit that the
  module is retained for research / non-Flow use, not on the
  v0.5.0a1 image-generation critical path. No behavior change.
- README "Project status" table updated with v0.5.0a1 row.
- `docs/USAGE.md` gains a `gflow run` section.

## [0.4.0a2] — 2026-05-11

> **Documentation polish.** Same release surface as v0.4.0a1; this tag fixes
> a doc-council pass: four broken Python snippets in the README, a shell
> exit-code branching example that silently dropped failures, a stale anchor
> link in `AUTHENTICATION.md`, three USER_GUIDE journeys the target audience
> needs (credit budgeting, pipeline wiring, error recovery), and a sweep of
> "planned v0.3 / v0.4" callouts across 9 files that had been overtaken by
> the Phase 4 release. No code changes. No tests changed.

### Fixed (docs)

- **`README.md` Python quick-start snippet rewritten** — the prior block had
  four real bugs (`from gflow_cli.paths import profile_dir` → import error,
  `upload_image(path, project_id)` args reversed, `generate_video(prompt=,
  start_asset=, aspect=)` wrong kwargs, `poll_video_status` method does not
  exist). Snippet now uses the same invocation pattern as
  `gflow_cli.cli_video._run_i2v` and would actually run.
- **`docs/USAGE.md` exit-code branching example** — `if ! cmd; then case $?`
  always saw `0` because the `if` consumed the exit code; rewritten to
  capture `rc=$?` first. Exit code `2` re-labelled "Bad CLI usage" (auth is
  exit `3`).
- **`docs/AUTHENTICATION.md` anchor link** to the Phase 4 PLAN heading
  fixed (was `#phase-4--hardening--post-v030a1`, did not exist).
- **`CHANGELOG.md` footer** — added `[0.4.0a1]:` and `[0.4.0a2]:` compare
  links; reset `[Unreleased]` to compare from v0.4.0a2.
- **`docs/USER_GUIDE.md` Journey 2** endpoint name `flowMedia:batchGenerateVeoVideo`
  → real route `/v1/video:batchAsyncGenerateVideoText`.
- **`docs/USER_GUIDE.md` Journey 5.2** invalid placeholder UUID
  (`media-uuid-abc-...`) → canonical hex shape.
- **`docs/USER_GUIDE.md` Journey 7.1** `echo $?` placement — previously
  captured the exit code of an intermediate command, not the failing batch.
- **`docs/USER_GUIDE.md` Journey 7.3** softened the "Flow doesn't re-bill"
  claim — billing is a private-API contract we cannot assert.
- **`KNOWN_ISSUES.md` same-profile examples** swapped `gflow image batch`
  (does not exist) → `gflow video batch`.

### Added (docs)

- **`docs/USER_GUIDE.md` Journey on credit budgeting** — rule-of-thumb credit
  cost per `video t2v` / `video i2v` / `image t2i` / `image i2i` call, links
  to Flow's credit-balance UI, batch-cost math example.
- **`docs/USER_GUIDE.md` Journey on wiring outputs into a pipeline** —
  deterministic output-dir layout, `find` (POSIX) + `Get-ChildItem`
  (PowerShell) recipes, `ffmpeg` consumer example.
- **`docs/USER_GUIDE.md` Journey on `ContentPolicyError` / `RateLimitError`
  recovery** — what each error means, how long to wait, prompt-rewrite
  pattern, when retry is futile.
- **`README.md` doc-nav** now links `docs/USER_GUIDE.md` (was missing).
- **`README.md` Stack table** lists `tenacity` and `structlog` (were
  shipped in v0.4.0a1 but not in the stack overview).

### Changed (docs)

- **`CHANGELOG.md` [0.4.0a1] section reordered** — `Added — Phase 4
  hardening` now appears before `Breaking`. The hardening release was
  user-visible value; the env-var rename was a one-line update for most
  users.
- **Per-class exit codes 3–7** promoted from a bullet to its own "Migration
  notes" subsection in the [0.4.0a1] block.
- **Version-time-warp sweep across 9 files** — every `(planned v0.3)`,
  `(planned v0.4)`, `v0.3+ will add`, `v0.4 will add`, and `current scaffold
  ignores this` line either describes shipped behaviour or points at v0.5+.
  Files touched: `README.md`, `CHANGELOG.md`, `CLAUDE.md`, `PLAN.md`,
  `KNOWN_ISSUES.md`, `CONFIGURATION.md`, `AUTHENTICATION.md`,
  `ARCHITECTURE.md`, `DISCLAIMER.md`, `SECURITY.md`, `CONTRIBUTING.md`,
  `.env.template`.
- **`docs/ARCHITECTURE.md` Concurrency section** describes the shipped
  `asyncio.Queue` Page pool, not the target-DDD `Semaphore` model.
- **`docs/ARCHITECTURE.md` Observability section** describes the shipped
  `error_raised` / `error_unhandled` event names, not the target-DDD
  dot-path names.
- **`docs/ARCHITECTURE.md` DDD error class names** annotated as target —
  shipped Phase 4 names (`AuthExpiredError`, `RateLimitError`,
  `ContentPolicyError`, `NetworkError`, `WireFormatError`) listed alongside.
- **`docs/CONFIGURATION.md` `GFLOW_CLI_CONCURRENCY`** describes shipped
  behaviour (per-worker Page pool, `asyncio.gather` fan-out).

## [0.4.0a1] — 2026-05-11

> **Phase 4 hardening release.** Concurrency, retry/backoff, typed errors,
> and structured logs ship — your existing scripts keep running (the
> `FLOW_CLI_*` env-var shim is in place until v0.5.0). The user-visible
> contract that changed: shell scripts can now branch on stable per-class
> exit codes (3–7) for auth / rate-limit / content-policy / network /
> wire-format failures.

### Added — Phase 4 hardening

- **Per-worker Playwright Page pool.** `FlowApiClient.__aenter__` opens
  `Settings.concurrency` Pages inside a single persistent BrowserContext.
  Operations check out a Page via `asyncio.Queue` (FIFO, bounded by
  `maxsize=N`). `GFLOW_CLI_CONCURRENCY=N` (1–16) now actually parallelizes.
- **`gflow video batch` fans out via `asyncio.gather`** over manifest
  entries — was sequential pre-v0.4.0a1.
- **`tenacity`-based retry layer** (3 attempts, exponential jittered
  backoff 1s±25% → 2s±25% → 4s±25%) on 5xx / 429 / `playwright.async_api.Error`
  / `TimeoutError`. `Retry-After` honoured, **capped at 60 s**. `reraise=True`
  so the original exception's `__cause__` chain is preserved. reCAPTCHA
  token re-minted **inside the retry loop, every attempt**, on the worker's
  own Page.
- **RFC 9457 Problem Details exception hierarchy:**
  `GFlowError → FlowApiError → {AuthExpiredError, RateLimitError,
  ContentPolicyError, NetworkError, WireFormatError}`. `except FlowApiError`
  catches the typed subclasses (back-compat). Each carries
  `problem_type` URI, `title`, `status`, `detail`, `instance`
  (`gflow:error:<correlation_id>`), `remediation_hint`, and `route`.
  `to_problem_details()` serializes to the RFC 9457 JSON shape.
- **Per-class exit codes**: 3 (auth) / 4 (rate-limit) / 5 (content-policy) /
  6 (network) / 7 (wire-format). Exit 1 = unhandled. Exit 130 = SIGINT.
- **`WireFormatError` discovery payload** — `route_name`, `http_status`,
  `content_type`, `top_level_keys`, `body_prefix_redacted` so log mining
  can propose new error subclasses for unexpected response shapes.
- **`structlog` bootstrap** with TTY auto-detection (text on TTY, JSON when
  piped). `show_locals=False` mandatory on the exception renderer so frame
  locals (which may contain auth tokens) NEVER reach the log stream.
  `correlation_id` + `cli_version` bound via `contextvars` at the process
  boundary.
- **`error_raised` and `error_unhandled` events.** `error_raised` for caught
  `GFlowError`s — carries Problem Details. `error_unhandled` for anything
  else — privacy-safe: hashes message + stack with SHA-256, never logs raw
  payload.
- **12 `pytest-bdd` scenarios** across `auth.feature`, `video.feature`,
  `image.feature` — all use a mocked `FlowApiClient`. A
  `_forbid_live_playwright` autouse tripwire fails any scenario that
  accidentally tries to start a real browser.

### Migration notes — stable exit codes

Shell scripts that previously branched on exit code `1` for any failure
can now distinguish the failure class. The mapping is locked by an
ordering-invariant test in `tests/test_errors.py`:

| Exit | Error class           | Meaning                              | Retry?         |
|------|-----------------------|--------------------------------------|----------------|
| 0    | —                     | Success                              | —              |
| 1    | (unhandled)           | Bug. Filed via `error_unhandled`     | No             |
| 2    | (Click)               | Bad CLI usage / missing arg          | Fix the call   |
| 3    | `AuthExpiredError`    | Session cookies invalidated          | After re-login |
| 4    | `RateLimitError`      | Flow returned 429                    | Yes, with wait |
| 5    | `ContentPolicyError`  | Prompt blocked upstream              | After rewrite  |
| 6    | `NetworkError`        | DNS / TLS / 5xx after retry          | Yes            |
| 7    | `WireFormatError`     | Response shape changed (Flow update) | File a bug     |
| 130  | (SIGINT)              | User Ctrl-C                          | —              |

See [`docs/USAGE.md § Exit codes`](docs/USAGE.md#exit-codes) for a
shell-script template that branches on these codes.

### Breaking — package + env-var rename

- **Python package renamed: `flow_cli` → `gflow_cli`.** All imports must
  change: `from gflow_cli...` (was `from flow_cli...`). The PyPI distribution
  name (`gflow-cli`), the CLI binary (`gflow`), and the user data directory
  (`gflow-cli/` under `platformdirs`) are unchanged.
- **Env var prefix renamed: `FLOW_CLI_*` → `GFLOW_CLI_*`.** Affected vars:
  `GFLOW_CLI_HOME`, `GFLOW_CLI_OUTPUT_DIR`, `GFLOW_CLI_PROFILE`,
  `GFLOW_CLI_HEADLESS`, `GFLOW_CLI_LOG_LEVEL`, `GFLOW_CLI_LOG_FORMAT`,
  `GFLOW_CLI_PROVIDER`, `GFLOW_CLI_TIMEOUT_SECONDS`, `GFLOW_CLI_CONCURRENCY`,
  `GFLOW_CLI_GEMINI_API_KEY`.
- **Backwards-compat shim.** Legacy `FLOW_CLI_*` env vars continue to work
  in v0.4.x; on first encounter the process emits a single
  `DeprecationWarning` to stderr summarising the promoted keys. The shim
  will be removed in v0.5.0 — update your `.env` files and shell exports.

### Changed

- `FlowApiError` re-parented under `GFlowError`. Legacy positional
  constructor `FlowApiError(status, body, *, route)` preserved (auto-detected
  via `isinstance(args[0], int) and not isinstance(args[0], bool)`).
- `_resolve_profile` and `_make_provider_dir` deduped — relocated from
  `cli_image.py` + `cli_video.py` to `gflow_cli._cli_helpers`. AST-based
  drift guard in `tests/cli/test_helpers.py` prevents regression.
- All `logging.*` callsites in `src/` migrated to `structlog`. The
  remaining `print()` in `auth.py` swapped to Rich `console.print()`.

### Internal

- New module: `gflow_cli.errors` (RFC 9457 hierarchy + `EXIT_CODE_MAP`).
- New module: `gflow_cli.observability` (structlog bootstrap + event
  emitters; `show_locals=False` via
  `ExceptionRenderer(ExceptionDictTransformer(show_locals=False))`).
- New module: `gflow_cli.api._retry` (tenacity `AsyncRetrying` +
  `Retry-After` parser, capped at 60 s).
- New module: `gflow_cli._cli_helpers` (shared CLI-boundary handlers +
  profile/provider helpers).

## [0.3.0a1] — 2026-05-10

### Added
- **`gflow image upload PATH`** — upload a single local image (PNG/JPEG) into a
  fresh Flow project and print the asset UUID + dimensions Flow inferred. The
  UUID is reusable as a starting frame for `gflow image i2i --ref` and
  `gflow video i2v`.
- **`gflow image t2i PROMPT`** — text-to-image generation (1–4 images per call)
  via Google Flow's Imagen / Nano Banana models.
  Flags: `--model {nano2|nano-pro|image4}`, `--aspect {9:16|16:9|1:1|4:3|3:4}`,
  `-n/--count` (1–4), `--seed` (single-image only), `--out DIR`, `--profile`.
  Files land date-partitioned under `$GFLOW_CLI_OUTPUT_DIR/images/<YYYY-MM-DD>/`
  by default; `--out DIR` writes flat as `<DIR>/<media_name>_<n>.png`.
- **`gflow image i2i PROMPT --ref PATH_OR_UUID`** — image-to-image generation
  with one or more reference images. Each `--ref` is classified at the CLI
  boundary: case-insensitive 8-4-4-4-12 hex UUIDs are passed through verbatim
  (no upload), anything else is canonicalized (symlinks resolved at validation
  time) and uploaded before use. `--ref` is repeatable; UUIDs and paths can mix
  freely on the same call. Same flag set as `t2i` otherwise.
- **Multi-image fan-out** — `t2i` / `i2i` with `-n {2..4}` mint a single shared
  `batch_id` and issue N parallel POSTs (one per shot, each with its own random
  seed). Same-batch images share the prompt + refs; per-shot variation comes
  from independent seeds.
- **Three image models** wired behind CLI aliases:
  `nano2` → `NARWHAL` (Nano Banana 2; default, fast/balanced),
  `nano-pro` → `GEM_PIX_2` (Nano Banana Pro; higher quality),
  `image4` → `IMAGEN_3_5` (Imagen 4; photoreal-leaning).
- **Five aspect ratios** for image generation: `9:16`, `16:9`, `1:1`, `4:3`,
  `3:4` (default `9:16`, matching the Flow web UI).
- `download_image()` on `FlowApiClient` — direct download of a generated
  image's signed `fifeUrl` to disk. Streams to a temp file and atomically
  renames on success; enforces an SSRF host allowlist (only Google-controlled
  CDNs accepted).
- `scripts/smoke_image.py` — live single-image E2E smoke script (image
  counterpart of `scripts/smoke_e2e.py` for video). Run after
  `gflow auth login` to exercise the full happy path: project create →
  `batchGenerateImages` → fifeUrl download.

### Changed
- `FlowApiClient.upload_image` now validates **PNG/JPEG/WebP/GIF magic
  bytes** and rejects files larger than **20 MB** before issuing the upload
  request. Existing callers (`gflow video i2v`, `gflow video batch`) inherit
  the stricter validation; previously-undocumented use of `upload_image` for
  non-image payloads no longer works (was never officially supported).
- Project renamed `flow-cli` → `gflow-cli` across all docs and source. The
  PyPI package and GitHub repo were already at the new name in v0.2.0a1;
  this commit completes the in-source rename. Local clones may want to
  rename their working directory to match `gh clone https://github.com/ffroliva/gflow-cli`
  behavior.

### Security
- DEBUG-level body logs now redact reCAPTCHA Enterprise tokens and other
  bearer-style fields before emission, eliminating a token-leak vector when
  users share verbose logs while filing bug reports.
- `download_image()` enforces an **SSRF host allowlist** on the signed
  `fifeUrl` returned by Flow — only Google-controlled image CDNs
  (`*.googleusercontent.com`, etc.) are followed; any other host raises
  before the GET is issued. Defends against a Flow-side bug or compromise
  redirecting downloads to an attacker-controlled origin.
- `project_id` allowlist regex `^[A-Za-z0-9-]{1,128}$` on
  `batch_generate_images_url` — closes percent-encoded slash (`%2F`),
  Unicode-lookalike (U+FF0F / U+2215 / U+29F8), and CRLF/NUL injection
  bypasses that the previous denylist guard let through.

### CI
- Test matrix now includes Python 3.13 alongside 3.11 and 3.12.

## [0.2.0a1] — 2026-05-09

### Added
- **`gflow video t2v`** — generate a video from a text prompt via Veo 3.1.
  Flags: `--aspect 9:16|16:9|1:1`, `--seed`, `--output`, `--profile`, `--poll-interval`.
- **`gflow video i2v`** — generate a video from a start image + text prompt (Veo 3.1 I2V).
- **`gflow video batch`** — run a TSV manifest of video generations against one shared project.
- `gflow_cli.api` package — low-level REST client (`FlowApiClient`) + value objects
  (`GenerateVideoRequest`, `VideoOperation`, `VideoStatus`) for video generation.
- `gflow_cli.api.recaptcha` — reCAPTCHA Enterprise token minting via Playwright `page.evaluate`.
  `TokenMinter` caches the discovered site key per session; `mint(action)` is called immediately
  before each generation request.
- `gflow_cli.manifest` — TSV manifest parser for `gflow video batch`. Supports optional
  `start_image`, `end_image`, `aspect`, `output_path` columns; skips `# `-prefixed comments.
- `GFLOW_CLI_HEADLESS` env var (`bool`, default `true`). Set to `false` if reCAPTCHA refuses
  to mint tokens in headless mode (Google bot detection fallback).
- `scripts/smoke_e2e.py` — one-shot live T2V smoke test; run after `gflow auth login` to
  verify the full happy path (create project → generate_video → poll → download).
- **`CLAUDE.md`** at repo root — project memory hub for AI coding agents
  (Claude Code reads natively; Cursor/Codex/Gemini/Aider can read as reference).
- **`.claude/`** directory — repo-local Claude Code surface for maintainers.
  - `.claude/README.md` — what goes here, how to extend.
  - `.claude/commands/release.md` — `/release` slash command that automates
    version bump + CHANGELOG migration + tag + push, with quality gates.
- `gflow_cli.profile_store` — profile inventory + default-profile persistence
  in `$GFLOW_CLI_HOME/config.toml`. Five-step resolution chain (CLI flag > env >
  config > auto-select > raise) with named exceptions
  (`NoProfilesError`, `NoDefaultProfileError`).
- New auth subcommands: bare `gflow auth`, `gflow auth list`, `gflow auth use <name>`,
  `gflow auth logout [--profile NAME] [-y]`. First login auto-sets default profile.
- `KNOWN_ISSUES.md` at repo root — open/mitigated/resolved issues with workarounds.
- `docs/` tree (INDEX, AUTHENTICATION, CONFIGURATION, ARCHITECTURE, USAGE, SECURITY).
- `.env.template` documenting every supported env var.
- GitHub Actions CI: ruff, pyright, pytest on Python 3.11 and 3.12.
- GitHub Actions release workflow: tag-triggered PyPI publish via Trusted Publishing.
- MIT license, comprehensive README, [`DISCLAIMER.md`](DISCLAIMER.md), [`CONTRIBUTING.md`](CONTRIBUTING.md).
- [`skills/gflow-cli/SKILL.md`](skills/gflow-cli/SKILL.md) — installable Claude Code Skill.

### Removed
- `gflow_cli.providers.FlowProvider` and `gflow_cli.models` — superseded by `gflow_cli.api`.
- Legacy CLI stubs: `gflow upload`, `gflow generate`, `gflow status`, `gflow download`,
  `gflow i2v`. Replaced by the wired `gflow video` subgroup.

## [0.1.0] — _unreleased_

First skeleton. Not functional end-to-end yet.

[Unreleased]: https://github.com/ffroliva/gflow-cli/compare/v0.103.1...HEAD
[0.103.1]: https://github.com/ffroliva/gflow-cli/compare/v0.103.0...v0.103.1
[0.103.0]: https://github.com/ffroliva/gflow-cli/compare/v0.102.1...v0.103.0
[0.102.1]: https://github.com/ffroliva/gflow-cli/compare/v0.102.0...v0.102.1
[0.102.0]: https://github.com/ffroliva/gflow-cli/compare/v0.101.2...v0.102.0
[0.101.2]: https://github.com/ffroliva/gflow-cli/compare/v0.101.1...v0.101.2
[0.101.1]: https://github.com/ffroliva/gflow-cli/compare/v0.101.0...v0.101.1
[0.101.0]: https://github.com/ffroliva/gflow-cli/compare/v0.100.1...v0.101.0
[0.100.1]: https://github.com/ffroliva/gflow-cli/compare/v0.100.0...v0.100.1
[0.100.0]: https://github.com/ffroliva/gflow-cli/compare/v0.99.0...v0.100.0
[0.99.0]: https://github.com/ffroliva/gflow-cli/compare/v0.98.0...v0.99.0
[0.98.0]: https://github.com/ffroliva/gflow-cli/compare/v0.97.0...v0.98.0
[0.97.0]: https://github.com/ffroliva/gflow-cli/compare/v0.96.1...v0.97.0
[0.96.1]: https://github.com/ffroliva/gflow-cli/compare/v0.96.0...v0.96.1
[0.96.0]: https://github.com/ffroliva/gflow-cli/compare/v0.95.0...v0.96.0
[0.95.0]: https://github.com/ffroliva/gflow-cli/compare/v0.94.0...v0.95.0
[0.94.0]: https://github.com/ffroliva/gflow-cli/compare/v0.93.0...v0.94.0
[0.93.0]: https://github.com/ffroliva/gflow-cli/compare/v0.92.1...v0.93.0
[0.92.1]: https://github.com/ffroliva/gflow-cli/compare/v0.92.0...v0.92.1
[0.92.0]: https://github.com/ffroliva/gflow-cli/compare/v0.91.0...v0.92.0
[0.91.0]: https://github.com/ffroliva/gflow-cli/compare/v0.90.0...v0.91.0
[0.90.0]: https://github.com/ffroliva/gflow-cli/compare/v0.89.1...v0.90.0
[0.89.1]: https://github.com/ffroliva/gflow-cli/compare/v0.89.0...v0.89.1
[0.89.0]: https://github.com/ffroliva/gflow-cli/compare/v0.88.0...v0.89.0
[0.88.0]: https://github.com/ffroliva/gflow-cli/compare/v0.87.1...v0.88.0
[0.87.1]: https://github.com/ffroliva/gflow-cli/compare/v0.87.0...v0.87.1
[0.87.0]: https://github.com/ffroliva/gflow-cli/compare/v0.86.0...v0.87.0
[0.86.0]: https://github.com/ffroliva/gflow-cli/compare/v0.85.0...v0.86.0
[0.85.0]: https://github.com/ffroliva/gflow-cli/compare/v0.84.0...v0.85.0
[0.84.0]: https://github.com/ffroliva/gflow-cli/compare/v0.83.2...v0.84.0
[0.83.2]: https://github.com/ffroliva/gflow-cli/compare/v0.83.1...v0.83.2
[0.83.1]: https://github.com/ffroliva/gflow-cli/compare/v0.83.0...v0.83.1
[0.83.0]: https://github.com/ffroliva/gflow-cli/compare/v0.82.1...v0.83.0
[0.82.1]: https://github.com/ffroliva/gflow-cli/compare/v0.82.0...v0.82.1
[0.82.0]: https://github.com/ffroliva/gflow-cli/compare/v0.81.0...v0.82.0
[0.81.0]: https://github.com/ffroliva/gflow-cli/compare/v0.80.0...v0.81.0
[0.80.0]: https://github.com/ffroliva/gflow-cli/compare/v0.79.1...v0.80.0
[0.79.1]: https://github.com/ffroliva/gflow-cli/compare/v0.79.0...v0.79.1
[0.79.0]: https://github.com/ffroliva/gflow-cli/compare/v0.78.0...v0.79.0
[0.78.0]: https://github.com/ffroliva/gflow-cli/compare/v0.77.1...v0.78.0
[0.77.1]: https://github.com/ffroliva/gflow-cli/compare/v0.77.0...v0.77.1
[0.77.0]: https://github.com/ffroliva/gflow-cli/compare/v0.76.0...v0.77.0
[0.76.0]: https://github.com/ffroliva/gflow-cli/compare/v0.75.0...v0.76.0
[0.75.0]: https://github.com/ffroliva/gflow-cli/compare/v0.74.0...v0.75.0
[0.74.0]: https://github.com/ffroliva/gflow-cli/compare/v0.73.2...v0.74.0
[0.73.2]: https://github.com/ffroliva/gflow-cli/compare/v0.73.1...v0.73.2
[0.73.1]: https://github.com/ffroliva/gflow-cli/compare/v0.73.0...v0.73.1
[0.73.0]: https://github.com/ffroliva/gflow-cli/compare/v0.72.0...v0.73.0
[0.72.0]: https://github.com/ffroliva/gflow-cli/compare/v0.71.1...v0.72.0
[0.71.1]: https://github.com/ffroliva/gflow-cli/compare/v0.71.0...v0.71.1
[0.71.0]: https://github.com/ffroliva/gflow-cli/compare/v0.70.0...v0.71.0
[0.70.0]: https://github.com/ffroliva/gflow-cli/compare/v0.69.0...v0.70.0
[0.69.0]: https://github.com/ffroliva/gflow-cli/compare/v0.68.0...v0.69.0
[0.68.0]: https://github.com/ffroliva/gflow-cli/compare/v0.67.0...v0.68.0
[0.67.0]: https://github.com/ffroliva/gflow-cli/compare/v0.66.3...v0.67.0
[0.66.3]: https://github.com/ffroliva/gflow-cli/compare/v0.66.2...v0.66.3
[0.66.2]: https://github.com/ffroliva/gflow-cli/compare/v0.66.1...v0.66.2
[0.66.1]: https://github.com/ffroliva/gflow-cli/compare/v0.66.0...v0.66.1
[0.66.0]: https://github.com/ffroliva/gflow-cli/compare/v0.65.0...v0.66.0
[0.65.0]: https://github.com/ffroliva/gflow-cli/compare/v0.64.0...v0.65.0
[0.64.0]: https://github.com/ffroliva/gflow-cli/compare/v0.63.0...v0.64.0
[0.63.0]: https://github.com/ffroliva/gflow-cli/compare/v0.62.1...v0.63.0
[0.62.1]: https://github.com/ffroliva/gflow-cli/compare/v0.62.0...v0.62.1
[0.62.0]: https://github.com/ffroliva/gflow-cli/compare/v0.61.0...v0.62.0
[0.61.0]: https://github.com/ffroliva/gflow-cli/compare/v0.60.0...v0.61.0
[0.60.0]: https://github.com/ffroliva/gflow-cli/compare/v0.59.0...v0.60.0
[0.59.0]: https://github.com/ffroliva/gflow-cli/compare/v0.58.0...v0.59.0
[0.58.0]: https://github.com/ffroliva/gflow-cli/compare/v0.57.1...v0.58.0
[0.57.1]: https://github.com/ffroliva/gflow-cli/compare/v0.57.0...v0.57.1
[0.57.0]: https://github.com/ffroliva/gflow-cli/compare/v0.56.0...v0.57.0
[0.56.0]: https://github.com/ffroliva/gflow-cli/compare/v0.55.0...v0.56.0
[0.55.0]: https://github.com/ffroliva/gflow-cli/compare/v0.54.0...v0.55.0
[0.54.0]: https://github.com/ffroliva/gflow-cli/compare/v0.53.1...v0.54.0
[0.53.1]: https://github.com/ffroliva/gflow-cli/compare/v0.53.0...v0.53.1
[0.53.0]: https://github.com/ffroliva/gflow-cli/compare/v0.52.0...v0.53.0
[0.52.0]: https://github.com/ffroliva/gflow-cli/compare/v0.51.0...v0.52.0
[0.51.0]: https://github.com/ffroliva/gflow-cli/compare/v0.50.0...v0.51.0
[0.50.0]: https://github.com/ffroliva/gflow-cli/compare/v0.49.0...v0.50.0
[0.49.0]: https://github.com/ffroliva/gflow-cli/compare/v0.48.0...v0.49.0
[0.48.0]: https://github.com/ffroliva/gflow-cli/compare/v0.47.0...v0.48.0
[0.47.0]: https://github.com/ffroliva/gflow-cli/compare/v0.46.1...v0.47.0
[0.46.1]: https://github.com/ffroliva/gflow-cli/compare/v0.46.0...v0.46.1
[0.46.0]: https://github.com/ffroliva/gflow-cli/compare/v0.45.0...v0.46.0
[0.45.0]: https://github.com/ffroliva/gflow-cli/compare/v0.44.0...v0.45.0
[0.44.0]: https://github.com/ffroliva/gflow-cli/compare/v0.43.0...v0.44.0
[0.43.0]: https://github.com/ffroliva/gflow-cli/compare/v0.42.0...v0.43.0
[0.42.0]: https://github.com/ffroliva/gflow-cli/compare/v0.41.0...v0.42.0
[0.41.0]: https://github.com/ffroliva/gflow-cli/compare/v0.40.0...v0.41.0
[0.40.0]: https://github.com/ffroliva/gflow-cli/compare/v0.39.0...v0.40.0
[0.39.0]: https://github.com/ffroliva/gflow-cli/compare/v0.38.1...v0.39.0
[0.38.1]: https://github.com/ffroliva/gflow-cli/compare/v0.38.0...v0.38.1
[0.38.0]: https://github.com/ffroliva/gflow-cli/compare/v0.37.0...v0.38.0
[0.37.0]: https://github.com/ffroliva/gflow-cli/compare/v0.36.0...v0.37.0
[0.36.0]: https://github.com/ffroliva/gflow-cli/compare/v0.35.0...v0.36.0
[0.35.0]: https://github.com/ffroliva/gflow-cli/compare/v0.34.0...v0.35.0
[0.34.0]: https://github.com/ffroliva/gflow-cli/compare/v0.33.0...v0.34.0
[0.33.0]: https://github.com/ffroliva/gflow-cli/compare/v0.32.1...v0.33.0
[0.32.1]: https://github.com/ffroliva/gflow-cli/compare/v0.32.0...v0.32.1
[0.32.0]: https://github.com/ffroliva/gflow-cli/compare/v0.31.0...v0.32.0
[0.31.0]: https://github.com/ffroliva/gflow-cli/compare/v0.30.0...v0.31.0
[0.30.0]: https://github.com/ffroliva/gflow-cli/compare/v0.29.0...v0.30.0
[0.29.0]: https://github.com/ffroliva/gflow-cli/compare/v0.28.0...v0.29.0
[0.28.0]: https://github.com/ffroliva/gflow-cli/compare/v0.27.1...v0.28.0
[0.27.1]: https://github.com/ffroliva/gflow-cli/compare/v0.27.0...v0.27.1
[0.27.0]: https://github.com/ffroliva/gflow-cli/compare/v0.26.0...v0.27.0
[0.26.0]: https://github.com/ffroliva/gflow-cli/compare/v0.25.0...v0.26.0
[0.25.0]: https://github.com/ffroliva/gflow-cli/compare/v0.24.0...v0.25.0
[0.24.0]: https://github.com/ffroliva/gflow-cli/compare/v0.23.0...v0.24.0
[0.23.0]: https://github.com/ffroliva/gflow-cli/compare/v0.22.0...v0.23.0
[0.22.0]: https://github.com/ffroliva/gflow-cli/compare/v0.21.0...v0.22.0
[0.21.0]: https://github.com/ffroliva/gflow-cli/compare/v0.20.1...v0.21.0
[0.20.1]: https://github.com/ffroliva/gflow-cli/compare/v0.20.0...v0.20.1
[0.20.0]: https://github.com/ffroliva/gflow-cli/compare/v0.19.0...v0.20.0
[0.19.0]: https://github.com/ffroliva/gflow-cli/compare/v0.18.0...v0.19.0
[0.18.0]: https://github.com/ffroliva/gflow-cli/compare/v0.17.0...v0.18.0
[0.17.0]: https://github.com/ffroliva/gflow-cli/compare/v0.16.0...v0.17.0
[0.16.0]: https://github.com/ffroliva/gflow-cli/compare/v0.15.1...v0.16.0
[0.15.1]: https://github.com/ffroliva/gflow-cli/compare/v0.15.0...v0.15.1
[0.15.0]: https://github.com/ffroliva/gflow-cli/compare/v0.14.0...v0.15.0
[0.14.0]: https://github.com/ffroliva/gflow-cli/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/ffroliva/gflow-cli/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/ffroliva/gflow-cli/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/ffroliva/gflow-cli/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/ffroliva/gflow-cli/compare/v0.9.1...v0.10.0
[0.9.1]: https://github.com/ffroliva/gflow-cli/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/ffroliva/gflow-cli/compare/v0.8.1...v0.9.0
[0.8.1]: https://github.com/ffroliva/gflow-cli/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/ffroliva/gflow-cli/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/ffroliva/gflow-cli/compare/v0.6.0a6...v0.7.0
[0.6.0a6]: https://github.com/ffroliva/gflow-cli/compare/v0.6.0a5...v0.6.0a6
[0.6.0a5]: https://github.com/ffroliva/gflow-cli/compare/v0.6.0a4...v0.6.0a5
[0.6.0a1]: https://github.com/ffroliva/gflow-cli/compare/v0.5.0a1...v0.6.0a1
[0.5.0a1]: https://github.com/ffroliva/gflow-cli/compare/v0.4.0a2...v0.5.0a1
[0.3.0a1]: https://github.com/ffroliva/gflow-cli/releases/tag/v0.3.0a1
[0.2.0a1]: https://github.com/ffroliva/gflow-cli/releases/tag/v0.2.0a1
[0.1.0]: https://github.com/ffroliva/gflow-cli/releases/tag/v0.1.0

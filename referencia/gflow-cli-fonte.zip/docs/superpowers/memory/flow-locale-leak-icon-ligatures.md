---
name: flow-locale-leak-icon-ligatures
description: Flow renders dialog labels in the Chrome PROFILE language; --lang=en-US Chromium arg cannot override it. Selectors must use Material Symbols icon ligatures.
---

Flow's editor UI renders dialog labels in the Chrome **profile** language preference (set in `chrome://settings/languages`), NOT the Google **account** language and NOT the `--lang=en-US` Chromium launch arg. Any selector that matches localized text breaks on non-EN profiles. The fail-loud `RuntimeError` in `_attach_references` (PR #60) correctly distinguishes these — keep that hint when adding similar guards.

The durable part of the selector is the **ligature**, not the tag that carries it. Flow's two frontends render the same Material Symbols ligature under different carriers — labs (React) `<i class="google-symbols">`, migrated `flow.google.com` (Angular) `<mat-icon class="… google-symbols …">` — so a cascade must cover **both**:

```
button:has(i.google-symbols:text('<icon_ligature>'))   # labs
button:has(mat-icon:text('<icon_ligature>'))           # migrated
```

Anchoring on one carrier returns a flat zero on the other host while the control is fully visible. See [[ligature-carrier-differs-by-host]] — that split cost #727, because #703 swept three constants for it and missed a fourth. Known Material Symbols ligatures used in Flow's UI (locale-stable):

- `add_2` — project "+" button AND editor Add Media button (disambiguate via `aria-haspopup="dialog"` + `aria-controls^="radix-"` for the editor variant)
- `upload` — "Upload media" item in the media-attach popover (use **`:text-is('upload')` exact match** — `:text` would also match `drive_folder_upload` of the Uploads tab)
- `crop_16_9` / `crop_9_16` — mode-switch trigger (current aspect — note: matches whichever aspect was last selected, so the cascade in `MODE_SWITCH_TRIGGER_SELECTORS` covers both)
- `arrow_forward` — Generate/submit button
- `dashboard`, `image`, `videocam`, `voice_selection`, `accessibility_new`, `drive_folder_upload` — media-dialog tabs (locale-stable but rarely selected; tabs are pre-populated by Flow)

**Why:** incident #56 — `UPLOAD_MEDIA_BUTTON = button:has-text('Upload media')` missed on pt-BR ("Enviar mídia") → click landed nowhere → `expect_file_chooser` waited Playwright's default 30s → 34s silent hang. PR #60 replaced it with the icon ligature.

**How to apply:**
- Any new selector added under `src/gflow_cli/api/transports/` must anchor on icon ligatures or structure, never on a caption: no English-text fallback, no multi-locale cascade. The rule and its only exceptions (format tokens such as `1080p` or `8s`, measured on 2+ locales) are AGENTS.md § Locale-Invariance Discipline for UI Automation.
- Iconless buttons (e.g. "Add to Prompt") should be selected structurally, not by localized text — but **"the button that is not the icon button" is not the structural rule**, and on the migrated host that recipe is measured wrong twice over. `has_not=<i.google-symbols>` filters *nothing* there (the carrier tag is `mat-icon` — see [[ligature-carrier-differs-by-host]]), and the Frames popover's other visible button is `header-close-btn`, so the guess resolves to **Close**. Prefer the component's own class: the measured anchor for this exact button is `button.detail-add-to-prompt-btn`, confirmed on both entries into `flow-add-menu-popover-content` — the `@`-mention entry (`docs/superpowers/spikes/2026-09-05-migrated-r2v-attach-surface.md:72`) and the Frames entry (`docs/superpowers/spikes/2026-09-13-frames-picker-confirm.md`, #792).
- `FRAME_SLOT_BY_LABEL` (the English Start/End slot fallback, #63) was removed in #1273; the I2V frame slots anchor only on `FRAME_SLOTS_STRUCT`.
- Still-open text-based (PR #123, avatar generation — under council review, NOT yet merged): `_attach_likeness` uses `button[role='tab']:has-text('Avatar')` and `button:has-text('Add to Prompt')` (`ui_automation_video.py:871,881`). The "Add to Prompt" one directly violates the line-24 rule above (it's the exact example given). Step 1 correctly reuses the locale-stable `ADD_MEDIA_BUTTON` (`add_2` ligature); only steps 2–3 regressed. Fix before merge: structural/aria anchor + EN-text fallback. See [[avatar-likeness-wire-field]].

PR #124 added a purely structural anchor `button:has(span.content)` for Flow's new "Agent" composer pill (see [[flow-agent-composer-mode-panel-removal]]). Caveat learned there: a structural selector is only as safe as its uniqueness — `.first` blind-picks, so pin uniqueness with a captured-DOM fixture rather than asserting it in a comment.

See [[image-video-mode-switch-symmetry]] for related selector symmetry rules, and [[playwright-click-no-downstream-event-signature]] for the debugging heuristic that caught this.

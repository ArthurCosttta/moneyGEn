---
name: flow-capabilities-are-cohort-dependent
description: "A Flow capability table needs a cohort dimension. N accounts inside one cohort is still N=1 - agreement across accounts is evidence of a shared cohort, never of universality. Ask which host AND which profile before encoding any static capability predicate."
---

**A Flow capability table needs a cohort dimension. N accounts in the same cohort
is still N=1.**

On 2026-08-14 the video duration matrix was encoded as fact after two accounts in
two locales agreed, and [[video-model-capability-matrix]] explicitly recorded *"the
one-cohort caveat is retired."* On 2026-09-04 a third profile on the **same**
`labs.google` frontend showed the opposite - `4s/6s/8s` on all three
selectable Veo 3.1 models (`lower_priority` missed its picker there too) -
with different credit prices (5/10/100 vs 10/20/100). The two agreeing accounts were
one cohort, not two.

**Why:** Google runs experiment buckets. Two accounts landing in the same bucket
agree with each other and tell you nothing about the population. The failure is not
a bad capture - both captures were honest and both passed their own read-validity
checks.

**How to apply:**
- The public caveat lives in `KNOWN_ISSUES.md` under "Video duration control is
  absent on some account cohorts", plus its `website/docs/` mirror. When the
  cohort key is found, update the memory AND both docs. The code gate
  (`supports_duration()`, `api/video.py`) is still static and still refuses
  `--duration` on every named Veo model at the CLI edge (exit 2) - docs must not
  imply otherwise while [[#650]] is open.
- Before encoding any Flow capability as a static predicate, ask: which **host**
  (`labs.google` vs `flow.google.com`), which **profile**, which region - and is
  there a session-level read that makes the static table unnecessary?
- A static table that says "supported" when the account's UI has no control is as
  wrong as one that says "unsupported" when it does. Both directions cost the user.
- Reviewer heuristic: a PR that relaxes *or tightens* a capability gate on one
  capture gets the same question. Do not reject on "our capture disagrees" - that is
  symmetric evidence, not a refutation.
- When two captures conflict, check whether the **instrument** changed between them
  before concluding cohort difference. On #650 the collector's selector had widened;
  it was ruled out on the DOM evidence, but it had to be ruled out.

Applies to duration, ingredients, resolution tabs, count tabs, and aspect. See
[[video-model-capability-matrix]], [[flow-recon-must-run-on-denon82-ffroliva-migrated]],
[[pr-must-verify-on-affected-surface]].

**OUTCOME 2026-09-04/05:** `supports_duration()` is gone (#650): one shared `validate_duration_for_model()` backs DTO, CLI, chain, movie and MCP; whether the control is rendered is decided pre-submit at zero cost (exit 23 on labs, exit 11 on the migrated host). The line above describing the static refusal is history.


**A second instance of the same error, in the same file, found 2026-09-05.**
`lower_priority` missed its picker on every account measured, and
[[video-model-capability-matrix]] twice concluded from that agreement that *the
selector is broken*. It was not: a throttled migrated account renders the entry
(`Veo 3.1 - Lite [Lower Priority]`) and the shipped selector binds it. Flow appears to
serve that tier only to accounts it is throttling, so the earlier accounts shared a
cohort in **absence** as well as in duration.

The lesson generalises past capabilities: an **absent menu entry** is cohort evidence
exactly like a present one, and "missing on N accounts" never by itself indicts the
selector. Duration and credits for that tier remain unmeasured — it has only ever been
selected at $0, never generated on.

**Ask "does it EXIST here", not "is it required here" (2026-09-13, #792).** When a
cohort cannot reproduce a reported failure, the fix still needs an anchor, and guessing one
is how a selector lands on the wrong element. The second question is answerable on a cohort
that never needs the control: #792's confirm button was measured **present, visible and
enabled** on an account whose picker auto-closes, which anchored the fix on a class instead
of on the reporter's translated label — with no recon round-trip, and at $0. A control you
cannot trigger is not thereby a control you cannot observe.

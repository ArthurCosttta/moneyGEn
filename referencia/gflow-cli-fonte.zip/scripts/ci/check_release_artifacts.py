"""Release-protocol guard — a release PR must carry the /gflow:release artifacts.

Enforces (for the version in pyproject.toml):
  1. ``src/gflow_cli/__init__.py`` ``__version__`` parity,
  2. a ``## [<version>]`` CHANGELOG section,
  3. CHANGELOG footer links: ``[<version>]: …compare/…v<version>`` and
     ``[Unreleased]: …compare/v<version>...HEAD``,
  4. ``docs/LIVE_VERIFICATION_v<version>.md`` exists (the step-4b gate),
  5. ``docs/INDEX.md`` references that live-verification doc,
  6. ``docs/PROJECT_STATUS.md``'s "## Current release" section names this
     version (added 2026-09-02 — see ``_project_status_violations``),
  7. every CHANGELOG section already released on ``origin/main`` is unchanged
     (added 2026-11-07 — see ``_released_section_violations``).

Run by the main-base guard workflow on PRs targeting ``main`` (release PRs).
Born 2026-07-17: v0.38.1 was initially cut WITHOUT /gflow:release — the missing
live-verification gate would have shipped a fix whose primary bug (the
composer-render race) only the live run exposed. Owner directive: all releases
must follow /gflow:release; this guard makes the documentation half structural.

Usage: python scripts/ci/check_release_artifacts.py [repo_root]
Exit 0 = all artifacts present; exit 1 = violations (each printed).
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path


def find_violations(root: Path, released_changelog: str | None = None) -> list[str]:
    """Return human-readable violations for the release version in pyproject."""
    violations: list[str] = []
    pyproject = (root / "pyproject.toml").read_text(encoding="utf-8")
    m = re.search(r'^version = "([^"]+)"', pyproject, re.M)
    if not m:
        return ['pyproject.toml: no version = "…" found']
    version = m.group(1)

    init_text = (root / "src" / "gflow_cli" / "__init__.py").read_text(encoding="utf-8")
    if f'__version__ = "{version}"' not in init_text:
        violations.append(f"src/gflow_cli/__init__.py: __version__ != {version} (pyproject)")

    changelog = (root / "CHANGELOG.md").read_text(encoding="utf-8")
    if not re.search(rf"^## \[{re.escape(version)}\]", changelog, re.M):
        violations.append(f"CHANGELOG.md: missing '## [{version}]' section")
    footer_re = rf"^\[{re.escape(version)}\]: .+compare/.+v{re.escape(version)}"
    if not re.search(footer_re, changelog, re.M):
        violations.append(f"CHANGELOG.md: footer missing '[{version}]: compare' link")
    if f"compare/v{version}...HEAD" not in changelog:
        violations.append(
            f"CHANGELOG.md: [Unreleased] footer link not updated to compare/v{version}...HEAD"
        )

    lv = root / "docs" / f"LIVE_VERIFICATION_v{version}.md"
    if not lv.exists():
        violations.append(
            f"docs/LIVE_VERIFICATION_v{version}.md missing (step 4b of /gflow:release)"
        )
    elif f"LIVE_VERIFICATION_v{version}" not in (root / "docs" / "INDEX.md").read_text(
        encoding="utf-8"
    ):
        violations.append(f"docs/INDEX.md: no reference to LIVE_VERIFICATION_v{version}.md")

    violations.extend(_project_status_violations(root, version))
    violations.extend(_not_verified_violations(root, version))
    if released_changelog is not None:
        violations.extend(_released_section_violations(changelog, released_changelog))
    return violations


_SECTION_RE = re.compile(r"^## \[(\d[^\]]*)\][^\n]*\n(.*?)(?=^## \[|\Z)", re.M | re.S)
#: The link-definition footer after the last section. A definition INSIDE a section
#: (``[#357]: url`` in [0.41.0]) belongs to that section and is compared with it.
_FOOTER_RE = re.compile(r"(?:\n\[[^\]]+\]: [^\n]*)+\s*\Z")


def _sections(changelog: str) -> dict[str, str]:
    text = _FOOTER_RE.sub("", changelog.replace("\r\n", "\n"))
    return {m.group(1): m.group(0).strip() for m in _SECTION_RE.finditer(text)}


def _released_section_violations(changelog: str, released: str) -> list[str]:
    """A released section is history: a release branch may add sections, never rewrite one.

    #1164: merging develop into a feature branch replaced the released ``[0.94.0]`` entry with
    the next release's notes; nothing noticed until the next release cut.
    """
    current = _sections(changelog)
    out: list[str] = []
    for version, body in _sections(released).items():
        if version not in current:
            out.append(f"CHANGELOG.md: released section [{version}] is missing (it exists on main)")
        elif current[version] != body:
            out.append(f"CHANGELOG.md: released section [{version}] differs from main — restore it")
    return out


def _released_changelog(root: Path) -> str | None:
    """``CHANGELOG.md`` at ``$RELEASED_REF`` (default ``origin/main``), or None when unreadable.

    CI sets ``RELEASED_REF`` to the PR's base commit, the one its merge snapshot was built on,
    so a release landing on main during the run is not reported as missing.
    """
    ref = os.environ.get("RELEASED_REF") or "origin/main"
    try:
        out = subprocess.run(  # noqa: S603
            ["git", "-C", str(root), "show", f"{ref}:CHANGELOG.md"],  # noqa: S607
            capture_output=True,
            check=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return out.stdout.decode("utf-8")


#: Words that name a real external blocker — something the author cannot remove:
#: an exhausted quota, hardware or an account they do not have, a cohort they are
#: not in. AGENTS.md § "The Iron Law" permits these and nothing else.
_BLOCKER_MARKERS = (
    "blocked on",
    "blocker",
    "quota",
    "rate limit",
    "cannot reproduce",
    "no account",
    "do not control",
    "don't control",
    "not in the cohort",
    "hardware",
    "requires a device",
    "upstream outage",
    "needs a maintainer with",
    # "credits" alone is too loose — it matches any mention of the credits FEATURE.
    # Only a spend the author cannot make is a blocker.
    "spends credits",
    "credit budget",
)


def _not_verified_violations(root: Path, version: str) -> list[str]:
    """Every "Not verified" bullet in the ledger must name an external blocker.

    AGENTS.md § "The Iron Law": done means verified by a run, and the only permitted
    exception is a blocker you cannot remove. "Recorded, not omitted" is a record of a
    blocker, never a substitute for running — v0.69.0 shipped two items under that
    heading and both were verified within the hour once challenged, because neither was
    ever actually blocked. This gate makes the difference mechanical: name the blocker,
    or run it.
    """
    ledger = root / "docs" / f"LIVE_VERIFICATION_v{version}.md"
    if not ledger.is_file():
        return []  # absence is already reported by the caller
    text = ledger.read_text(encoding="utf-8")

    out: list[str] = []
    for header in re.finditer(r"^#{2,4}\s+.*not verified.*$", text, re.M | re.I):
        body = text[header.end() :]
        nxt = re.search(r"^#{2,4}\s", body, re.M)
        section = body[: nxt.start()] if nxt else body
        # Bullets may wrap onto continuation lines; join each bullet before matching.
        for bullet in re.split(r"(?m)^(?=[-*] )", section):
            entry = " ".join(bullet.split())
            if not entry or not entry.startswith(("- ", "* ")):
                continue
            # Two accountable forms: a blocker you cannot remove, or debt someone owes
            # under a tracked issue. Anything else is a run you skipped and wrote down.
            accountable = re.search(r"#\d+", entry) is not None or any(
                m in entry.lower() for m in _BLOCKER_MARKERS
            )
            if not accountable:
                out.append(
                    f"docs/LIVE_VERIFICATION_v{version}.md: a 'Not verified' entry names no "
                    f"blocker and no tracking issue — run it, say what stops you, or file "
                    f"it (AGENTS.md § The Iron Law): {entry[:90]}"
                )
    return out


def _project_status_violations(root: Path, version: str) -> list[str]:
    """``docs/PROJECT_STATUS.md``'s "Current release" must name this version.

    That file's own header promises it is "Updated on every signed tag", and
    nothing enforced it: v0.64.0 was cut with the section still announcing
    v0.63.0 as current, caught only because a human doc-review council read the
    file. Shipping a release that announces the wrong version as current is a
    documentation defect users see, so it belongs in the mechanical gate.

    Scoped to the "## Current release" section deliberately. Every past release
    is still named further down the file, so a whole-file substring search
    would pass on a completely stale header — the exact drift being caught.
    """
    status = root / "docs" / "PROJECT_STATUS.md"
    if not status.exists():
        return ["docs/PROJECT_STATUS.md missing (step 9 of /gflow:release)"]

    text = status.read_text(encoding="utf-8")
    m = re.search(r"^## Current release\s*$", text, re.M)
    if not m:
        return ['docs/PROJECT_STATUS.md: no "## Current release" section found']

    rest = text[m.end() :]
    next_heading = re.search(r"^(?:## |<details>)", rest, re.M)
    section = rest[: next_heading.start()] if next_heading else rest
    if f"v{version}" not in section:
        return [
            f'docs/PROJECT_STATUS.md: "## Current release" does not mention v{version} '
            "— update it to describe the release being cut (step 9 of /gflow:release)"
        ]
    return []


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
    released = _released_changelog(root)
    if released is None:
        if os.environ.get("GITHUB_ACTIONS") == "true":
            # CI fetched the baseline, so an unreadable one fails closed rather than skipping.
            print("::error::baseline not readable — released CHANGELOG sections not compared.")
            return 1
        print("::notice::origin/main not available — released CHANGELOG sections not compared.")
    violations = find_violations(root, released)
    if violations:
        for v in violations:
            print(f"::error title=Release protocol violation::{v}")
        print(
            f"\n{len(violations)} violation(s) — releases must follow /gflow:release "
            "(skills/release/SKILL.md)."
        )
        return 1
    print("release artifacts OK — /gflow:release protocol satisfied.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
